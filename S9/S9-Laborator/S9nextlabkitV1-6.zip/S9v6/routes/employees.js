const express = require("express");
const router = express.Router();
const Employee = require("../models/employee");
const { Op } = require("sequelize");

router
  .route("/employees")
  .get(async (req, res) => {
    try {
      const { simplified } = req.query;
      const query = {};

      if (simplified === "true") {
        query.attributes = ["firstname", "lastname"];
      }

      const employees = await Employee.findAll(query);
      return res.status(200).json(employees);
    } catch (err) {
      return res.status(500).json(err);
    }
  })
  .post(async (req, res) => {
    // console.log("request body ", req.body);
    try {
      const newEmployee = await Employee.create(req.body);
      return res.status(200).json(newEmployee);
    } catch (err) {
      return res.status(500).json(err);
    }
  });
// ... (rest of the file remains similar but is not the focus of the final edits shown)

module.exports = router;