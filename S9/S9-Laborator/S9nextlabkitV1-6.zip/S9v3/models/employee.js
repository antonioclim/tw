const { DataTypes } = require("sequelize");
const sequelize = require("../sequelize");

const Employee = sequelize.define(
  "Employee",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    firstname: {
      type: DataTypes.STRING,
      allowNull: false, // defaults to true
    },
    lastname: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      validate: {
        isEmail: true,
      },
    },
    birthyear: {
      type: DataTypes.INTEGER,
      validate: {
        min: 1900,
      },
    },
    salary: {
        type: DataTypes.INTEGER,
        validate: {
            min: 200,
        }
    }
  },
  {
    tableName: "Employees",
  }
);

module.exports = Employee;