"use strict";

const express = require("express");
const sequelize = require("./sequelize");
const router = require("./routes");

const app = express();

app.use(
  express.urlencoded({
    extended: true,
  })
);

app.use(express.json());

app.use("/api", router);

app.listen(7000, async () => {
  console.log("Server started on http://localhost:7000");
  try {
    await sequelize.authenticate();
    console.log("Connection has been established successfully.");
  } catch (err) {
    console.error("Unable to connect to the database:", err);
  }
});