const express = require("express");
const router = express.Router();
const employeesRouter = require("./employees");

router.use(employeesRouter);

module.exports = router;