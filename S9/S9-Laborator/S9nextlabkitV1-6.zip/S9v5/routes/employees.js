const express = require("express");
const router = express.Router();
const Employee = require("../models/employee");
const { Op } = require("sequelize");

router
  .route("/employees")
  .get(async (req, res) => {
    try {
      const { minSalary } = req.query;
      const where = {};
      if (minSalary) {
        where.salary = { [Op.gt]: minSalary };
      }

      const employees = await Employee.findAll({
        where,
      });
      return res.status(200).json(employees);
    } catch (err) {
      return res.status(500).json(err);
    }
  })
  .post(async (req, res) => {
    try {
      const newEmployee = await Employee.create(req.body);
      return res.status(200).json(newEmployee);
    } catch (err) {
      return res.status(500).json(err);
    }
  });

router
  .route("/employees/:id")
  .get(async (req, res) => {
    try {
      const employee = await Employee.findByPk(req.params.id);
      if (employee) {
        return res.status(200).json(employee);
      } else {
        return res
          .status(404)
          .json({ error: `Employee with id ${req.params.id} not found` });
      }
    } catch (err) {
      return res.status(500).json(err);
    }
  })
  .put(async (req, res) => {
    try {
      const employee = await Employee.findByPk(req.params.id);
      if (employee) {
        const updatedEmployee = await employee.update(req.body);
        return res.status(200).json(updatedEmployee);
      } else {
        return res
          .status(404)
          .json({ error: `Employee with id ${req.params.id} not found` });
      }
    } catch (err) {
      return res.status(500).json(err);
    }
  });

module.exports = router;