// src/models/index.js
const sequelize = require("../config/database");
const { DataTypes } = require("sequelize");

// iniţializăm modelele
const Employee = require("./employee")(sequelize, DataTypes);
const User = require("./user")(sequelize, DataTypes);
const Contact = require("./contact")(sequelize, DataTypes);
const Tag = require("./tag")(sequelize, DataTypes);

// --------------- ASOCIERI (segment 9EN) ---------------

// One‑to‑many: User -> Contact
User.hasMany(Contact, {
  foreignKey: "userId",
  as: "contacts"
});
Contact.belongsTo(User, {
  foreignKey: "userId",
  as: "user"
});

// Many‑to‑many: Contact <-> Tag prin tabela de legătură ContactTags
Contact.belongsToMany(Tag, {
  through: "ContactTags",
  foreignKey: "contactId",
  otherKey: "tagId",
  as: "tags"
});
Tag.belongsToMany(Contact, {
  through: "ContactTags",
  foreignKey: "tagId",
  otherKey: "contactId",
  as: "contacts"
});

module.exports = {
  sequelize,
  Employee,
  User,
  Contact,
  Tag
};
