// src/models/employee.js
module.exports = (sequelize, DataTypes) => {
  const Employee = sequelize.define(
    "Employee",
    {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      firstname: {
        type: DataTypes.STRING,
        allowNull: false,
        // Pasul 3 – restricţie 3–10 caractere
        validate: {
          len: {
            args: [3, 10],
            msg: "Firstname length must be between 3 and 10 characters"
          }
        }
      },
      lastname: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
          len: {
            args: [3, 10],
            msg: "Lastname length must be between 3 and 10 characters"
          }
        }
      },
      role: {
        type: DataTypes.STRING,
        allowNull: false,
        defaultValue: "developer"
      },
      // Pasul 2 – câmp salary cu valoare implicită 0 şi min 0
      salary: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0,
        validate: {
          min: {
            args: [0],
            msg: "Salary must be non‑negative"
          }
        }
      },
      birthyear: {
        type: DataTypes.INTEGER,
        allowNull: true,
        validate: {
          min: {
            args: [1900],
            msg: "Birth year should not be before 1900"
          }
        }
      }
    },
    {
      tableName: "Employees"
    }
  );

  return Employee;
};
