// src/config/database.js
const { Sequelize } = require("sequelize");
const path = require("path");

// baza SQLite va fi creată în ./data/seminar9.sqlite
const sequelize = new Sequelize({
  dialect: "sqlite",
  storage: path.join(__dirname, "..", "..", "data", "seminar9.sqlite"),
  logging: false // pune true dacă vrei să vezi SQL‑ul generat
});

module.exports = sequelize;
