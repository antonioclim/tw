// src/server/api-server.js
const express = require("express");
const {
  sequelize,
  Employee,
  User,
  Contact,
  Tag
} = require("../models");

const employeeRoutes = require("../routes/employees");
const relationshipsRoutes = require("../routes/relationships");

const app = express();
const PORT = 3001;

app.use(express.json());

// Health check simplu (bun pentru Pasul 1)
app.get("/health", (req, res) => {
  res.json({ status: "ok", message: "Seminar 9 API is running" });
});

// prefix /api pentru toate rutele de seminar
app.use("/api", employeeRoutes);
app.use("/api/relationships", relationshipsRoutes);

// Seed minimal pentru datele de relaţii (segment 9)
async function seedRelationshipsDemoData() {
  const userCount = await User.count();
  if (userCount > 0) {
    return; // deja există date, nu refacem seed‑ul
  }

  // utilizatori
  const alice = await User.create({
    name: "Alice",
    email: "alice@example.com"
  });
  const bob = await User.create({
    name: "Bob",
    email: "bob@example.com"
  });

  // contacte pentru Alice şi Bob
  const charlie = await Contact.create({
    name: "Charlie",
    phone: "111-222",
    email: "charlie@abc.com",
    userId: alice.id
  });
  const dave = await Contact.create({
    name: "Dave",
    phone: "333-444",
    email: "dave@abc.com",
    userId: alice.id
  });
  const eve = await Contact.create({
    name: "Eve",
    phone: "555-666",
    email: "eve@xyz.com",
    userId: bob.id
  });

  // tag‑uri
  const friendTag = await Tag.create({ name: "friend" });
  const workTag = await Tag.create({ name: "work" });

  // asocieri many‑to‑many
  await charlie.addTags([friendTag, workTag]);
  await dave.addTag(workTag);
  await eve.addTag(friendTag);
}

// Iniţializare: conectare, sync, seed + start server
async function start() {
  try {
    await sequelize.authenticate();
    console.log("Database connection has been established successfully.");

    // sincronizare modele cu SQLite (creare tabele dacă nu există)
    await sequelize.sync();
    console.log("Models were synchronised.");

    await seedRelationshipsDemoData();
    console.log("Demo data for relationships ensured.");

    app.listen(PORT, () => {
      console.log(`API server listening on http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error("Unable to start API server:", err);
  }
}

start();

module.exports = app;
