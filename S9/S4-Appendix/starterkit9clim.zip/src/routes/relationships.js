// src/routes/relationships.js
const express = require("express");
const { User, Contact, Tag, sequelize } = require("../models");

const router = express.Router();

/**
 * GET /api/relationships/users-with-contacts
 * One‑to‑many + eager loading: User -> Contacts -> Tags
 */
router.get("/users-with-contacts", async (req, res) => {
  try {
    const users = await User.findAll({
      include: [
        {
          model: Contact,
          as: "contacts",
          include: [{ model: Tag, as: "tags" }]
        }
      ]
    });

    return res.status(200).json(users);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * GET /api/relationships/contacts-with-tags
 * Many‑to‑many + eager loading: Contact <-> Tag
 */
router.get("/contacts-with-tags", async (req, res) => {
  try {
    const contacts = await Contact.findAll({
      include: [{ model: Tag, as: "tags" }]
    });
    return res.status(200).json(contacts);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * GET /api/relationships/export-json
 * Export JSON „platt” cu tabelele users, contacts, tags, contactTags (segment 9.5)
 */
router.get("/export-json", async (req, res) => {
  try {
    const ContactTags = sequelize.model("ContactTags");

    const [users, contacts, tags, contactTags] = await Promise.all([
      User.findAll({ raw: true }),
      Contact.findAll({ raw: true }),
      Tag.findAll({ raw: true }),
      ContactTags.findAll({ raw: true })
    ]);

    return res.status(200).json({
      users,
      contacts,
      tags,
      contactTags
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
