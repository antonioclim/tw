// src/routes/employees.js
const express = require("express");
const { Op } = require("sequelize");
const { Employee } = require("../models");

const router = express.Router();

// helper pentru tratarea erorilor de validare Sequelize
function handleSequelizeError(res, err) {
  if (err.name === "SequelizeValidationError") {
    return res.status(400).json({
      error: "Validation error",
      details: err.errors.map((e) => e.message)
    });
  }
  console.error(err);
  return res.status(500).json({ error: "Internal server error" });
}

/**
 * GET /api/employees
 * Pasul 3: listare
 * Pasul 5: filtrare (name, minSalary)
 * Pasul 6: proiecţii (simplified), sortare (sort)
 */
router.get("/employees", async (req, res) => {
  try {
    const { name, minSalary, simplified, sort } = req.query;

    const where = {};
    const options = { where };

    // Pasul 5 – filtrare după nume (LIKE %name%)
    if (name) {
      where.firstname = { [Op.like]: `%${name}%` };
    }

    // Filtrare după salariu minim (inspirat de S9v5)
    if (minSalary !== undefined) {
      const value = Number(minSalary);
      if (!Number.isNaN(value)) {
        where.salary = { [Op.gte]: value };
      }
    }

    // Pasul 6 – proiecţie simplificată
    if (simplified === "true") {
      options.attributes = ["id", "firstname", "lastname", "salary"];
    }

    // Pasul 6 – sortare după câmp (ex. ?sort=salary)
    if (sort) {
      const allowed = ["salary", "firstname", "lastname"];
      if (allowed.includes(sort)) {
        options.order = [[sort, "ASC"]];
      }
    }

    const employees = await Employee.findAll(options);
    return res.status(200).json(employees);
  } catch (err) {
    return handleSequelizeError(res, err);
  }
});

/**
 * POST /api/employees
 * Pasul 3 – creare (Create din CRUD)
 */
router.post("/employees", async (req, res) => {
  try {
    const newEmployee = await Employee.create(req.body);
    return res.status(201).json(newEmployee);
  } catch (err) {
    return handleSequelizeError(res, err);
  }
});

/**
 * GET /api/employees/:id
 * Pasul 4 – căutare după ID
 */
router.get("/employees/:id", async (req, res) => {
  try {
    const employee = await Employee.findByPk(req.params.id);
    if (!employee) {
      return res
        .status(404)
        .json({ error: `Employee with id ${req.params.id} not found` });
    }
    return res.status(200).json(employee);
  } catch (err) {
    return handleSequelizeError(res, err);
  }
});

/**
 * PUT /api/employees/:id
 * Pasul 4 – actualizare după ID
 */
router.put("/employees/:id", async (req, res) => {
  try {
    const employee = await Employee.findByPk(req.params.id);
    if (!employee) {
      return res
        .status(404)
        .json({ error: `Employee with id ${req.params.id} not found` });
    }

    const updated = await employee.update(req.body);
    return res.status(200).json(updated);
  } catch (err) {
    return handleSequelizeError(res, err);
  }
});

/**
 * DELETE /api/employees/:id
 * Pasul 4 – ştergere după ID
 */
router.delete("/employees/:id", async (req, res) => {
  try {
    const employee = await Employee.findByPk(req.params.id);
    if (!employee) {
      return res
        .status(404)
        .json({ error: `Employee with id ${req.params.id} not found` });
    }

    await employee.destroy();
    return res.status(204).send();
  } catch (err) {
    return handleSequelizeError(res, err);
  }
});

module.exports = router;
