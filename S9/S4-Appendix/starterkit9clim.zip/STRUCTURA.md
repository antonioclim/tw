Îţi dau mai jos, integral, conţinutul tuturor fişierelor din

`/public/steps/` (step1–step6), în stilul început deja în răspunsul precedent, apoi un `README.md` complet, scris ca pentru studenţi, cu structură, justificări şi explicaţii academice.



Voi păstra convenţiile din starterkit‑ul anterior:



\* server de \*\*documentaţie\*\* pe portul \*\*3000\*\* (`docs-server.js`, care serveşte `public/`)

\* server \*\*API\*\* pe portul \*\*3001\*\* (`api-server.js`), cu rute de forma `http://localhost:3001/api/...`



---



\## 1. Fişierele din `/public/steps`



\### 1.1. `/public/steps/step1.html`



```html

<!doctype html>

<html lang="ro">

&nbsp; <head>

&nbsp;   <meta charset="utf-8" />

&nbsp;   <title>Pasul 1 – Conectarea la baza de date</title>

&nbsp;   <link rel="stylesheet" href="/styles.css" />

&nbsp; </head>

&nbsp; <body>

&nbsp;   <nav>

&nbsp;     <a href="/">← Înapoi la index</a>

&nbsp;   </nav>



&nbsp;   <h1>Pasul 1 – Conectarea la baza de date (Sequelize + SQLite)</h1>



&nbsp;   <h2>Obiectiv</h2>

&nbsp;   <p>

&nbsp;     În acest prim pas dorim să ne asigurăm că infrastructura tehnică este

&nbsp;     funcţională: serverul Express porneşte, iar Sequelize reuşeşte să se

&nbsp;     conecteze la baza de date SQLite. Fără această etapă, orice discuţie

&nbsp;     ulterioară despre persistenţă cu ORM ar fi pur teoretică.

&nbsp;   </p>



&nbsp;   <h2>Ce scriem</h2>

&nbsp;   <ul>

&nbsp;     <li>

&nbsp;       În <code>src/config/database.js</code> definim instanţa de

&nbsp;       <code>Sequelize</code> care foloseşte driverul <code>sqlite</code> şi

&nbsp;       fişierul <code>seminar9.sqlite</code> din directorul

&nbsp;       <code>data/</code>.

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       În <code>src/server/api-server.js</code> importăm această instanţă şi

&nbsp;       apelăm <code>sequelize.authenticate()</code> înainte de a porni serverul

&nbsp;       API pe portul <code>3001</code>. Afişăm în consolă mesaje explicite de

&nbsp;       succes sau eroare.

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Expunem şi un endpoint de verificare de tip „health check”:

&nbsp;       <code>GET /health</code>, care întoarce un JSON simplu şi confirmă că

&nbsp;       serverul este pornit.

&nbsp;     </li>

&nbsp;   </ul>



&nbsp;   <h2>Ce face codul</h2>

&nbsp;   <p>

&nbsp;     Obţinem o conexiune abstractizată către baza de date: în loc să scriem

&nbsp;     direct SQL, lucrăm cu obiecte şi metode de nivel înalt. Dacă fişierul

&nbsp;     SQLite nu există, SQLite îl va crea la prima scriere; dacă nu se poate

&nbsp;     crea sau deschide, vedem imediat eroarea în consolă. Această etapă este

&nbsp;     esenţială pentru a valida că „stratul de persistenţă” este configurat

&nbsp;     corect.

&nbsp;   </p>



&nbsp;   <h2>Ce exemplificăm şi de ce</h2>

&nbsp;   <ul>

&nbsp;     <li>

&nbsp;       Separarea clară între configurarea conexiunii la baza de date

&nbsp;       (<code>database.js</code>) şi logica aplicaţiei (serverul Express).

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Diferenţa dintre erorile de infrastructură (nu se poate deschide

&nbsp;       fişierul SQLite, credenţiale invalide etc.) şi erorile de validare a

&nbsp;       datelor, pe care le vom discuta în paşii următori.

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Utilitatea unui endpoint de tip <em>health check</em> pentru a verifica

&nbsp;       rapid, inclusiv cu Postman, că API‑ul este „în picioare” înainte de a

&nbsp;       testa operaţii CRUD.

&nbsp;     </li>

&nbsp;   </ul>



&nbsp;   <h2>Testare rapidă cu Postman</h2>

&nbsp;   <ol>

&nbsp;     <li>Pornim serverul API: <code>npm run api</code>.</li>

&nbsp;     <li>Deschidem Postman şi creăm un request nou.</li>

&nbsp;     <li>

&nbsp;       Metoda: <strong>GET</strong><br />

&nbsp;       URL: <code>http://localhost:3001/health</code>

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Apăsăm <strong>Send</strong> – ar trebui să vedem un răspuns JSON de

&nbsp;       forma:

&nbsp;       <code>{"status":"ok","message":"Seminar 9 API is running"}</code>.

&nbsp;     </li>

&nbsp;   </ol>



&nbsp;   <p>

&nbsp;     În pasul următor vom discuta modul în care definim un model concret

&nbsp;     (<code>Employee</code>) şi sincronizăm schema logică (modelul) cu schema

&nbsp;     fizică (tabela din SQLite).

&nbsp;   </p>

&nbsp; </body>

</html>

```



---



\### 1.2. `/public/steps/step2.html`



```html

<!doctype html>

<html lang="ro">

&nbsp; <head>

&nbsp;   <meta charset="utf-8" />

&nbsp;   <title>Pasul 2 – Definirea entităţii Employee şi sincronizarea modelului</title>

&nbsp;   <link rel="stylesheet" href="/styles.css" />

&nbsp; </head>

&nbsp; <body>

&nbsp;   <nav>

&nbsp;     <a href="/">← Înapoi la index</a>

&nbsp;   </nav>



&nbsp;   <h1>Pasul 2 – Definirea entităţii <code>Employee</code> şi sincronizarea cu baza de date</h1>



&nbsp;   <h2>Obiectiv</h2>

&nbsp;   <p>

&nbsp;     În acest pas introducem noţiunea de model în Sequelize. Scopul este să

&nbsp;     definim entitatea <code>Employee</code> cu câmpuri semnificative (de

&nbsp;     exemplu <code>firstname</code>, <code>lastname</code>, <code>role</code>,

&nbsp;     <code>salary</code>) şi să sincronizăm această definiţie cu baza de date

&nbsp;     SQLite, astfel încât să apară tabela corespunzătoare.

&nbsp;   </p>



&nbsp;   <h2>Ce scriem</h2>

&nbsp;   <ul>

&nbsp;     <li>

&nbsp;       În <code>src/models/employee.js</code> definim:

&nbsp;       <ul>

&nbsp;         <li>câmpuri pentru prenume şi nume (<code>firstname</code>, <code>lastname</code>), obligatorii;</li>

&nbsp;         <li>

&nbsp;           câmpul <code>role</code> cu o valoare implicită (de exemplu

&nbsp;           <code>"developer"</code>);

&nbsp;         </li>

&nbsp;         <li>

&nbsp;           câmpul <code>salary</code> cu:

&nbsp;           <ul>

&nbsp;             <li>valoare implicită <code>0</code>;</li>

&nbsp;             <li>validare <em>minim</em> 0 (nu acceptăm salarii negative).</li>

&nbsp;           </ul>

&nbsp;         </li>

&nbsp;       </ul>

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       În <code>src/models/index.js</code> importăm modelul şi îl

&nbsp;       „înregistrăm” pe instanţa globală de <code>sequelize</code>.

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       În <code>src/server/api-server.js</code>, după

&nbsp;       <code>sequelize.authenticate()</code>, apelăm

&nbsp;       <code>sequelize.sync()</code> (eventual cu opţiunea

&nbsp;       <code>{ alter: true }</code> în timpul dezvoltării) pentru a crea sau

&nbsp;       actualiza tabela <code>Employees</code>.

&nbsp;     </li>

&nbsp;   </ul>



&nbsp;   <h2>Ce face codul</h2>

&nbsp;   <p>

&nbsp;     Din această etapă încolo, baza de date nu mai este un „black box”: avem o

&nbsp;     corespondenţă explicită între un tip de obiect JavaScript

&nbsp;     (<code>Employee</code>) şi o tabelă concretă (<code>Employees</code>) în

&nbsp;     SQLite. Sequelize generează automat comenzi <code>CREATE TABLE</code> sau

&nbsp;     <code>ALTER TABLE</code> pentru a reflecta structura modelului.

&nbsp;   </p>



&nbsp;   <h2>Ce exemplificăm şi de ce</h2>

&nbsp;   <ul>

&nbsp;     <li>

&nbsp;       Ideea de model ca abstractizare a unei entităţi de domeniu (un

&nbsp;       angajat) şi ca interfaţă între codul nostru şi baza de date relaţională.

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Utilizarea valorilor implicite şi a constrângerilor (de exemplu

&nbsp;       <code>min: 0</code> pentru salariu) direct în model, nu „împrăştiate”

&nbsp;       în codul aplicaţiei.

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Faptul că <code>sync()</code> trebuie folosit cu atenţie: în

&nbsp;       dezvoltare este util pentru a evolua schema; în producţie este de obicei

&nbsp;       înlocuit cu mecanisme de migrare controlate.

&nbsp;     </li>

&nbsp;   </ul>



&nbsp;   <h2>Testare rapidă cu Postman</h2>

&nbsp;   <p>

&nbsp;     Deşi <code>sync()</code> este apelat în principal la pornirea serverului,

&nbsp;     putem verifica efectele acestui pas indirect, creând ulterior înregistrări

&nbsp;     prin endpoint‑urile din Pasul 3 şi observând că:

&nbsp;   </p>

&nbsp;   <ul>

&nbsp;     <li>câmpul <code>salary</code> există în JSON‑ul întors de API;</li>

&nbsp;     <li>valoarea implicită 0 este aplicată dacă nu trimitem explicit un salariu;</li>

&nbsp;     <li>Sequelize refuză valori negative pentru <code>salary</code>.</li>

&nbsp;   </ul>



&nbsp;   <p>

&nbsp;     În Pasul 3 vom introduce explicit operaţiile GET şi POST asupra

&nbsp;     <code>Employee</code>, pe care le vom testa direct cu Postman.

&nbsp;   </p>

&nbsp; </body>

</html>

```



---



\### 1.3. `/public/steps/step3.html`



```html

<!doctype html>

<html lang="ro">

&nbsp; <head>

&nbsp;   <meta charset="utf-8" />

&nbsp;   <title>Pasul 3 – Operaţii GET şi POST</title>

&nbsp;   <link rel="stylesheet" href="/styles.css" />

&nbsp; </head>

&nbsp; <body>

&nbsp;   <nav>

&nbsp;     <a href="/">← Înapoi la index</a>

&nbsp;   </nav>



&nbsp;   <h1>Pasul 3 – Operaţii de citire şi creare (GET / POST) pentru Employee</h1>



&nbsp;   <h2>Obiectiv</h2>

&nbsp;   <p>

&nbsp;     În acest pas trecem de la simpla definiţie a modelului la un API REST

&nbsp;     minim funcţional. Implementăm operaţiile de citire (GET) şi creare (POST)

&nbsp;     pentru entitatea <code>Employee</code>, însoţite de o primă regulă de

&nbsp;     validare aplicată asupra numelui.

&nbsp;   </p>



&nbsp;   <h2>Ce scriem</h2>

&nbsp;   <ul>

&nbsp;     <li>

&nbsp;       În <code>src/routes/employees.js</code> definim ruta:

&nbsp;       <ul>

&nbsp;         <li>

&nbsp;           <code>GET /api/employees</code> – întoarce lista tuturor

&nbsp;           angajaţilor din tabelă.

&nbsp;         </li>

&nbsp;         <li>

&nbsp;           <code>POST /api/employees</code> – creează un angajat nou pe baza

&nbsp;           corpului JSON trimis de client.

&nbsp;         </li>

&nbsp;       </ul>

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       În modelul <code>Employee</code> adăugăm un validator pentru

&nbsp;       <code>firstname</code> (şi eventual <code>lastname</code>) care

&nbsp;       restricţionează lungimea numelui la 3–10 caractere.

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Ne asigurăm că în <code>api-server.js</code> folosim

&nbsp;       <code>express.json()</code> pentru a putea citi corect corpul cererii

&nbsp;       (body‑ul).

&nbsp;     </li>

&nbsp;   </ul>



&nbsp;   <h2>Ce face codul</h2>

&nbsp;   <p>

&nbsp;     Metoda <code>findAll()</code> a modelului <code>Employee</code> este

&nbsp;     mapată pe ruta GET şi corespunde, în esenţă, unui <code>SELECT \* FROM

&nbsp;     Employees</code>. Ruta POST foloseşte <code>Employee.create(req.body)</code>,

&nbsp;     care combină validările definite în model (de exemplu lungimea numelui) cu

&nbsp;     inserţia propriu‑zisă în baza de date.

&nbsp;   </p>



&nbsp;   <h2>Ce exemplificăm şi de ce</h2>

&nbsp;   <ul>

&nbsp;     <li>

&nbsp;       Trasarea completă a fluxului „cerere HTTP → ORM → bază de date → răspuns

&nbsp;       JSON”, fără a scrie manual o singură instrucţiune SQL.

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Faptul că regulile de validare pot fi centralizate la nivel de model şi

&nbsp;       nu dispersate în toate rutele; dacă schema se schimbă, modificăm o singură

&nbsp;       dată modelul.

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Răspunsurile HTTP ca mijloc de comunicare a erorilor de validare (de

&nbsp;       exemplu codul 400 atunci când numele nu respectă lungimea minimă).

&nbsp;     </li>

&nbsp;   </ul>



&nbsp;   <h2>Testare cu Postman (port 3001)</h2>



&nbsp;   <h3>1. Citirea tuturor angajaţilor</h3>

&nbsp;   <ol>

&nbsp;     <li>Metoda: <strong>GET</strong></li>

&nbsp;     <li>URL: <code>http://localhost:3001/api/employees</code></li>

&nbsp;     <li>Body: (nimic)</li>

&nbsp;     <li>Rezultat aşteptat: un array JSON (eventual gol la început).</li>

&nbsp;   </ol>



&nbsp;   <h3>2. Crearea unui angajat</h3>

&nbsp;   <ol>

&nbsp;     <li>Metoda: <strong>POST</strong></li>

&nbsp;     <li>URL: <code>http://localhost:3001/api/employees</code></li>

&nbsp;     <li>

&nbsp;       Headere: <code>Content-Type: application/json</code>

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Body (tab <strong>raw</strong>, tip <strong>JSON</strong>), de exemplu:

&nbsp;       <pre><code>{

&nbsp; "firstname": "Ana",

&nbsp; "lastname": "Ionescu",

&nbsp; "role": "developer",

&nbsp; "salary": 3500,

&nbsp; "birthyear": 1995

}</code></pre>

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Dacă validările sunt respectate, răspunsul va conţine angajatul creat,

&nbsp;       inclusiv câmpul <code>id</code>. În caz contrar, vom primi un cod

&nbsp;       <code>400</code> şi un mesaj de eroare.

&nbsp;     </li>

&nbsp;   </ol>



&nbsp;   <p>

&nbsp;     În Pasul 4 vom extinde acest API cu operaţii bazate pe identificator

&nbsp;     (<code>id</code>): căutare, actualizare şi ştergere.

&nbsp;   </p>

&nbsp; </body>

</html>

```



---



\### 1.4. `/public/steps/step4.html`



```html

<!doctype html>

<html lang="ro">

&nbsp; <head>

&nbsp;   <meta charset="utf-8" />

&nbsp;   <title>Pasul 4 – Operaţii bazate pe ID</title>

&nbsp;   <link rel="stylesheet" href="/styles.css" />

&nbsp; </head>

&nbsp; <body>

&nbsp;   <nav>

&nbsp;     <a href="/">← Înapoi la index</a>

&nbsp;   </nav>



&nbsp;   <h1>Pasul 4 – Operaţii bazate pe ID (GET / PUT / DELETE)</h1>



&nbsp;   <h2>Obiectiv</h2>

&nbsp;   <p>

&nbsp;     După ce am învăţat să listăm şi să creăm angajaţi, este natural să dorim

&nbsp;     să lucrăm cu instanţe individuale: să căutăm un angajat după ID, să îl

&nbsp;     actualizăm sau să îl ştergem. Acest pas închide ciclul clasic CRUD.

&nbsp;   </p>



&nbsp;   <h2>Ce scriem</h2>

&nbsp;   <ul>

&nbsp;     <li>

&nbsp;       În <code>src/routes/employees.js</code> extindem routerul cu:

&nbsp;       <ul>

&nbsp;         <li>

&nbsp;           <code>GET /api/employees/:id</code> – căutarea unui angajat după

&nbsp;           ID, folosind <code>Employee.findByPk()</code>.

&nbsp;         </li>

&nbsp;         <li>

&nbsp;           <code>PUT /api/employees/:id</code> – actualizarea unui angajat

&nbsp;           existent, folosind <code>employee.update()</code>.

&nbsp;         </li>

&nbsp;         <li>

&nbsp;           <code>DELETE /api/employees/:id</code> – ştergerea unui angajat,

&nbsp;           folosind <code>employee.destroy()</code>.

&nbsp;         </li>

&nbsp;       </ul>

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Tratăm explicit cazul în care angajatul nu există: returnăm codul

&nbsp;       <code>404</code> şi un mesaj clar.

&nbsp;     </li>

&nbsp;   </ul>



&nbsp;   <h2>Ce face codul</h2>

&nbsp;   <p>

&nbsp;     Fiecare din aceste operaţii corespunde unui tip de comandă SQL:

&nbsp;     <code>SELECT</code> cu condiţie pe cheie primară,

&nbsp;     <code>UPDATE</code> şi <code>DELETE</code>. Sequelize ascunde detaliile

&nbsp;     SQL, dar păstrează semanticile relaţionale: instanţa modelului

&nbsp;     <code>Employee</code> este legată de rândul din tabelă prin câmpul

&nbsp;     <code>id</code>.

&nbsp;   </p>



&nbsp;   <h2>Ce exemplificăm şi de ce</h2>

&nbsp;   <ul>

&nbsp;     <li>

&nbsp;       Importanţa codurilor de status HTTP: <code>200</code> pentru succes,

&nbsp;       <code>404</code> pentru „not found”, <code>400</code> sau

&nbsp;       <code>500</code> pentru erori.

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Folosirea metodelor de instanţă (<code>update()</code>,

&nbsp;       <code>destroy()</code>) ale modelelor Sequelize pentru a manipula datele

&nbsp;       într‑un mod orientat‑obiect.

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Responsabilitatea API‑ului de a răspunde cu mesaje clare şi consecvente

&nbsp;       în cazul erorilor (de exemplu atunci când ID‑ul nu există).

&nbsp;     </li>

&nbsp;   </ul>



&nbsp;   <h2>Testare cu Postman (port 3001)</h2>



&nbsp;   <h3>1. Citirea unui angajat după ID</h3>

&nbsp;   <ol>

&nbsp;     <li>Metoda: <strong>GET</strong></li>

&nbsp;     <li>URL: <code>http://localhost:3001/api/employees/1</code></li>

&nbsp;     <li>

&nbsp;       Rezultat aşteptat: obiectul JSON corespunzător angajatului cu

&nbsp;       <code>id = 1</code> sau cod <code>404</code> dacă nu există.

&nbsp;     </li>

&nbsp;   </ol>



&nbsp;   <h3>2. Actualizarea unui angajat</h3>

&nbsp;   <ol>

&nbsp;     <li>Metoda: <strong>PUT</strong></li>

&nbsp;     <li>URL: <code>http://localhost:3001/api/employees/1</code></li>

&nbsp;     <li>

&nbsp;       Body (JSON), de exemplu:

&nbsp;       <pre><code>{

&nbsp; "salary": 4200

}</code></pre>

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Rezultat: obiectul JSON actualizat sau cod <code>404</code> dacă

&nbsp;       angajatul nu există.

&nbsp;     </li>

&nbsp;   </ol>



&nbsp;   <h3>3. Ştergerea unui angajat</h3>

&nbsp;   <ol>

&nbsp;     <li>Metoda: <strong>DELETE</strong></li>

&nbsp;     <li>URL: <code>http://localhost:3001/api/employees/1</code></li>

&nbsp;     <li>

&nbsp;       Rezultat: cod <code>204 No Content</code> (sau un mesaj JSON simplu

&nbsp;       confirmând ştergerea).

&nbsp;     </li>

&nbsp;   </ol>



&nbsp;   <p>

&nbsp;     După acest pas putem spune că am construit un mic API REST complet pentru

&nbsp;     entitatea <code>Employee</code>. În Pasul 5 vom adăuga criterii de

&nbsp;     selecţie (filtrare) pentru interogările GET.

&nbsp;   </p>

&nbsp; </body>

</html>

```



---



\### 1.5. `/public/steps/step5.html`



```html

<!doctype html>

<html lang="ro">

&nbsp; <head>

&nbsp;   <meta charset="utf-8" />

&nbsp;   <title>Pasul 5 – Selecţii şi filtrare</title>

&nbsp;   <link rel="stylesheet" href="/styles.css" />

&nbsp; </head>

&nbsp; <body>

&nbsp;   <nav>

&nbsp;     <a href="/">← Înapoi la index</a>

&nbsp;   </nav>



&nbsp;   <h1>Pasul 5 – Selecţii (filtrare) cu clauza <code>where</code> în Sequelize</h1>



&nbsp;   <h2>Obiectiv</h2>

&nbsp;   <p>

&nbsp;     Până acum am lucrat cu liste complete şi cu operaţii pe ID. În practică

&nbsp;     avem frecvent nevoie de interogări filtrate (de exemplu „toţi angajaţii cu

&nbsp;     numele care conţine <em>Ana</em>” sau „toţi angajaţii cu salariu peste o

&nbsp;     anumită valoare”). În acest pas folosim clauza

&nbsp;     <code>where</code> din Sequelize pentru a construi astfel de selecţii.

&nbsp;   </p>



&nbsp;   <h2>Ce scriem</h2>

&nbsp;   <ul>

&nbsp;     <li>

&nbsp;       În <code>src/routes/employees.js</code>, în handler‑ul pentru

&nbsp;       <code>GET /api/employees</code>, prelucrăm parametrii de query:

&nbsp;       <ul>

&nbsp;         <li>

&nbsp;           <code>name</code> – pentru filtrare după prenume (sau nume, în

&nbsp;           funcţie de ce am ales în model).

&nbsp;         </li>

&nbsp;         <li>

&nbsp;           <code>minSalary</code> – pentru filtrare după un salariu minim.

&nbsp;         </li>

&nbsp;       </ul>

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Construim un obiect <code>where</code> şi îl transmitem către

&nbsp;       <code>Employee.findAll({ where })</code>. Pentru <code>name</code>

&nbsp;       folosim operatorul <code>LIKE</code>, iar pentru

&nbsp;       <code>minSalary</code> operatorul <code>\&gt;=</code> (sau

&nbsp;       <code>\&gt;</code>, după preferinţă).

&nbsp;     </li>

&nbsp;   </ul>



&nbsp;   <h2>Ce face codul</h2>

&nbsp;   <p>

&nbsp;     În funcţie de parametrii de query prezenţi, obiectul <code>where</code>

&nbsp;     poate fi gol (niciun filtru) sau poate conţine una sau mai multe

&nbsp;     condiţii. Sequelize transformă aceste condiţii într‑un <code>WHERE</code>

&nbsp;     în SQL, folosind operatori specifici dialectului SQLite.

&nbsp;   </p>



&nbsp;   <h2>Ce exemplificăm şi de ce</h2>

&nbsp;   <ul>

&nbsp;     <li>

&nbsp;       Ideea de „interogare parametrică”: structura rutei rămâne aceeaşi,

&nbsp;       dar rezultatul depinde de parametrii de query.

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Rolul obiectului <code>where</code> ca interfaţă declarativă pentru

&nbsp;       construirea condiţiilor în ORM, fără a scrie manual predicate SQL.

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Interacţiunea cu Postman: modul în care modificarea interactivă a

&nbsp;       parametrilor de query produce seturi de rezultate diferite.

&nbsp;     </li>

&nbsp;   </ul>



&nbsp;   <h2>Testare cu Postman (port 3001)</h2>



&nbsp;   <h3>1. Fără filtre</h3>

&nbsp;   <ol>

&nbsp;     <li>Metoda: <strong>GET</strong></li>

&nbsp;     <li>URL: <code>http://localhost:3001/api/employees</code></li>

&nbsp;     <li>Rezultat: toţi angajaţii existenţi în tabelă.</li>

&nbsp;   </ol>



&nbsp;   <h3>2. Filtrare după nume</h3>

&nbsp;   <ol>

&nbsp;     <li>Metoda: <strong>GET</strong></li>

&nbsp;     <li>

&nbsp;       URL:

&nbsp;       <code>http://localhost:3001/api/employees?name=an</code>

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Rezultat: toţi angajaţii al căror prenume (sau nume) conţine

&nbsp;       secvenţa <code>"an"</code>.

&nbsp;     </li>

&nbsp;   </ol>



&nbsp;   <h3>3. Filtrare după salariu minim</h3>

&nbsp;   <ol>

&nbsp;     <li>Metoda: <strong>GET</strong></li>

&nbsp;     <li>

&nbsp;       URL:

&nbsp;       <code>http://localhost:3001/api/employees?minSalary=4000</code>

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Rezultat: angajaţii cu salariu mai mare sau egal cu 4000 (în funcţie

&nbsp;       de implementarea exactă a operatorului).

&nbsp;     </li>

&nbsp;   </ol>



&nbsp;   <p>

&nbsp;     În Pasul 6 vom merge mai departe, introducând noţiunea de proiecţie

&nbsp;     (selectarea doar a anumitor câmpuri) şi ordonarea rezultatelor în funcţie

&nbsp;     de un parametru suplimentar.

&nbsp;   </p>

&nbsp; </body>

</html>

```



---



\### 1.6. `/public/steps/step6.html`



```html

<!doctype html>

<html lang="ro">

&nbsp; <head>

&nbsp;   <meta charset="utf-8" />

&nbsp;   <title>Pasul 6 – Proiecţii şi ordonare</title>

&nbsp;   <link rel="stylesheet" href="/styles.css" />

&nbsp; </head>

&nbsp; <body>

&nbsp;   <nav>

&nbsp;     <a href="/">← Înapoi la index</a>

&nbsp;   </nav>



&nbsp;   <h1>Pasul 6 – Proiecţii de câmpuri şi ordonare a rezultatelor</h1>



&nbsp;   <h2>Obiectiv</h2>

&nbsp;   <p>

&nbsp;     În practică nu avem nevoie întotdeauna de toate câmpurile unui model

&nbsp;     şi nici de o ordine „naturală” a rezultatelor. În acest pas folosim

&nbsp;     opţiunile <code>attributes</code> şi <code>order</code> ale lui Sequelize

&nbsp;     pentru a controla explicit ce câmpuri sunt returnate şi în ce ordine

&nbsp;     sunt sortate înregistrările.

&nbsp;   </p>



&nbsp;   <h2>Ce scriem</h2>

&nbsp;   <ul>

&nbsp;     <li>

&nbsp;       În <code>src/routes/employees.js</code>, în handler‑ul pentru

&nbsp;       <code>GET /api/employees</code>:

&nbsp;       <ul>

&nbsp;         <li>

&nbsp;           dacă parametrul <code>simplified=true</code> este prezent, setăm

&nbsp;           <code>options.attributes</code> la un subset (de exemplu

&nbsp;           <code>\["id", "firstname", "lastname", "salary"]</code>);

&nbsp;         </li>

&nbsp;         <li>

&nbsp;           dacă parametrul <code>sort</code> este prezent (de ex.

&nbsp;           <code>sort=salary</code>), adăugăm <code>options.order =

&nbsp;           \[\[sort, "ASC"]]</code>, eventual după ce verificăm că valoarea este

&nbsp;           una permisă.

&nbsp;         </li>

&nbsp;       </ul>

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Apelăm <code>Employee.findAll(options)</code>, unde

&nbsp;       <code>options</code> conţine atât filtrarea (din Pasul 5), cât şi

&nbsp;       proiecţia şi ordonarea (din acest pas).

&nbsp;     </li>

&nbsp;   </ul>



&nbsp;   <h2>Ce face codul</h2>

&nbsp;   <p>

&nbsp;     Parametrul <code>simplified</code> controlează o proiecţie: în loc să

&nbsp;     aducem toate câmpurile (inclusiv <code>email</code>, <code>birthyear</code>

&nbsp;     etc.), limităm rezultatul la câteva atribute considerate relevante

&nbsp;     pentru scenariul curent (de exemplu o listă de salarii). Parametrul

&nbsp;     <code>sort</code> controlează coloana după care sunt ordonate rândurile

&nbsp;     în SQL.

&nbsp;   </p>



&nbsp;   <h2>Ce exemplificăm şi de ce</h2>

&nbsp;   <ul>

&nbsp;     <li>

&nbsp;       Tehnica de a construi incremental opţiunile unei interogări

&nbsp;       (<code>where</code>, <code>attributes</code>, <code>order</code>)

&nbsp;       pornind de la parametrii de query.

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Economia de date transferate: proiecţiile reduc cantitatea de JSON

&nbsp;       transmisă, ceea ce poate fi important pentru performanţă.

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Controlul ordinii de afişare din API, de exemplu pentru a obţine o

&nbsp;       listă de angajaţi sortaţi după salariu.

&nbsp;     </li>

&nbsp;   </ul>



&nbsp;   <h2>Testare cu Postman (port 3001)</h2>



&nbsp;   <h3>1. Proiecţie simplificată</h3>

&nbsp;   <ol>

&nbsp;     <li>Metoda: <strong>GET</strong></li>

&nbsp;     <li>

&nbsp;       URL:

&nbsp;       <code>http://localhost:3001/api/employees?simplified=true</code>

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Rezultat: pentru fiecare angajat, doar câmpurile

&nbsp;       <code>id</code>, <code>firstname</code>, <code>lastname</code> şi

&nbsp;       <code>salary</code>.

&nbsp;     </li>

&nbsp;   </ol>



&nbsp;   <h3>2. Proiecţie + ordonare după salariu</h3>

&nbsp;   <ol>

&nbsp;     <li>Metoda: <strong>GET</strong></li>

&nbsp;     <li>

&nbsp;       URL:

&nbsp;       <code>http://localhost:3001/api/employees?simplified=true\&amp;sort=salary</code>

&nbsp;     </li>

&nbsp;     <li>

&nbsp;       Rezultat: aceeaşi proiecţie ca mai sus, dar angajaţii sunt ordonaţi

&nbsp;       crescător după salariu.

&nbsp;     </li>

&nbsp;   </ol>



&nbsp;   <p>

&nbsp;     La acest punct am parcurs întreg fluxul seminariului: am început cu

&nbsp;     conectarea la baza de date şi definirea modelului, am implementat CRUD

&nbsp;     complet, am adăugat filtrare, proiecţii şi sortare. Pe această bază se

&nbsp;     poate construi ulterior un segment dedicat relaţiilor între modele

&nbsp;     (one‑to‑many, many‑to‑many) şi import/export JSON.

&nbsp;   </p>

&nbsp; </body>

</html>

```



---



\## 2. README.md complet (stil academic, pentru studenţi)



Fişierul următor trebuie pus la rădăcina proiectului, în `nextlab/README.md`.



````markdown

\# Seminar 9 – Persistenţă cu ORM (Sequelize + SQLite) – Starterkit



Acest proiect constituie un „starterkit” pentru Seminarul 9, dedicat

persistenţei datelor prin utilizarea unui Object‑Relational Mapper (ORM),

în particular \*\*Sequelize\*\* peste o bază de date \*\*SQLite\*\*.



Scopul principal este să avem un cadru unic, coerent, în care:



\- să putem discuta, incremental, paşii de construcţie ai unui API REST

&nbsp; peste o entitate simplă (`Employee`);

\- să separăm clar partea de API (portul 3001) de partea de documentaţie

&nbsp; pedagogică (portul 3000);

\- să putem testa şi ilustra toate ideile direct cu Postman.



---



\## 1. Cerinţe şi obiective de învăţare



La finalul acestui seminar, studenţii ar trebui:



1\. Să înţeleagă rolul unui ORM într‑o aplicaţie web:

&nbsp;  - maparea modelelor de domeniu pe tabele relaţionale;

&nbsp;  - avantajele în raport cu scrierea manuală a instrucţiunilor SQL.

2\. Să ştie cum se configurează Sequelize cu SQLite într‑un proiect Node.js.

3\. Să poată implementa un flux complet CRUD (Create–Read–Update–Delete)

&nbsp;  pentru o entitate simplă.

4\. Să utilizeze filtre, proiecţii şi sortări bazate pe parametri de query.

5\. Să testeze şi să documenteze un API REST folosind Postman.

6\. (Opţional, pentru segmentul avansat) Să aibă o bază pentru a înţelege

&nbsp;  relaţii one‑to‑many şi many‑to‑many, <em>eager loading</em> şi

&nbsp;  import/export JSON, conform prezentării dedicate Sequelize ORM Relationships. :contentReference\[oaicite:0]{index=0}



---



\## 2. Context tehnic şi cerinţe de mediu



\- Sistem de operare: Windows 11 (dar proiectul este portabil şi pe alte

&nbsp; sisteme).

\- Editor recomandat: Visual Studio Code.

\- Node.js: v18+ (sau o versiune relativ recentă care suportă sintaxa folosită).

\- NPM: pentru gestionarea pachetelor.



Proiectul este gândit să fie amplasat în:



```text

Z:\\tw\\SxTEST\\FAZA9\\nextlab

````



(Desigur, căile pot fi adaptate, dar în seminar vom presupune această

configuraţie.)



---



\## 3. Structura proiectului



Structura propusă este:



```text

nextlab/

&nbsp; package.json

&nbsp; README.md

&nbsp; /data/

&nbsp;   seminar9.sqlite

&nbsp; /src/

&nbsp;   /config/

&nbsp;     database.js

&nbsp;   /models/

&nbsp;     index.js

&nbsp;     employee.js

&nbsp;     user.js

&nbsp;     contact.js

&nbsp;     tag.js

&nbsp;   /routes/

&nbsp;     employees.js

&nbsp;     relationships.js

&nbsp;   /server/

&nbsp;     api-server.js        # serverul API (port 3001)

&nbsp;     docs-server.js       # serverul de documentaţie (port 3000)

&nbsp; /public/

&nbsp;   styles.css

&nbsp;   index.html

&nbsp;   /steps/

&nbsp;     step1.html

&nbsp;     step2.html

&nbsp;     step3.html

&nbsp;     step4.html

&nbsp;     step5.html

&nbsp;     step6.html

&nbsp;   segment9-relationships.html

&nbsp;   postman.html

```



\### Justificarea structurii



\* \*\*`src/config/`\*\*: separăm configurarea bazei de date (Sequelize + SQLite)

&nbsp; de restul codului, pentru a putea schimba ulterior dialectul (MySQL,

&nbsp; PostgreSQL etc.) fără a afecta codul de routing.

\* \*\*`src/models/`\*\*: conţine toate modelele Sequelize. Folderul

&nbsp; `index.js` acţionează ca un agregator care:



&nbsp; \* iniţializează modelele;

&nbsp; \* defineşte asocierile (relaţiile) dintre ele;

&nbsp; \* exportă un obiect comun cu `sequelize` şi toate modelele.

\* \*\*`src/routes/`\*\*: delimitează rutele aferente entităţii de bază

&nbsp; (`employees.js`) de cele aferente segmentului de relaţii (`relationships.js`).

&nbsp; Studenţii văd astfel clar „frontiera” dintre logică de acces la date şi

&nbsp; definiţiile de modele.

\* \*\*`src/server/`\*\*: aici avem două servere Express distincte:



&nbsp; \* `api-server.js` – API-ul tehnic, consumat de Postman;

&nbsp; \* `docs-server.js` – serverul de documentaţie, care serveşte fişierele static.

\* \*\*`public/`\*\*: conţine interfaţa de documentaţie:



&nbsp; \* `index.html` – pagina centrală cu linkuri către paşi;

&nbsp; \* `steps/\*.html` – câte o pagină pentru fiecare pas (1–6);

&nbsp; \* `segment9-relationships.html` – pagina de sinteză pentru relaţii;

&nbsp; \* `postman.html` – instrucţiuni de utilizare a Postman.



Această separare are o puternică motivaţie pedagogică: putem discuta

algoritmica şi modelarea datelor independent de detaliile de prezentare

(HTML/CSS) şi, invers, putem discuta structura documentaţiei fără a

interfera cu codul API.



---



\## 4. Instalare şi rulare



Din directorul `nextlab/`:



1\. Iniţializare pachete (o singură dată):



&nbsp;  ```bash

&nbsp;  npm install

&nbsp;  ```



2\. Pornirea serverului API (port 3001):



&nbsp;  ```bash

&nbsp;  npm run api

&nbsp;  ```



&nbsp;  Veţi vedea în consolă mesaje de tip:



&nbsp;  \* `Database connection has been established successfully.`

&nbsp;  \* `Models were synchronised.`

&nbsp;  \* `API server listening on http://localhost:3001`



3\. Pornirea serverului de documentaţie (port 3000), într‑un al doilea terminal:



&nbsp;  ```bash

&nbsp;  npm run docs

&nbsp;  ```



&nbsp;  Mesaj tipic: `Docs server available at http://localhost:3000`.



4\. Acces:



&nbsp;  \* Documentaţie (paşi, explicaţii, linkuri):

&nbsp;    \[http://localhost:3000](http://localhost:3000)

&nbsp;  \* API (de testat cu Postman):

&nbsp;    \[http://localhost:3001](http://localhost:3001)



---



\## 5. Arhitectura backend‑ului (port 3001)



\### 5.1. Conectarea la baza de date



Fişier: `src/config/database.js`



\* Creează instanţa de `Sequelize` cu:



&nbsp; \* `dialect: 'sqlite'`

&nbsp; \* `storage: data/seminar9.sqlite`

\* Oferă un punct unic de configurare pentru baza de date.



\### 5.2. Modelele



Fişier: `src/models/employee.js`



\* Defineşte entitatea de bază `Employee` cu câmpuri precum:



&nbsp; \* `firstname`, `lastname` – obligatorii, cu validări de lungime;

&nbsp; \* `role` – cu valoare implicită, de ex. `"developer"`;

&nbsp; \* `salary` – cu valoare implicită `0` şi validare `min 0`;

&nbsp; \* `birthyear` – cu validare minimă (de ex. ≥ 1900).

\* Mapează modelul pe tabela `Employees`.



Fişier: `src/models/index.js`



\* Importă toate modelele (Employee, User, Contact, Tag).

\* Defineşte asocierile pentru segmentul avansat:



&nbsp; \* `User.hasMany(Contact)` / `Contact.belongsTo(User)` (one‑to‑many);

&nbsp; \* `Contact.belongsToMany(Tag)` / `Tag.belongsToMany(Contact)` (many‑to‑many).

\* Exportă:



&nbsp; \* instanţa `sequelize`;

&nbsp; \* toate modelele (folosite în rute).



\### 5.3. Rutele pentru Employee (CRUD + filtrare + proiecţii)



Fişier: `src/routes/employees.js`



\* Conţine într‑un singur loc toate operaţiile asupra `Employee`:



&nbsp; \* `GET /api/employees`:



&nbsp;   \* listă completă;

&nbsp;   \* opţional:



&nbsp;     \* filtrare după `name` (`?name=...`);

&nbsp;     \* filtrare după salariu minim (`?minSalary=...`);

&nbsp;     \* proiecţie simplificată (`?simplified=true`);

&nbsp;     \* ordonare după câmp (`?sort=salary`).

&nbsp; \* `POST /api/employees` – creare.

&nbsp; \* `GET /api/employees/:id` – căutare după ID.

&nbsp; \* `PUT /api/employees/:id` – actualizare după ID.

&nbsp; \* `DELETE /api/employees/:id` – ştergere după ID.



Acest fişier este „inima” fluxului în 6 paşi. Fiecare pas din

documentaţie se referă la o subset de funcţionalitate din acest router:



\* Pasul 3: GET + POST;

\* Pasul 4: operaţii pe ID;

\* Pasul 5: filtrare;

\* Pasul 6: proiecţie + sortare.



\### 5.4. Rutele pentru relaţii (segment avansat)



Fişier: `src/routes/relationships.js`



\* Demonstrează:



&nbsp; \* one‑to‑many User–Contact cu încărcare anticipată (`include`);

&nbsp; \* many‑to‑many Contact–Tag;

&nbsp; \* export de date în format JSON „plat” (users, contacts, tags, contactTags).

\* Expune endpoint‑uri de forma:



&nbsp; \* `GET /api/relationships/users-with-contacts`

&nbsp; \* `GET /api/relationships/contacts-with-tags`

&nbsp; \* `GET /api/relationships/export-json`



Această parte se conectează direct la ideile din documentul

„Sequelize ORM Relationships” (asocieri, eager loading, import/export). 



---



\## 6. Arhitectura documentaţiei (port 3000)



Fişier: `src/server/docs-server.js`



\* Creează un server Express minimalist care serveşte conţinutul din

&nbsp; folderul `public/`.



Fişiere în `public/`:



\* `styles.css` – stilizare minimalistă pentru text, navigaţie şi liste.

\* `index.html` – portalul central al seminarului:



&nbsp; \* secţiune cu linkuri către fiecare pas (1–6);

&nbsp; \* link către segmentul avansat (relaţii);

&nbsp; \* link către pagina despre Postman.

\* `steps/step1.html` … `steps/step6.html` – pagini dedicate fiecărui pas,

&nbsp; cu structură unitară:



&nbsp; \* „Ce scriem”;

&nbsp; \* „Ce face codul”;

&nbsp; \* „Ce exemplificăm şi de ce”;

&nbsp; \* „Testare cu Postman”.

\* `segment9-relationships.html` – sinteză textuală a relaţiilor

&nbsp; one‑to‑many / many‑to‑many şi a interogărilor cu eager loading.

\* `postman.html` – ghid practic pentru configurarea şi utilizarea Postman

&nbsp; în contextul acestui seminar.



Rolul acestui server este pur pedagogic: el nu implementează logică de

business, ci oferă suport narativ şi conceptual pentru codul din `src/`.



---



\## 7. Cele 6 etape ale seminarului (rezumat)



1\. \*\*Pasul 1 – Conectarea la baza de date\*\*



&nbsp;  \* Configurăm Sequelize + SQLite.

&nbsp;  \* Verificăm conexiunea prin `sequelize.authenticate()` şi endpoint‑ul

&nbsp;    `GET /health`.



2\. \*\*Pasul 2 – Definirea entităţii Employee\*\*



&nbsp;  \* Definim modelul `Employee` cu câmpurile de bază.

&nbsp;  \* Introducem `salary` cu valoare implicită 0 şi validare minim 0.

&nbsp;  \* Sincronizăm modelul cu baza de date prin `sequelize.sync()`.



3\. \*\*Pasul 3 – GET / POST pentru Employee\*\*



&nbsp;  \* Implementăm `GET /api/employees` şi `POST /api/employees`.

&nbsp;  \* Adăugăm validare pentru lungimea numelui (3–10 caractere).

&nbsp;  \* Testăm fluxul complet folosind Postman (listare + creare).



4\. \*\*Pasul 4 – Operaţii bazate pe ID\*\*



&nbsp;  \* Adăugăm `GET /api/employees/:id`, `PUT /api/employees/:id` şi

&nbsp;    `DELETE /api/employees/:id`.

&nbsp;  \* Discutăm codurile HTTP de răspuns şi tratarea cazului „not found”.



5\. \*\*Pasul 5 – Selecţii (filtrare)\*\*



&nbsp;  \* Extindem `GET /api/employees` cu parametri de query:



&nbsp;    \* `name` – filtrare după nume;

&nbsp;    \* `minSalary` – filtrare după salariu minim.

&nbsp;  \* Introducem clauza `where` şi operatorii `LIKE`, `>=`.



6\. \*\*Pasul 6 – Proiecţii şi ordonare\*\*



&nbsp;  \* Adăugăm parametrul `simplified=true` pentru a selecta doar un subset de

&nbsp;    câmpuri (proiecţie).

&nbsp;  \* Adăugăm parametrul `sort` (de ex. `sort=salary`) pentru ordonarea

&nbsp;    rezultatelor.

&nbsp;  \* Combinăm filtrarea, proiecţia şi ordonarea într‑un singur endpoint GET.



---



\## 8. Utilizarea Postman



Fişierul `public/postman.html` descrie în detaliu paşii, dar putem rezuma

aici ideile principale:



1\. \*\*Crearea unei colecţii „Seminar 9 – ORM”\*\* în Postman.

2\. \*\*Definirea unei variabile `baseUrl`\*\* (de exemplu

&nbsp;  `http://localhost:3001`) pentru a evita repetarea adresei.

3\. \*\*Crearea de request‑uri\*\* pentru fiecare pas:



&nbsp;  \* Step 1: `GET {{baseUrl}}/health`

&nbsp;  \* Step 3: `GET {{baseUrl}}/api/employees`, `POST {{baseUrl}}/api/employees`

&nbsp;  \* Step 4: `GET / PUT / DELETE {{baseUrl}}/api/employees/:id`

&nbsp;  \* Step 5: `GET {{baseUrl}}/api/employees?name=...` etc.

&nbsp;  \* Step 6: `GET {{baseUrl}}/api/employees?simplified=true\&sort=salary`

4\. \*\*Interpretarea răspunsurilor\*\*:



&nbsp;  \* coduri de status (`200`, `201`, `400`, `404`, `500`);

&nbsp;  \* structură JSON (liste vs. obiecte individuale);

&nbsp;  \* mesaje de eroare în caz de validare eşuată.



Postman este, astfel, atât un instrument de testare, cât şi o unealtă

didactică pentru ilustrarea protocolului HTTP şi a contractului dintre

client şi server.



---



\## 9. Segmentul avansat: relaţii şi eager loading



Pe baza acestui starterkit, se poate introduce un segment suplimentar

(în acelaşi proiect sau într‑unul derivat) în care:



\* se definesc modele suplimentare (`User`, `Contact`, `Tag`);

\* se construiesc relaţii:



&nbsp; \* `User.hasMany(Contact)` / `Contact.belongsTo(User)` (one‑to‑many);

&nbsp; \* `Contact.belongsToMany(Tag)` / `Tag.belongsToMany(Contact)` (many‑to‑many);

\* se utilizează `include` pentru <em>eager loading</em>:



&nbsp; \* utilizatori cu toate contactele lor;

&nbsp; \* contacte cu toate tag‑urile asociate;

\* se exportă structuri de date în format JSON, fie „plate” (liste separate

&nbsp; pentru fiecare tabelă), fie ierarhizate (utilizatori cu contacte şi tag‑uri).



Aceste idei sunt detaliate în prezentarea „Sequelize ORM Relationships” şi

pot fi discutate după ce studenţii stăpânesc fluxul CRUD de bază prezentat

în paşii 1–6. 



---



\## 10. Concluzie



Proiectul de faţă îşi propune să fie, în acelaşi timp:



\* un exemplu tehnic minimal, dar complet, de utilizare a Sequelize cu SQLite;

\* un suport de curs interactiv, în care putem „vedea” fiecare pas atât în

&nbsp; cod, cât şi în documentaţia servită pe portul 3000;

\* o bază pentru extindere către scenarii mai complexe (relaţii între

&nbsp; entităţi, import/export, testare automată etc.).



Recomandare de lectură pentru studenţi: să parcurgă, în paralel,

fişierele din `src/` şi paginile corespunzătoare din `public/steps/`,

testând fiecare etapă cu Postman şi observând legătura strânsă dintre

model, rută şi răspunsul HTTP.



```

::contentReference\[oaicite:3]{index=3}

```













