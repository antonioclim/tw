# 01 – Selectori bazici

Să facem · Rulăm · Observăm · Exercițiu în README extins din rădăcină.
