# S6 – Starter Kit (Pașii 1–6 + 04b): Selectori CSS & Layout

Acest pachet conține **7 exemple** (01–06 + 04b), fiecare cu fișierele necesare (HTML/CSS și, unde e cazul, JS) și un `README.md` scurt.
Structura urmează seminarul „Selectori CSS și Layout” (Bloom: **înțelegere → aplicare → analiză**).

## Cum rulezi rapid
1. Deschide folderul în **VS Code**.
2. Instalează extensia **Live Server** (dacă nu o ai).
3. Intră în oricare dintre subfolderele `01`–`06` sau `04b`, deschide `index.html` și folosește **Open with Live Server**.
4. În **Firefox**, apasă **F12** → *Inspector*, *Rules/Computed*, *Layout (Box Model)*; activează `:hov` pentru a forța **:hover/:focus**.

## Conținut (pe scurt)
- `01-selectori-bazici/` – Selectori de tip, descendență, ID, clasă; `::before`/`::after` pe titlu/footer (cascadă & specificitate).
- `02-pseudoclase-pseudoelemente/` – `:hover`, `:focus`, `:required`, `::first-line` (opțional `::first-letter`).
- `03-tabele-nth-child-css-vs-js/` – Alternare rânduri cu `:nth-child` (CSS pur) **vs** varianta prin JS (stil inline) – contrast metodologic.
- `04-layout-sidebar-fix/` – Sidebar fix ( `position: fixed` ) + conținut principal cu `margin-left` (ancore, scroll).
- `04b-float-tictactoe/` – **Grid 3×3** construit exclusiv cu **`float`** + **clearfix** (tic‑tac‑toe). Linii centrale îngroșate cu `:nth-child`.  
  **De ce 04b?** Arată tehnica „istorică” bazată pe float și comportamentul containerelor fără/cu clearfix. În practică modernă preferăm **Flex**/**Grid**; 04b rămâne util pentru **înțelegerea fluxului** și a efectelor `float`.
- `05-formular-login/` – Selectori de atribute `input[type=...]`, box model coerent, butoane, focus vizibil; `float` punctual pentru aliniere.
- `06-meniu-vertical/` – Meniu pe listă (`ul/li`) cu pseudo-clase pentru link-uri (`:link/:visited/:hover/:active/:focus`).

## Ce să urmărești în DevTools (orientativ)
- **Inspector → Rules/Computed**: ordinea regulilor, suprascrieri, stări forțate (`:hov`).
- **Layout (Box Model)**: efectul `box-sizing: border-box` pe lățimi/înălțimi (01, 05), sumarul padding/border/margin.
- **Float & Clearfix (04b)**: debifează `float:left` la `.cell` → cele 9 div-uri devin stivuite vertical; elimină pseudo-elementul `::after` (clearfix) → containerul `.board` nu‑și mai cuprinde copiii flotanți.
- **Positioning (04)**: debifează temporar `position: fixed` pe `.sidebar` ca să vezi diferența față de fluxul normal.
- **Pseudo-clase**: activează `:hover`/`:focus` la buton/inputs (02), respectiv la link-uri (06).

## Întrebări rapide (auto‑verificare)
1. Ce diferență practică vezi între **04** (fixed) și **04b** (float) în raport cu fluxul documentului?
2. Când este suficient CSS pur (`:nth-child`) și când ai nevoie de JS pentru stilizare/logică dinamică (03)?
3. De ce `border-box` simplifică layout-ul în formulare (05) și componente?

---

**Changelog:**  
- *v1.2* – actualizat `README.md` pentru inserarea `04b` (detalii + întrebări rapide).  
- *v1.1* – adăugat `04b-float-tictactoe/`.  
- *v1.0* – versiune inițială (01–06).
