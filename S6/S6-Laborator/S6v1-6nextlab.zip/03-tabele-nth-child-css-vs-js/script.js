(function(){const rows=document.querySelectorAll('#jsTable tbody tr');rows.forEach((tr,i)=>{if(i%2===0)tr.style.backgroundColor='#ffe0e0'});
const r=document.querySelectorAll('#jsTable tbody tr');if(r.length){r[0].style.backgroundColor='#99ccff';r[r.length-1].style.backgroundColor='#b3ffb3'}})();
