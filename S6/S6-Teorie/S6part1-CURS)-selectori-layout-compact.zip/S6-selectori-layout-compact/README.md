# Compact Kit — Selectori CSS & Layout (curated)

Această arhivă conține **doar fișierele recomandate** pentru seminarul „Selectori CSS și Layout”, extrase din:
- `tw-curs-2024-AT.zip` → în subfolderul `curs/`
- `tw-sem-2024-AT.zip` → în subfolderul `sem/`

## Cum rulezi
1. Deschide în VS Code și folosește **Live Server**, sau deschide fiecare `.html` direct în browser.
2. Pentru fișierele din `curs/tw-live-2024-main/c4/css/`, dacă pagina leagă un CSS relativ `css/*.css`, acesta este inclus în `curs/tw-live-2024-main/c4/css/css/`.

## Conținut (mapare scurtă)
- **Selectori – curs (`curs/tw-live-2024-main/c4/css/`)**: 5.html, 6.html, 7.html, 8.html, 9.html, 10.html, 11.html, 12.html, 14.html, 14.1.html (+ CSS relevante în `css/`).
- **Layout – curs (`curs/tw-live-2024-main/c4/css/`)**: 16.html, 17.html, 18.html, 19.html, 20.html, 21.html, 22.html (+ CSS relevante în `css/`).
- **Selectori & Layout – seminar (`sem/webtech-2024-1108-main/`)**:
  - `wk5/`: ex1.html, ex2.html, ex3.html, sol3.html, ex4.html, ex4-modern.html, ex5.html, sol4.html
  - `wk6/`: ex1.html, ex1-sol.html, ex2.html, ex3.html, ex3-sol.html, ex4.html

## Notă
Structura internă a subfolderelor a fost păstrată pentru a nu rupe referințele relative către fișiere CSS.
