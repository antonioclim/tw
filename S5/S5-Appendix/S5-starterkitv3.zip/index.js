// index.js – punct de intrare
require('./server');
