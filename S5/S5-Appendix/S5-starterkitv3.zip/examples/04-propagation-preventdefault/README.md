# 04 – Propagare & `preventDefault`

**Idee:** arată cum „bulele” de eveniment urcă prin DOM și cum pot fi oprite; arată prevenirea comportamentului implicit.

**Pași:**
1. Deschideți `http://localhost:8080/04-propagation-preventdefault/`.
2. Click pe d3 → d2 → d1; observați jurnalul evenimentelor.
3. Click pe link – nu se navighează, evenimentul e „consumat”.
