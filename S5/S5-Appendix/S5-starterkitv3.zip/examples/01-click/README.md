# 01 – Eveniment click (de bază)

**Idee:** demonstrează atașarea unui handler prin `addEventListener('click', ...)` și actualizarea DOM-ului cu `textContent`.

**Pași:**
1. Deschideți în browser: `http://localhost:8080/01-click/`.
2. Apăsați butonul; observați cum mesajul este actualizat în `<div id="out">`.
