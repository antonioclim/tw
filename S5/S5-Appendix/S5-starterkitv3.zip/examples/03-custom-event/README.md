# 03 – Eveniment personalizat

**Idee:** se atașează un handler pe un eveniment inventat (`alarm`) și se dispecerizează cu `dispatchEvent(...)`.

**Pași:**
1. Deschideți `http://localhost:8080/03-custom-event/`.
2. Click pe „Declanșează alarm” – observați efectul vizual și mesajul.
