# 07 – PUT/DELETE

**Idee:** finalizarea CRUD: actualizare cu `PUT /api/cats/:id` și ștergere cu `DELETE /api/cats/:id`.

**Pași:**
1. Deschideți `http://localhost:8080/07-put-delete/`.
2. Modificați numele și salvați; apoi încercați ștergerea.

**Notă:** La lansare, în terminal vedeți mesajul **API is running**. Endpoint de sănătate: `/health` sau `/api/health`.
