# 05 – Agendă DOM

**Idee:** creare, inserare și eliminare de noduri DOM (`createElement`, `appendChild`, `remove`).

**Pași:**
1. Deschideți `http://localhost:8080/05-dom-agenda/`.
2. Adăugați contacte; folosiți butonul „Șterge” pentru eliminare.
