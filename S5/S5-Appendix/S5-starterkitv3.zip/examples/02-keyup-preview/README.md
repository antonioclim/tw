# 02 – Tastare & previzualizare

**Idee:** ascultă `keyup` pe un `<input>` și reflectă valoarea în DOM, în timp real.

**Pași:**
1. Deschideți `http://localhost:8080/02-keyup-preview/`.
2. Tastați – previzualizarea se actualizează la fiecare eveniment `keyup`.
