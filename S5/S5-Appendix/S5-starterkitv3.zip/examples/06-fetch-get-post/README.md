# 06 – fetch GET/POST

**Idee:** consum de API REST (Express) din browser. Afișare listă (GET) și adăugare element (POST).

**Pași:**
1. Deschideți `http://localhost:8080/06-fetch-get-post/` (după pornirea serverului).
2. Reîncărcați lista, apoi adăugați o pisică; lista se actualizează.

**Notă:** La lansare, în terminal vedeți mesajul **API is running**. Endpoint de sănătate: `/health` sau `/api/health`.
