import http from 'node:http';
import app from './server.js';

const PORT = process.env.PORT ?? 8080;
const server = http.createServer(app);
server.listen(PORT, () => {
  console.log(`API is running at http://localhost:${PORT}`);
  console.log(`Health:           http://localhost:${PORT}/api/health`);
});
