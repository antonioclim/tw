# S5 – Starter kit DOM & Evenimente (v4)

**Ce include**
- Server Express (ESM) pe `http://localhost:8080`
- Ruta `GET /api/health` și banner UI care confirmă starea API
- API REST demonstrativ `GET/POST/PUT/DELETE /api/cats` (persistență în `data/cats.json`)
- 7 exemple front‑end (JS nativ) despre DOM & evenimente (+ fetch)
- README‑uri și cod curate, ușor de rulat pe Windows/VS Code

## 1) Cerințe
- Node.js **18+** (recomandat 20 LTS)
- PowerShell / VS Code

## 2) Instalare & rulare (Windows/PowerShell)
```powershell
npm install
npm start
```
Vezi în consolă:
```
API is running at http://localhost:8080
Health:           http://localhost:8080/api/health
```

## 3) Exemplarează
Deschide `http://localhost:8080/` și alege (afișare **verticală**):
- `/01-dom-basics/` – selecție și inserare DOM
- `/02-events/` – click & keyup
- `/03-delegation/` – delegarea evenimentelor
- `/04-custom-event/` – `CustomEvent` + `dispatchEvent`
- `/05-form-prevent/` – form + `preventDefault`
- `/06-fetch-get-post/` – GET listă + POST creare
- `/07-put-delete/` – PUT actualizare + DELETE ștergere

## 4) API
- `GET /api/health` – status, uptime și versiune
- `GET /api/cats` – array `{id, name}`
- `POST /api/cats` body: `{ "name": "Luna" }` → `201 Created`
- `PUT /api/cats/:id` body: `{ "name": "Nou" }`
- `DELETE /api/cats/:id` → `204 No Content`
- `POST /api/cats/seed` – reinițializează cu 2 intrări

Persistența este în fișier (`data/cats.json`).

## 5) Soluționare probleme
- **EJSONPARSE / package.json invalid** – JSON strict (fără virgule la final, fără comentarii).
- **[MODULE_TYPELESS_PACKAGE_JSON]** – rezolvat prin `"type": "module"`.
- **Port 8080 ocupat**:
  ```powershell
  netstat -ano | findstr :8080
  taskkill /PID <pid> /F
  ```
- **Import local în ESM** – folosește extensia `.js` în importuri: `import app from './server.js'`.

## 6) Scripturi
- `npm start` – pornește serverul
- `npm run dev` – pornește cu nodemon (reîncărcare la salvare)
