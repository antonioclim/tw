import express from 'express';
import path from 'node:path';
import fs from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'examples')));

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', version: '1.3.0', uptime: process.uptime(), timestamp: new Date().toISOString() });
});
app.get('/health', (_req, res) => res.redirect('/api/health'));

const DATA_DIR = path.join(__dirname, 'data');
const CATS_FILE = path.join(DATA_DIR, 'cats.json');
async function ensureFile(){ await fs.mkdir(DATA_DIR, {recursive:true}); try{ await fs.access(CATS_FILE); } catch{ await fs.writeFile(CATS_FILE, JSON.stringify([{id:1,name:'Miti'},{id:2,name:'Tom'}], null, 2)); } }
async function loadCats(){ await ensureFile(); return JSON.parse(await fs.readFile(CATS_FILE, 'utf-8')); }
async function saveCats(c){ await fs.writeFile(CATS_FILE, JSON.stringify(c, null, 2)); }

app.get('/api/cats', async (_req,res)=>{ res.json(await loadCats()); });
app.post('/api/cats', async (req,res)=>{ const {name} = req.body||{}; if(!name||!name.trim()) return res.status(400).json({error:'Numele este obligatoriu.'}); const cats = await loadCats(); const nextId = cats.length? Math.max(...cats.map(x=>x.id))+1:1; const item={id:nextId,name:name.trim()}; cats.push(item); await saveCats(cats); res.status(201).json(item); });
app.put('/api/cats/:id', async (req,res)=>{ const id = Number(req.params.id); const {name}=req.body||{}; if(!Number.isInteger(id)) return res.status(400).json({error:'ID invalid.'}); if(!name||!name.trim()) return res.status(400).json({error:'Numele este obligatoriu.'}); const cats = await loadCats(); const i=cats.findIndex(c=>c.id===id); if(i===-1) return res.status(404).json({error:'Element inexistent.'}); cats[i].name=name.trim(); await saveCats(cats); res.json(cats[i]); });
app.delete('/api/cats/:id', async (req,res)=>{ const id=Number(req.params.id); const cats=await loadCats(); const i=cats.findIndex(c=>c.id===id); if(i===-1) return res.status(404).json({error:'Element inexistent.'}); cats.splice(i,1); await saveCats(cats); res.status(204).end(); });
app.post('/api/cats/seed', async (_req,res)=>{ const seed=[{id:1,name:'Miti'},{id:2,name:'Tom'}]; await saveCats(seed); res.json({ok:true,count:seed.length}); });

app.get('/', (_req,res)=>{ res.sendFile(path.join(__dirname,'examples','index.html')); });

export default app;
