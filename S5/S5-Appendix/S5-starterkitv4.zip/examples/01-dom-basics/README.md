# 01 – DOM basics
- **Obiectiv:** selectarea elementelor și inserarea de noduri create cu `document.createElement`.
- **Ce să observi:** `appendChild`, `replaceChildren`; input focus workflow.
