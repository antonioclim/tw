# 07 – PUT/DELETE
- **GET**: `/api/cats` → randează rânduri editabile.
- **PUT**: `/api/cats/:id` cu body `{ "name": "..." }` → salvează modificarea.
- **DELETE**: `/api/cats/:id` → `204 No Content`, reîncarcă lista.
