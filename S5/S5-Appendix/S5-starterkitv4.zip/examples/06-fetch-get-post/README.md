# 06 – fetch GET/POST
- **GET**: `/api/cats` → listează pisicile.
- **POST**: `/api/cats` body JSON `{ "name": "Luna" }` → inserează și reîncarcă lista.
- Butonul **Seed** reinițializează datele (POST `/api/cats/seed`).
