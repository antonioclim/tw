# Unelte SQLite în S10vDEMO

Acest laborator include trei utilitare oficiale SQLite (versiune Windows, 64‑bit), plasate în folderul:

```text
tools/sqlite/
```

## 1. sqlite3.exe – shell-ul interactiv

`sqlite3.exe` este clientul de linie de comandă pentru SQLite. El permite:

- rularea interactivă de comenzi SQL;
- folosirea comenzilor „dot” (`.tables`, `.schema`, `.dump`, etc.);
- exportul datelor în diverse formate (CSV, listă, HTML).

Exemplu de utilizare cu baza `demo.db`:

```bat
cd \calea\spre\S10vDEMO-lab
tools\sqlite\sqlite3.exe demo.db

sqlite> .tables
sqlite> .schema Students
sqlite> SELECT * FROM Students;
sqlite> .quit
```

Logica internă este cea descrisă în documentația oficială `shell.c`: un REPL care distinge între
comenzi care încep cu punct (dot-commands) și instrucțiuni SQL trimise motorului SQLite. fileciteturn0file1L18-L28

## 2. sqldiff.exe – motor de diferențe între baze

`sqldiff.exe` compară două fișiere `.db` și generează un script SQL cu diferențele necesare pentru
a transforma baza A în baza B. Algoritmul:

- compară mai întâi schema (tabele, indecși, view‑uri);
- apoi parcurge rândurile (după `rowid` sau cheia primară) și generează `INSERT` / `UPDATE` /
  `DELETE` pentru rândurile care diferă. fileciteturn0file1L70-L83

Pentru baze mari, el folosește un mecanism de hashing incremental asupra BLOB‑urilor pentru a evita
încărcarea întregului fișier în memorie.

Exemplu de utilizare:

```bat
copy demo.db demo-before.db
REM ... modifici baza prin API / Postman ...
copy demo.db demo-after.db

tools\sqlite\sqldiff.exe demo-before.db demo-after.db > diff.sql
```

Fișierul `diff.sql` poate fi analizat sau aplicat cu `sqlite3.exe`.

## 3. sqlite3_analyzer.exe – analiză fizică a fișierului

`sqlite3_analyzer.exe` este un „container” C + Tcl: codul C pornește un interpretor Tcl și rulează
un script intern (`spaceanal.tcl`) care interoghează tabela virtuală `dbstat` pentru a raporta:

- numărul și mărimea paginilor;
- gradul de fragmentare;
- eficiența utilizării spațiului pe disc. fileciteturn0file1L112-L126

Arhitectura de tip „executabil care conține un script” poate genera uneori alerte false în antivirus,
dar aceasta este metoda standard prin care proiectul SQLite distribuie unealta ca fișier unic. fileciteturn0file1L128-L143

Exemplu de utilizare:

```bat
cd \calea\spre\S10vDEMO-lab
tools\sqlite\sqlite3_analyzer.exe demo.db > analyzer-demo.txt
```

Raportul text rezultat poate fi discutat în laborator pentru a evidenția legătura dintre modele
ORM și reprezentarea fizică pe disc.

## 4. Verificarea integrității executabilelor

Executabilele sunt copiate direct din distribuția oficială SQLite. Pentru verificare suplimentară
se pot calcula hash‑uri (de exemplu SHA3‑256) și compara cu valorile publicate pe site‑ul
proiectului SQLite. fileciteturn0file1L145-L166

Deoarece sunt utilitare de linie de comandă, ele nu au dependențe externe și nu necesită instalare;
pot fi șterse oricând dacă nu mai sunt necesare sau dacă politica de laborator o cere.
