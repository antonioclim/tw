const express = require('express');
const path = require('path');
const { spawn } = require('child_process');
const {
  sequelize,
  University,
  Student,
  Course,
  Enrollment
} = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Servire pagini HTML statice din /web
app.use(express.static(path.join(__dirname, 'web')));

// ---------- 1. SEED DEMO DATA ----------

async function seedDemoData() {
  await sequelize.sync({ force: true });

  const [upb, uvt] = await Promise.all([
    University.create({ name: 'UPB', city: 'București' }),
    University.create({ name: 'UVT', city: 'Timișoara' })
  ]);

  const [ana, mihai, ioana, dan] = await Promise.all([
    Student.create({ firstName: 'Ana',   lastName: 'Ionescu',  universityId: upb.id }),
    Student.create({ firstName: 'Mihai', lastName: 'Popescu',  universityId: upb.id }),
    Student.create({ firstName: 'Ioana', lastName: 'Dobre',    universityId: uvt.id }),
    Student.create({ firstName: 'Dan',   lastName: 'Georgescu',universityId: uvt.id })
  ]);

  const [tw, bd, ia] = await Promise.all([
    Course.create({ title: 'Tehnologii Web',    semester: 'Sem I',  universityId: upb.id }),
    Course.create({ title: 'Baze de date',      semester: 'Sem I',  universityId: upb.id }),
    Course.create({ title: 'Introducere în AI', semester: 'Sem II', universityId: uvt.id })
  ]);

  await Promise.all([
    ana.addCourse(tw, { through: { grade: '10' } }),
    ana.addCourse(bd, { through: { grade: '9' } }),
    mihai.addCourse(bd, { through: { grade: '8' } }),
    ioana.addCourse(tw, { through: { grade: '9' } }),
    dan.addCourse(ia, { through: { grade: '10' } })
  ]);
}

// Endpoint de resetare/seed explicită
app.get('/api/demo/reset', async (req, res) => {
  try {
    await seedDemoData();
    res.json({
      message: 'Baza demo a fost resetată și populată cu universități, studenți, cursuri și înscrieri.'
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Eroare la resetarea demo-ului.' });
  }
});

// ---------- 2. API – RELAȚII ORM ----------

// 2.1 Universități + studenți (one-to-many + include)

app.get('/api/universities', async (req, res) => {
  try {
    const universities = await University.findAll({ include: [Student, Course] });
    res.json(universities);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Eroare la citirea universităților.' });
  }
});

app.post('/api/universities', async (req, res) => {
  try {
    const { name, city } = req.body;
    if (!name || !city) {
      return res.status(400).json({ error: 'Câmpurile name și city sunt obligatorii.' });
    }
    const uni = await University.create({ name, city });
    res.status(201).json(uni);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Eroare la creare universitate.' });
  }
});

app.get('/api/universities/:id/students', async (req, res) => {
  try {
    const { id } = req.params;
    const university = await University.findByPk(id, { include: Student });
    if (!university) {
      return res.status(404).json({ error: 'Universitate inexistentă.' });
    }
    res.json({
      university: {
        id: university.id,
        name: university.name,
        city: university.city
      },
      students: university.Students
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Eroare la citirea studenților universității.' });
  }
});

app.post('/api/universities/:id/students', async (req, res) => {
  try {
    const { id } = req.params;
    const { firstName, lastName } = req.body;
    const university = await University.findByPk(id);
    if (!university) {
      return res.status(404).json({ error: 'Universitate inexistentă.' });
    }
    if (!firstName || !lastName) {
      return res.status(400).json({ error: 'firstName și lastName sunt obligatorii.' });
    }
    const student = await Student.create({
      firstName,
      lastName,
      universityId: university.id
    });
    res.status(201).json(student);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Eroare la creare student.' });
  }
});

// 2.2 Studenți + universitate + cursuri (include, many-to-many)

app.get('/api/students', async (req, res) => {
  try {
    const students = await Student.findAll({ include: [University, Course] });
    res.json(students);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Eroare la citirea studenților.' });
  }
});

app.get('/api/students/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const student = await Student.findByPk(id, { include: [University, Course] });
    if (!student) {
      return res.status(404).json({ error: 'Student inexistent.' });
    }
    res.json(student);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Eroare la citirea studentului.' });
  }
});

app.put('/api/students/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { firstName, lastName } = req.body;
    const student = await Student.findByPk(id);
    if (!student) {
      return res.status(404).json({ error: 'Student inexistent.' });
    }
    if (firstName) student.firstName = firstName;
    if (lastName)  student.lastName  = lastName;
    await student.save();
    res.json(student);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Eroare la actualizarea studentului.' });
  }
});

app.delete('/api/students/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const student = await Student.findByPk(id);
    if (!student) {
      return res.status(404).json({ error: 'Student inexistent.' });
    }
    await student.destroy();
    res.status(204).send();
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Eroare la ștergerea studentului.' });
  }
});

// 2.3 Many-to-many: studenți <-> cursuri

app.get('/api/courses', async (req, res) => {
  try {
    const courses = await Course.findAll({ include: Student });
    res.json(courses);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Eroare la citirea cursurilor.' });
  }
});

app.get('/api/students/:id/courses', async (req, res) => {
  try {
    const { id } = req.params;
    const student = await Student.findByPk(id, { include: Course });
    if (!student) {
      return res.status(404).json({ error: 'Student inexistent.' });
    }
    res.json({
      student: {
        id: student.id,
        firstName: student.firstName,
        lastName: student.lastName
      },
      courses: student.Courses
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Eroare la citirea cursurilor studentului.' });
  }
});

app.post('/api/students/:id/courses/:courseId', async (req, res) => {
  try {
    const { id, courseId } = req.params;
    const { grade } = req.body || {};
    const student = await Student.findByPk(id);
    const course = await Course.findByPk(courseId);
    if (!student || !course) {
      return res.status(404).json({ error: 'Student sau curs inexistent.' });
    }
    await Enrollment.create({
      studentId: student.id,
      courseId: course.id,
      grade: grade || null
    });
    res.status(201).json({ message: 'Student înscris la curs.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Eroare la înscrierea studentului la curs.' });
  }
});

// 2.4 Import / export JSON

app.get('/api/export', async (req, res) => {
  try {
    const [universities, students, courses, enrollments] = await Promise.all([
      University.findAll({ raw: true }),
      Student.findAll({ raw: true }),
      Course.findAll({ raw: true }),
      Enrollment.findAll({ raw: true })
    ]);
    res.json({ universities, students, courses, enrollments });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Eroare la exportul datelor.' });
  }
});

app.post('/api/import', async (req, res) => {
  try {
    const { universities, students, courses, enrollments } = req.body;
    if (!universities || !students || !courses || !enrollments) {
      return res.status(400).json({
        error: 'Body-ul trebuie să conțină universities, students, courses, enrollments.'
      });
    }
    await sequelize.sync({ force: true });
    await University.bulkCreate(universities);
    await Course.bulkCreate(courses);
    await Student.bulkCreate(students);
    await Enrollment.bulkCreate(enrollments);
    res.json({ message: 'Import realizat cu succes.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Eroare la importul datelor.' });
  }
});

// ---------- 3. WRAPPER PENTRU SQLITE.EXE / SQLDIFF / SQLITE3_ANALYZER ----------

const SQLITE_DIR = path.join(__dirname, 'tools', 'sqlite');

function isSafePath(p) {
  // acceptăm doar căi relative simple, fără drive-uri sau ".."
  if (!p) return false;
  if (p.includes('..')) return false;
  if (p.includes(':')) return false;
  if (p.startsWith('/') || p.startsWith('\\')) return false;
  return true;
}

function runTool(exeName, args, res) {
  const exePath = path.join(SQLITE_DIR, exeName);

  const child = spawn(exePath, args, {
    cwd: SQLITE_DIR
  });

  let stdout = '';
  let stderr = '';

  child.stdout.on('data', chunk => {
    stdout += chunk.toString('utf-8');
  });
  child.stderr.on('data', chunk => {
    stderr += chunk.toString('utf-8');
  });

  child.on('error', err => {
    console.error(err);
    res.status(500).json({ error: 'Nu pot porni utilitarul SQLite.', details: err.message });
  });

  child.on('close', code => {
    if (code !== 0 && stderr) {
      res.status(500).json({ error: 'Utilitarul SQLite a returnat o eroare.', code, stderr });
    } else {
      res.type('text/plain').send(stdout || stderr || `Proces încheiat cu codul ${code}.`);
    }
  });
}

// Listează tabelele dintr-o bază
app.get('/tools/sqlite3/tables', (req, res) => {
  const { db } = req.query;
  if (!isSafePath(db)) {
    return res.status(400).json({ error: 'Parametrul db trebuie să fie o cale relativă sigură.' });
  }
  const dbPath = path.join('..', '..', db); // din tools/sqlite înapoi la rădăcina laboratorului
  runTool('sqlite3.exe', [dbPath, '.tables'], res);
});

// Schema completă
app.get('/tools/sqlite3/schema', (req, res) => {
  const { db } = req.query;
  if (!isSafePath(db)) {
    return res.status(400).json({ error: 'Parametrul db trebuie să fie o cale relativă sigură.' });
  }
  const dbPath = path.join('..', '..', db);
  runTool('sqlite3.exe', [dbPath, '.schema'], res);
});

// Interogare arbitrară
app.post('/tools/sqlite3/query', (req, res) => {
  const { db, sql } = req.body || {};
  if (!isSafePath(db) || typeof sql !== 'string' || !sql.trim()) {
    return res.status(400).json({ error: 'Trebuie trimise db (cale relativă sigură) și sql (string nevid).' });
  }
  const dbPath = path.join('..', '..', db);
  runTool('sqlite3.exe', [dbPath, sql], res);
});

// Diferențe între două baze (sqldiff)
app.get('/tools/sqldiff', (req, res) => {
  const { db1, db2 } = req.query;
  if (!isSafePath(db1) || !isSafePath(db2)) {
    return res.status(400).json({ error: 'Parametrii db1 și db2 trebuie să fie căi relative sigure.' });
  }
  const dbPath1 = path.join('..', '..', db1);
  const dbPath2 = path.join('..', '..', db2);
  runTool('sqldiff.exe', [dbPath1, dbPath2], res);
});

// Analyzer pentru o bază
app.get('/tools/sqlite3_analyzer', (req, res) => {
  const { db } = req.query;
  if (!isSafePath(db)) {
    return res.status(400).json({ error: 'Parametrul db trebuie să fie o cale relativă sigură.' });
  }
  const dbPath = path.join('..', '..', db);
  runTool('sqlite3_analyzer.exe', [dbPath], res);
});

// ---------- PORNIRE SERVER ----------

async function start() {
  try {
    await seedDemoData();
    app.listen(PORT, () => {
      console.log(`S10vDEMO – laborator separat pornit pe http://localhost:${PORT}`);
      console.log('Pagini HTML: / (index), /demo-api.html, /postman.html, /sqlite-tools.html');
      console.log('API demo REST: prefix /api/ ...');
      console.log('Wrapper unelte SQLite: prefix /tools/... ');
    });
  } catch (err) {
    console.error('Eroare la pornirea serverului:', err);
    process.exit(1);
  }
}

start();
