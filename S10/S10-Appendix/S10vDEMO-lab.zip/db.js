const { Sequelize, DataTypes } = require('sequelize');

// Conexiune Sequelize spre fișierul demo.db din directorul curent
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: 'demo.db',
  logging: false
});

// MODELE

const University = sequelize.define('University', {
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  city: {
    type: DataTypes.STRING,
    allowNull: false
  }
});

const Student = sequelize.define('Student', {
  firstName: {
    type: DataTypes.STRING,
    allowNull: false
  },
  lastName: {
    type: DataTypes.STRING,
    allowNull: false
  }
});

const Course = sequelize.define('Course', {
  title: {
    type: DataTypes.STRING,
    allowNull: false
  },
  semester: {
    type: DataTypes.STRING,
    allowNull: false
  }
});

const Enrollment = sequelize.define('Enrollment', {
  grade: {
    type: DataTypes.STRING,
    allowNull: true
  }
});

// RELAȚII

// One-to-many: University -> Student
University.hasMany(Student, { foreignKey: 'universityId' });
Student.belongsTo(University, { foreignKey: 'universityId' });

// One-to-many: University -> Course
University.hasMany(Course, { foreignKey: 'universityId' });
Course.belongsTo(University, { foreignKey: 'universityId' });

// Many-to-many: Student <-> Course (through Enrollment)
Student.belongsToMany(Course, { through: Enrollment, foreignKey: 'studentId' });
Course.belongsToMany(Student, { through: Enrollment, foreignKey: 'courseId' });

module.exports = {
  sequelize,
  University,
  Student,
  Course,
  Enrollment
};
