# S10vDEMO – Laborator separat ORM + SQLite + unelte SQLite

Acest kit este gândit ca **laborator complet separat** față de seminarul 10 original. Poate fi
plasat oriunde pe disc (de exemplu):

```text
Z:\tw\S10vDEMO-lab
```

și rulează pe Windows 11 cu Node.js și Visual Studio Code.

---

## 1. Structura laboratorului

```text
S10vDEMO-lab/
  package.json
  server.js
  db.js
  demo.db                 # fișierul SQLite creat automat la pornire
  web/
    index.html
    demo-api.html
    postman.html
    sqlite-tools.html
  tools/
    sqlite/
      sqlite3.exe
      sqldiff.exe
      sqlite3_analyzer.exe
    README-sqlite-tools-DEMO.md
  README-DEMO.md          # acest fișier
```

- **`server.js`** – aplicație Express care:
  - servește paginile HTML din `web/` pe `http://localhost:3000`;
  - expune un API REST (`/api/...`) bazat pe Sequelize + SQLite;
  - expune un wrapper HTTP pentru utilitarele `sqlite3.exe`, `sqldiff.exe`, `sqlite3_analyzer.exe`
    (`/tools/...`).
- **`db.js`** – definește modelele Sequelize și relațiile:
  - `University`, `Student`, `Course`, `Enrollment` (tabel de legătură).
- **`demo.db`** – baza SQLite care conține datele demo (se regenerează automat la start).
- **`web/*.html`** – pagini de suport pentru laborator:
  - `index.html` – pagină de pornire;
  - `demo-api.html` – descrierea modelelor și a endpoint‑urilor;
  - `postman.html` – ghid pas cu pas pentru testarea API‑ului;
  - `sqlite-tools.html` – ghid pentru uneltele CLI + wrapper HTTP.
- **`tools/sqlite/*.exe`** – executabilele oficiale SQLite: shell interactiv, motor de diff și
  analizor de spațiu. fileciteturn0file1L10-L24

---

## 2. Cerințe preliminare

- Windows 11 (sau similar);
- Node.js instalat (LTS; de exemplu 18.x sau 20.x);
- drept de execuție pentru `.exe` (fără restricții de antivirus / SmartScreen).

---

## 3. Instalare – un singur `npm install`

1. Descarcă și dezarhivează kitul într‑un director, de exemplu:

   ```text
   Z:\tw\S10vDEMO-lab
   ```

2. Deschide un terminal (PowerShell) în directorul rădăcină al laboratorului:

   ```bat
   cd Z:\tw\S10vDEMO-lab
   ```

3. Instalează dependențele Node:

   ```bat
   npm install
   ```

   Aceasta va instala local:

   - `express` – framework HTTP;
   - `sequelize` – ORM;
   - `sqlite3` – driverul pentru SQLite. fileciteturn0file3L46-L60

---

## 4. Pornirea laboratorului

Pornește serverul unic:

```bat
cd Z:\tw\S10vDEMO-lab
npm start
```

Dacă totul este în regulă, consola va afișa, aproximativ:

```text
S10vDEMO – laborator separat pornit pe http://localhost:3000
Pagini HTML: / (index), /demo-api.html, /postman.html, /sqlite-tools.html
API demo REST: prefix /api/ ...
Wrapper unelte SQLite: prefix /tools/...
```

La pornire se întâmplă două lucruri importante:

1. `sequelize.sync({ force: true })` creează sau recreează tabelele în `demo.db`; fileciteturn0file3L160-L171  
2. funcția de seed populează baza cu:
   - două universități (UPB, UVT);
   - câțiva studenți legați de acestea;
   - câteva cursuri;
   - înscrieri many‑to‑many cu note.

---

## 5. Ce deschizi în browser

După `npm start`:

1. Deschide:

   ```text
   http://localhost:3000/
   ```

2. Vei vedea pagina **Acasă (index.html)** cu:
   - o descriere a laboratorului;
   - explicații despre cum se pornește serverul;
   - linkuri spre:
     - `API demo (ORM)` – <code>/demo-api.html</code>;
     - `Postman` – <code>/postman.html</code>;
     - `Unelte SQLite` – <code>/sqlite-tools.html</code>.

Paginile HTML sunt doar suport de curs: ele documentează ce face API‑ul și ce vei vedea în Postman
și în uneltele SQLite.

---

## 6. Modele și relații în `demo.db`

În `db.js` sunt definite următoarele modele Sequelize: fileciteturn0file2L1-L15

- `University(id, name, city)`
- `Student(id, firstName, lastName, universityId)`
- `Course(id, title, semester, universityId)`
- `Enrollment(studentId, courseId, grade)`

Relațiile:

- **one‑to‑many**:
  - `University.hasMany(Student)` și `Student.belongsTo(University)`;
  - `University.hasMany(Course)` și `Course.belongsTo(University)`;
- **many‑to‑many**:
  - `Student.belongsToMany(Course, { through: Enrollment })`;
  - `Course.belongsToMany(Student, { through: Enrollment })`. fileciteturn0file2L17-L27

Sequelize creează automat cheile externe și generează metode de conveniență (de exemplu
`student.addCourse(course)`) care inserează în tabelul de legătură. fileciteturn0file2L76-L96

---

## 7. API REST – prefix `/api/`

Prefixul tuturor endpoint‑urilor este:

```text
http://localhost:3000/api/...
```

### 7.1. Seed și verificare rapidă

- `GET /api/demo/reset` – recreează schema și reface seed‑ul.
- `GET /api/universities` – listează universitățile cu studenți și cursuri (eager loading cu `include`). fileciteturn0file2L139-L154  

### 7.2. Universități și studenți (one‑to‑many)

- `GET /api/universities` – toate universitățile, fiecare cu `Students` și `Courses`.
- `POST /api/universities` – creează universitate:

  ```json
  {
    "name": "UBB",
    "city": "Cluj-Napoca"
  }
  ```

- `GET /api/universities/:id/students` – o universitate + lista de studenți.
- `POST /api/universities/:id/students` – adaugă un student la universitate:

  ```json
  {
    "firstName": "Radu",
    "lastName": "Enache"
  }
  ```

### 7.3. Studenți (CRUD + include)

- `GET /api/students` – toți studenții, cu universitate + cursuri.
- `GET /api/students/:id` – un student, cu `University` și `Courses`.
- `PUT /api/students/:id` – actualizare parțială (ex.:

  ```json
  {
    "firstName": "Ana-Maria"
  }
  ```  

- `DELETE /api/students/:id` – ștergere student (răspuns `204 No Content` dacă reușește).

### 7.4. Many‑to‑many Student–Course

- `GET /api/courses` – toate cursurile, cu studenții înscriși;
- `GET /api/students/:id/courses` – cursurile unui student;
- `POST /api/students/:id/courses/:courseId` – înscriere la curs:

  ```json
  {
    "grade": "9"
  }
  ```

### 7.5. Import / export JSON

- `GET /api/export` – returnează:

  ```json
  {
    "universities": [ ... ],
    "students":     [ ... ],
    "courses":      [ ... ],
    "enrollments":  [ ... ]
  }
  ```

  Structura corespunde exact modelelor ORM. fileciteturn0file2L205-L233  

- `POST /api/import` – primește un JSON cu aceeași structură și recreează baza:

  ```json
  {
    "universities": [ /* obiecte University */ ],
    "students":     [ /* obiecte Student */ ],
    "courses":      [ /* obiecte Course */ ],
    "enrollments":  [ /* obiecte Enrollment */ ]
  }
  ```

---

## 8. Postman – environment și scenariu complet

1. Creează environment `S10vDEMO-local` cu:

   ```text
   baseUrl = http://localhost:3000/api
   ```

2. Creează o colecție `S10vDEMO` cu foldere:
   - „Seed + listă” (reset + universități);
   - „One‑to‑many” (universități și studenți);
   - „CRUD Student”;
   - „Many‑to‑many Student–Course”;
   - „Import/Export”.

3. În fiecare folder adaugi request‑urile descrise în paginile
   `demo-api.html` și `postman.html` (vezi și exemplele de mai sus).

Prin acest flux, studentul vede exact cum se traduce o operație Postman (HTTP) în:

- modificări în fișierul `demo.db` (vizibile cu `sqlite3.exe`);
- schimbări în scriptul de diferențe (`sqldiff.exe`);
- efecte în raportul de analiză (`sqlite3_analyzer.exe`).

---

## 9. Unelte SQLite – CLI + wrapper HTTP

Executabilele se află în `tools/sqlite/` și sunt cele oficiale: `sqlite3.exe`, `sqldiff.exe`,
`sqlite3_analyzer.exe`. fileciteturn0file0L12-L23  

### 9.1. Linia de comandă

Exemple rapide:

```bat
cd Z:\tw\S10vDEMO-lab
tools\sqlite\sqlite3.exe demo.db
.tables
.schema
SELECT * FROM Students;
.quit
```

```bat
tools\sqlite\sqldiff.exe demo-before.db demo-after.db > diff.sql
tools\sqlite\sqlite3_analyzer.exe demo.db > analyzer-demo.txt
```

### 9.2. Wrapper HTTP (pentru Postman/browser)

- `GET /tools/sqlite3/tables?db=demo.db` – echivalent cu `sqlite3.exe demo.db ".tables"`;
- `GET /tools/sqlite3/schema?db=demo.db` – echivalent cu `.schema`;
- `POST /tools/sqlite3/query` cu body:

  ```json
  {
    "db": "demo.db",
    "sql": "SELECT * FROM Students;"
  }
  ```

- `GET /tools/sqldiff?db1=demo-before.db&db2=demo-after.db` – script SQL cu diferențe;
- `GET /tools/sqlite3_analyzer?db=demo.db` – raport textual de analiză.

Parametrii `db`, `db1`, `db2` sunt verificați ca **căi relative** (nu se permit `..`, litere de
unitate sau căi absolute), pentru a preveni accesul accidental în afara laboratorului.

---

## 10. Scenariu pedagogic sugerat

1. **Introducere ORM + modele** – pornești serverul, deschizi `demo-api.html`, discuți
   definițiile și relațiile; trimiți `GET /api/universities` din Postman.
2. **One‑to‑many** – folosești endpoint‑urile `/api/universities/:id/students`, insiști pe
   rolul cheii străine și pe cum se vede asta în `sqlite3.exe` (`.schema Students`). fileciteturn0file2L29-L43  
3. **PUT/DELETE** – actualizezi/ștergi studenți prin Postman și observi efectele în baza SQLite.
4. **Many‑to‑many** – înscrii studenți la cursuri, apoi arăți cum se reflectă acest lucru în
   tabelul de legătură (`Enrollment`) și în interogările cu `include`. fileciteturn0file2L96-L121  
5. **Import/Export** – explici exportul JSON ca formă de backup / migrare și faci un mic
   experiment de modificare manuală + reimport. fileciteturn0file2L181-L233  
6. **Forensic / tooling** – închei cu demonstrații `sqldiff.exe` și `sqlite3_analyzer.exe`
   pentru a arăta cum se poate inspecta „sub capotă” baza generată de un ORM. fileciteturn0file1L70-L83  

În acest fel, laboratorul S10vDEMO poate fi folosit ca „mic univers complet” în care toate
funcționalitățile seminariului 10 original sunt concentrate într‑un singur proiect, cu date
pre‑populate și uneltele SQLite integrate atât în linia de comandă, cât și prin HTTP.
