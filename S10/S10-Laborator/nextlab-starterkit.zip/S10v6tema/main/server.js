const app = require('./app')

app.listen(3001, () => {
  console.log('Server started on port 8080...')
})
