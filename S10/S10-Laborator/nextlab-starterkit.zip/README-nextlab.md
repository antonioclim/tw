# Starterkit Seminar 10 – Relații cu ORM (Sequelize)

Acest starterkit presupune Node.js instalat pe Windows 11 și este gândit să fie plasat în directorul `Z:\tw\SxTEST\FAZA10\nextlab`.

## Structură

- `dashboard/` – aplicație Express simplă pe **portul 3000** care servește paginile HTML cu pașii și explicațiile.
- `S10v1` … `S10v5` – proiectele pentru fiecare pas al seminarului (variantă seminar + soluție).
- `S10v6tema/` – tema 3, cu testele automate.

## Pornirea dashboard‑ului (port 3000)

```bash
cd dashboard
npm install
npm start
# http://localhost:3000
```

## Pornirea unui pas pe portul 3001

Pentru fiecare pas, intrați în folderul `S10vX/S10vXsem` și rulați:

```bash
cd S10v1/S10v1sem   # sau S10v2/S10v2sem etc.
npm install
npm run dev         # sau: node index.js
# server pe http://localhost:3001
```

Pentru tema 3:

```bash
cd S10v6tema/main
npm install
npm test            # rulează testele
node server.js      # pornește serverul pe portul 3001
```

Configurați Postman conform paginii `Postman` din dashboard (`http://localhost:3000/postman.html`).
