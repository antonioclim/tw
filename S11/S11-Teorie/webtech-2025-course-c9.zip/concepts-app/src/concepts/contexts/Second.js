import React from 'react'
import Third from './Third'

const Second = () => {
  return (
		<div>
			<h2>
					I am 2 deep
			</h2>
			<Third />
		</div>
  )
}

export default Second