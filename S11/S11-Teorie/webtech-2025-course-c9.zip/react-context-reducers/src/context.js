import { createContext } from 'react'

export const AppStateContext = createContext()
export const AppDispatchContext = createContext()
