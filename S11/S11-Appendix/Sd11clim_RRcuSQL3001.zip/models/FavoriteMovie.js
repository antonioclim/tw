const { DataTypes } = require("sequelize");
const sequelize = require("./index");

const FavoriteMovie = sequelize.define(
  "FavoriteMovie",
  {
    tmdbId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
    },
    title: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    posterPath: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    releaseDate: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  {
    tableName: "FavoriteMovies",
    timestamps: true,
  }
);

module.exports = FavoriteMovie;
