import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";

export const fetchFavorites = createAsyncThunk("favorites/fetchAll", async () => {
  const res = await fetch("/api/favorites");
  if (!res.ok) {
    throw new Error("Failed to fetch favourites.");
  }
  const data = await res.json();
  return data.map((fav) => ({
    id: Number(fav.tmdbId),
    title: fav.title,
    poster_path: fav.posterPath || null,
    release_date: fav.releaseDate || null,
  }));
});

export const addFavorite = createAsyncThunk(
  "favorites/add",
  async (movie) => {
    const payload = {
      tmdbId: movie.id,
      title: movie.title,
      posterPath: movie.poster_path || null,
      releaseDate: movie.release_date || null,
    };
    const res = await fetch("/api/favorites", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      throw new Error("Failed to add favourite.");
    }
    const fav = await res.json();
    return {
      id: Number(fav.tmdbId),
      title: fav.title,
      poster_path: fav.posterPath || null,
      release_date: fav.releaseDate || null,
    };
  }
);

export const removeFavorite = createAsyncThunk(
  "favorites/remove",
  async (tmdbId) => {
    const res = await fetch(`/api/favorites/${encodeURIComponent(tmdbId)}`, {
      method: "DELETE",
    });
    if (!res.ok && res.status !== 404) {
      throw new Error("Failed to remove favourite.");
    }
    return tmdbId;
  }
);

const favoritesSlice = createSlice({
  name: "favorites",
  initialState: {
    items: [],
    status: "idle",
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchFavorites.pending, (state) => {
        state.status = "loading";
        state.error = null;
      })
      .addCase(fetchFavorites.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.items = action.payload;
      })
      .addCase(fetchFavorites.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message || "Failed to load favourites.";
      })
      .addCase(addFavorite.fulfilled, (state, action) => {
        const exists = state.items.some((m) => m.id === action.payload.id);
        if (!exists) {
          state.items.unshift(action.payload);
        }
      })
      .addCase(removeFavorite.fulfilled, (state, action) => {
        state.items = state.items.filter((m) => m.id !== Number(action.payload));
      });
  },
});

export const selectFavorites = (state) => state.favorites.items;
export const selectFavoriteIds = (state) =>
  state.favorites.items.map((fav) => fav.id);

export default favoritesSlice.reducer;
