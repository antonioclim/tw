import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import MovieCard from "../components/MovieCard.jsx";
import { fetchFavorites, selectFavorites } from "../features/favoritesSlice.js";
import "../css/Favorites.css";

function Favorites() {
  const dispatch = useDispatch();
  const favorites = useSelector(selectFavorites);
  const hasFavorites = Array.isArray(favorites) && favorites.length > 0;

  useEffect(() => {
    dispatch(fetchFavorites());
  }, [dispatch]);

  if (!hasFavorites) {
    return (
      <section className="favorites-empty">
        <h2>No favourite movies yet</h2>
        <p>
          Start adding movies to your favourites on the Home page and they will
          appear here.
        </p>
      </section>
    );
  }

  return (
    <section className="favorites">
      <h2>Your favourites</h2>
      <div className="movies-grid">
        {favorites.map((movie) => (
          <MovieCard movie={movie} key={movie.id} />
        ))}
      </div>
    </section>
  );
}

export default Favorites;
