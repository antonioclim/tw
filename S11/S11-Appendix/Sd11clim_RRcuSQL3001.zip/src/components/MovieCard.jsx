import PropTypes from "prop-types";
import { useDispatch, useSelector } from "react-redux";
import { addFavorite, removeFavorite, selectFavoriteIds } from "../features/favoritesSlice.js";
import "../css/MovieCard.css";

function MovieCard({ movie }) {
  const dispatch = useDispatch();
  const favoriteIds = useSelector(selectFavoriteIds);
  const isFavorite = favoriteIds.includes(movie.id);

  const handleClick = (event) => {
    event.preventDefault();
    if (isFavorite) {
      dispatch(removeFavorite(movie.id));
    } else {
      dispatch(addFavorite(movie));
    }
  };

  const year = movie?.release_date?.split("-")[0] ?? "Unknown year";

  return (
    <article className="movie-card">
      {movie.poster_path ? (
        <img
          className="movie-poster"
          src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
          alt={movie.title}
        />
      ) : (
        <div className="movie-poster placeholder">
          <span>No image</span>
        </div>
      )}
      <div className="movie-body">
        <h3 className="movie-title">{movie.title}</h3>
        <p className="movie-meta">{year}</p>
        <button
          type="button"
          className={`favorite-button ${isFavorite ? "active" : ""}`}
          onClick={handleClick}
        >
          {isFavorite ? "Remove from favourites" : "Add to favourites"}
        </button>
      </div>
    </article>
  );
}

MovieCard.propTypes = {
  movie: PropTypes.shape({
    id: PropTypes.number.isRequired,
    title: PropTypes.string.isRequired,
    poster_path: PropTypes.string,
    release_date: PropTypes.string,
  }).isRequired,
};

export default MovieCard;
