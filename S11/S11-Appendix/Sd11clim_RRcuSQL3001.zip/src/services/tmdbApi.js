const API_KEY = import.meta.env.VITE_TMDB_API_KEY || "";
const BASE_URL = "https://api.themoviedb.org/3";

async function safeFetch(url) {
  const response = await fetch(url);
  let data;
  try {
    data = await response.json();
  } catch (error) {
    throw new Error("Invalid JSON response from TMDB.");
  }
  if (!response.ok) {
    const message =
      (data && data.status_message) ||
      `TMDB request failed with status ${response.status}`;
    throw new Error(message);
  }
  return data;
}

export async function getPopularMovies() {
  if (!API_KEY) {
    console.warn(
      "[TMDB] No API key configured. Returning an empty list of popular movies."
    );
    return [];
  }
  const url = `${BASE_URL}/movie/popular?api_key=${API_KEY}&language=en-GB&page=1`;
  const data = await safeFetch(url);
  return Array.isArray(data.results) ? data.results : [];
}

export async function searchMovies(query) {
  if (!API_KEY) {
    console.warn(
      "[TMDB] No API key configured. Returning an empty search result list."
    );
    return [];
  }
  const encoded = encodeURIComponent(query);
  const url = `${BASE_URL}/search/movie?api_key=${API_KEY}&language=en-GB&query=${encoded}&page=1&include_adult=false`;
  const data = await safeFetch(url);
  return Array.isArray(data.results) ? data.results : [];
}
