const express = require("express");
const path = require("path");
const sequelize = require("./models");
const FavoriteMovie = require("./models/FavoriteMovie");

const app = express();
const API_PORT = 3001;

// Middlewares
app.use(express.json());

// Serve static files if needed (for production builds)
app.use(express.static(path.join(__dirname, "dist")));

// API routes for favourites
app.get("/api/favorites", async (req, res) => {
  try {
    const favorites = await FavoriteMovie.findAll({
      order: [["createdAt", "DESC"]],
    });
    res.json(
      favorites.map((fav) => ({
        tmdbId: fav.tmdbId,
        title: fav.title,
        posterPath: fav.posterPath,
        releaseDate: fav.releaseDate,
      }))
    );
  } catch (error) {
    console.error("[API] GET /api/favorites error:", error);
    res.status(500).json({ error: "Failed to fetch favourites." });
  }
});

app.post("/api/favorites", async (req, res) => {
  try {
    const { tmdbId, title, posterPath, releaseDate } = req.body;

    if (typeof tmdbId === "undefined" || !title) {
      return res
        .status(400)
        .json({ error: "tmdbId and title are required fields." });
    }

    const [favorite] = await FavoriteMovie.upsert({
      tmdbId,
      title,
      posterPath: posterPath || null,
      releaseDate: releaseDate || null,
    });

    res.status(201).json({
      tmdbId: favorite.tmdbId,
      title: favorite.title,
      posterPath: favorite.posterPath,
      releaseDate: favorite.releaseDate,
    });
  } catch (error) {
    console.error("[API] POST /api/favorites error:", error);
    res.status(500).json({ error: "Failed to save favourite." });
  }
});

app.delete("/api/favorites/:tmdbId", async (req, res) => {
  try {
    const tmdbId = parseInt(req.params.tmdbId, 10);
    if (Number.isNaN(tmdbId)) {
      return res.status(400).json({ error: "Invalid tmdbId parameter." });
    }

    const deletedCount = await FavoriteMovie.destroy({
      where: { tmdbId },
    });

    if (deletedCount === 0) {
      return res.status(404).json({ error: "Favourite not found." });
    }

    res.status(204).send();
  } catch (error) {
    console.error("[API] DELETE /api/favorites/:tmdbId error:", error);
    res.status(500).json({ error: "Failed to delete favourite." });
  }
});

// Fallback: send index.html for any non-API route in production
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "dist", "index.html"));
});

async function start() {
  try {
    await sequelize.authenticate();
    await sequelize.sync();
    app.listen(API_PORT, () => {
      console.log(
        `API server (Express + Sequelize) running at http://localhost:${API_PORT}`
      );
    });
  } catch (error) {
    console.error("Failed to start API server:", error);
    process.exit(1);
  }
}

start();
