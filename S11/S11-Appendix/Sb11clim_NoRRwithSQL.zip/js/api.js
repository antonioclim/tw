/**
 * Very small wrapper around TMDB REST API, using plain JavaScript.
 * Exposes a global `TMDB` object:
 *
 *   TMDB.getPopularMovies() -> Promise<Array<Movie>>
 *   TMDB.searchMovies(query) -> Promise<Array<Movie>>
 */
(function (global) {
  "use strict";

  var API_KEY = typeof TMDB_API_KEY !== "undefined" ? TMDB_API_KEY : "";
  var BASE_URL = "https://api.themoviedb.org/3";

  function safeFetch(url) {
    return fetch(url).then(function (response) {
      return response
        .json()
        .then(function (data) {
          if (!response.ok) {
            var message =
              (data && data.status_message) ||
              "Request failed with status " + response.status;
            throw new Error(message);
          }
          return data;
        })
        .catch(function (error) {
          if (error instanceof SyntaxError) {
            throw new Error("Invalid JSON response.");
          }
          throw error;
        });
    });
  }

  function warnMissingKey(contextMessage) {
    console.warn(
      "[TMDB] No API key configured. " +
        "Set TMDB_API_KEY in js/config.js. " +
        "Context: " +
        contextMessage
    );
  }

  function getPopularMovies() {
    if (!API_KEY) {
      warnMissingKey("getPopularMovies");
      return Promise.resolve([]);
    }

    var url =
      BASE_URL + "/movie/popular?api_key=" + API_KEY + "&language=en-GB&page=1";

    return safeFetch(url).then(function (data) {
      return Array.isArray(data.results) ? data.results : [];
    });
  }

  function searchMovies(query) {
    if (!API_KEY) {
      warnMissingKey("searchMovies");
      return Promise.resolve([]);
    }

    var encoded = encodeURIComponent(query);
    var url =
      BASE_URL +
      "/search/movie?api_key=" +
      API_KEY +
      "&language=en-GB&query=" +
      encoded +
      "&page=1&include_adult=false";

    return safeFetch(url).then(function (data) {
      return Array.isArray(data.results) ? data.results : [];
    });
  }

  global.TMDB = {
    getPopularMovies: getPopularMovies,
    searchMovies: searchMovies,
  };
})(window);
