/* global TMDB */
/**
 * Main application logic implemented in plain JavaScript.
 * Handles:
 *  - initial load of popular movies (TMDB)
 *  - search form and rendering results
 *  - favourites management via back-end (Express + Sequelize)
 *  - simple view switching between Home and Favourites
 */
(function () {
  "use strict";

  // DOM elements
  var navHomeButton = document.getElementById("nav-home");
  var navHomeBrand = document.getElementById("nav-home-brand");
  var navFavoritesButton = document.getElementById("nav-favorites");

  var viewHome = document.getElementById("view-home");
  var viewFavorites = document.getElementById("view-favorites");

  var searchForm = document.getElementById("search-form");
  var searchInput = document.getElementById("search-input");

  var homeError = document.getElementById("home-error");
  var homeLoading = document.getElementById("home-loading");
  var homeNoResults = document.getElementById("home-no-results");
  var homeMoviesGrid = document.getElementById("home-movies-grid");

  var favoritesEmpty = document.getElementById("favorites-empty");
  var favoritesMoviesGrid = document.getElementById("favorites-movies-grid");

  var favorites = []; // array of { id, title, poster_path, release_date }

  // ---------- Utility: favourites via back-end ----------

  function transformFromServerFavorite(serverFav) {
    return {
      id: Number(serverFav.tmdbId),
      title: serverFav.title,
      poster_path: serverFav.posterPath || null,
      release_date: serverFav.releaseDate || null,
    };
  }

  function loadFavoritesFromServer() {
    return fetch("/api/favorites")
      .then(function (res) {
        if (!res.ok) {
          throw new Error("Failed to load favourites from server.");
        }
        return res.json();
      })
      .then(function (data) {
        if (Array.isArray(data)) {
          favorites = data.map(transformFromServerFavorite);
        } else {
          favorites = [];
        }
      })
      .catch(function (error) {
        console.warn("[MovieApp] Could not load favourites:", error);
        favorites = [];
      });
  }

  function isFavorite(movieId) {
    var id = Number(movieId);
    for (var i = 0; i < favorites.length; i += 1) {
      if (favorites[i] && Number(favorites[i].id) === id) {
        return true;
      }
    }
    return false;
  }

  function addFavoriteOnServer(movie) {
    if (!movie || typeof movie.id === "undefined") {
      return Promise.resolve();
    }
    if (isFavorite(movie.id)) {
      return Promise.resolve();
    }

    var payload = {
      tmdbId: movie.id,
      title: movie.title,
      posterPath: movie.poster_path || null,
      releaseDate: movie.release_date || null,
    };

    return fetch("/api/favorites", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }).then(function (res) {
      if (!res.ok) {
        return res.json().catch(function () {}).then(function () {
          throw new Error("Failed to add favourite on server.");
        });
      }
      return loadFavoritesFromServer();
    });
  }

  function removeFavoriteOnServer(movieId) {
    var id = Number(movieId);
    return fetch("/api/favorites/" + encodeURIComponent(id), {
      method: "DELETE",
    }).then(function (res) {
      if (!res.ok && res.status !== 404) {
        throw new Error("Failed to remove favourite on server.");
      }
      return loadFavoritesFromServer();
    });
  }

  // ---------- View switching ----------

  function setActiveView(viewName) {
    if (viewName === "home") {
      viewHome.classList.add("view-active");
      viewFavorites.classList.remove("view-active");

      navHomeButton.classList.add("active");
      navFavoritesButton.classList.remove("active");
    } else if (viewName === "favorites") {
      viewHome.classList.remove("view-active");
      viewFavorites.classList.add("view-active");

      navHomeButton.classList.remove("active");
      navFavoritesButton.classList.add("active");
    }
  }

  // ---------- Rendering movie cards ----------

  function createMovieCard(movie) {
    var card = document.createElement("article");
    card.className = "movie-card";

    var imageContainer;
    if (movie.poster_path) {
      var img = document.createElement("img");
      img.className = "movie-poster";
      img.src = "https://image.tmdb.org/t/p/w500" + movie.poster_path;
      img.alt = movie.title || "Movie poster";
      imageContainer = img;
    } else {
      var placeholder = document.createElement("div");
      placeholder.className = "movie-poster placeholder";
      var span = document.createElement("span");
      span.textContent = "No image";
      placeholder.appendChild(span);
      imageContainer = placeholder;
    }
    card.appendChild(imageContainer);

    var body = document.createElement("div");
    body.className = "movie-body";

    var title = document.createElement("h3");
    title.className = "movie-title";
    title.textContent = movie.title || "Untitled";
    body.appendChild(title);

    var year = "Unknown year";
    if (movie.release_date && typeof movie.release_date === "string") {
      year = movie.release_date.split("-")[0] || year;
    }

    var meta = document.createElement("p");
    meta.className = "movie-meta";
    meta.textContent = year;
    body.appendChild(meta);

    var favButton = document.createElement("button");
    favButton.type = "button";
    favButton.className = "favorite-button";
    favButton.setAttribute("data-movie-id", movie.id);

    function updateButtonState() {
      if (isFavorite(movie.id)) {
        favButton.classList.add("active");
        favButton.textContent = "Remove from favourites";
      } else {
        favButton.classList.remove("active");
        favButton.textContent = "Add to favourites";
      }
    }

    updateButtonState();

    favButton.addEventListener("click", function (event) {
      event.preventDefault();
      if (isFavorite(movie.id)) {
        removeFavoriteOnServer(movie.id)
          .then(function () {
            updateButtonState();
            renderFavoritesView();
          })
          .catch(function (error) {
            console.error(error);
          });
      } else {
        addFavoriteOnServer(movie)
          .then(function () {
            updateButtonState();
            renderFavoritesView();
          })
          .catch(function (error) {
            console.error(error);
          });
      }
    });

    body.appendChild(favButton);

    card.appendChild(body);
    return card;
  }

  function renderMoviesGrid(container, movies) {
    container.innerHTML = "";

    if (!Array.isArray(movies) || movies.length === 0) {
      return;
    }

    for (var i = 0; i < movies.length; i += 1) {
      var movie = movies[i];
      if (!movie || typeof movie.id === "undefined") {
        continue;
      }
      var card = createMovieCard(movie);
      container.appendChild(card);
    }
  }

  // ---------- Home view logic ----------

  function showHomeLoading(isLoading) {
    if (isLoading) {
      homeLoading.classList.remove("hidden");
    } else {
      homeLoading.classList.add("hidden");
    }
  }

  function showHomeError(message) {
    if (message) {
      homeError.textContent = message;
      homeError.classList.remove("hidden");
    } else {
      homeError.textContent = "";
      homeError.classList.add("hidden");
    }
  }

  function showHomeNoResults(message) {
    if (message) {
      homeNoResults.textContent = message;
      homeNoResults.classList.remove("hidden");
    } else {
      homeNoResults.textContent = "";
      homeNoResults.classList.add("hidden");
    }
  }

  function loadPopularMovies() {
    showHomeError(null);
    showHomeNoResults(null);
    showHomeLoading(true);
    homeMoviesGrid.innerHTML = "";

    TMDB.getPopularMovies()
      .then(function (movies) {
        renderMoviesGrid(homeMoviesGrid, movies);
        if (!movies || movies.length === 0) {
          showHomeNoResults(
            "No popular movies could be loaded. Please check your API key or try again later."
          );
        }
      })
      .catch(function (error) {
        console.error(error);
        showHomeError(
          "Failed to load popular movies. Please try again later."
        );
      })
      .finally(function () {
        showHomeLoading(false);
      });
  }

  function handleSearchSubmit(event) {
    event.preventDefault();

    var query = (searchInput.value || "").trim();
    if (!query) {
      return;
    }

    showHomeError(null);
    showHomeNoResults(null);
    showHomeLoading(true);
    homeMoviesGrid.innerHTML = "";

    TMDB.searchMovies(query)
      .then(function (movies) {
        renderMoviesGrid(homeMoviesGrid, movies);
        if (!movies || movies.length === 0) {
          showHomeNoResults(
            'No movies found for "' + query + '". Please try another search.'
          );
        }
      })
      .catch(function (error) {
        console.error(error);
        showHomeError("Failed to search movies. Please try again later.");
      })
      .finally(function () {
        showHomeLoading(false);
      });
  }

  // ---------- Favourites view logic ----------

  function renderFavoritesView() {
    if (!Array.isArray(favorites) || favorites.length === 0) {
      favoritesMoviesGrid.innerHTML = "";
      favoritesEmpty.classList.remove("hidden");
      return;
    }

    favoritesEmpty.classList.add("hidden");
    renderMoviesGrid(favoritesMoviesGrid, favorites);
  }

  // ---------- Initialisation ----------

  function initialiseNavigation() {
    function toHome(event) {
      if (event) {
        event.preventDefault();
      }
      setActiveView("home");
    }

    function toFavorites(event) {
      if (event) {
        event.preventDefault();
      }
      setActiveView("favorites");
      renderFavoritesView();
    }

    navHomeButton.addEventListener("click", toHome);
    navHomeBrand.addEventListener("click", toHome);
    navFavoritesButton.addEventListener("click", toFavorites);
  }

  function init() {
    initialiseNavigation();

    searchForm.addEventListener("submit", handleSearchSubmit);

    // Load favourites from server first, then load popular movies.
    loadFavoritesFromServer().finally(function () {
      setActiveView("home");
      loadPopularMovies();
    });
  }

  function setActiveView(viewName) {
    if (viewName === "home") {
      viewHome.classList.add("view-active");
      viewFavorites.classList.remove("view-active");

      navHomeButton.classList.add("active");
      navFavoritesButton.classList.remove("active");
    } else if (viewName === "favorites") {
      viewHome.classList.remove("view-active");
      viewFavorites.classList.add("view-active");

      navHomeButton.classList.remove("active");
      navFavoritesButton.classList.add("active");
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
