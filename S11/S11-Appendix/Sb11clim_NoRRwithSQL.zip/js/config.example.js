// Copy this file to `config.js` and replace the placeholder value
// with your own TMDB v3 API key from https://www.themoviedb.org/.
//
// Example:
//   var TMDB_API_KEY = "123456789abcdef...";
//
var TMDB_API_KEY = "YOUR_TMDB_API_KEY_HERE";
