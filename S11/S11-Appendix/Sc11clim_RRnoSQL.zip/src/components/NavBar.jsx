import { Link, NavLink } from "react-router-dom";
import "../css/NavBar.css";

function NavBar() {
  return (
    <header className="navbar">
      <div className="navbar-inner">
        <div className="navbar-brand">
          <Link to="/">Movie App</Link>
        </div>
        <nav className="navbar-links">
          <NavLink
            to="/"
            end
            className={({ isActive }) =>
              isActive ? "navbar-link active" : "navbar-link"
            }
          >
            Home
          </NavLink>
          <NavLink
            to="/favorites"
            className={({ isActive }) =>
              isActive ? "navbar-link active" : "navbar-link"
            }
          >
            Favorites
          </NavLink>
        </nav>
      </div>
    </header>
  );
}

export default NavBar;
