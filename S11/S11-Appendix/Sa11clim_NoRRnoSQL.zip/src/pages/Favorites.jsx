import { useMovieContext } from "../contexts/MovieContext.jsx";
import MovieCard from "../components/MovieCard.jsx";
import "../css/Favorites.css";

function Favorites() {
  const { favorites } = useMovieContext();

  const hasFavorites = Array.isArray(favorites) && favorites.length > 0;

  if (!hasFavorites) {
    return (
      <section className="favorites-empty">
        <h2>No favourite movies yet</h2>
        <p>
          Start adding movies to your favourites on the Home page and they will
          appear here.
        </p>
      </section>
    );
  }

  return (
    <section className="favorites">
      <h2>Your favourites</h2>
      <div className="movies-grid">
        {favorites.map((movie) => (
          <MovieCard movie={movie} key={movie.id} />
        ))}
      </div>
    </section>
  );
}

export default Favorites;
