import { useEffect, useState } from "react";
import MovieCard from "../components/MovieCard.jsx";
import { getPopularMovies, searchMovies } from "../services/api.js";
import "../css/Home.css";

function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [movies, setMovies] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [hasSearched, setHasSearched] = useState(false);

  useEffect(() => {
    let isMounted = true;

    const loadPopularMovies = async () => {
      try {
        const popularMovies = await getPopularMovies();
        if (isMounted) {
          setMovies(Array.isArray(popularMovies) ? popularMovies : []);
          setError(null);
        }
      } catch (err) {
        console.error(err);
        if (isMounted) {
          setError("Failed to load popular movies. Please try again later.");
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    loadPopularMovies();

    return () => {
      isMounted = false;
    };
  }, []);

  const handleSearch = async (event) => {
    event.preventDefault();

    const trimmedQuery = searchQuery.trim();
    if (!trimmedQuery) return;
    if (loading) return;

    setLoading(true);
    setHasSearched(true);

    try {
      const searchResults = await searchMovies(trimmedQuery);
      setMovies(Array.isArray(searchResults) ? searchResults : []);
      setError(null);
    } catch (err) {
      console.error(err);
      setError("Failed to search movies. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  const showNoResults =
    !loading && !error && hasSearched && Array.isArray(movies) && movies.length === 0;

  return (
    <section className="home">
      <h1 className="home-title">Discover movies</h1>

      <form className="search-form" onSubmit={handleSearch}>
        <input
          type="text"
          placeholder="Search for a movie…"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="search-input"
        />
        <button type="submit" className="search-button">
          Search
        </button>
      </form>

      {error && <div className="error-message">{error}</div>}

      {loading ? (
        <div className="loading">Loading…</div>
      ) : (
        <>
          {showNoResults && (
            <p className="no-results">
              No movies found for “{searchQuery.trim()}”. Please try another search.
            </p>
          )}

          <div className="movies-grid">
            {(Array.isArray(movies) ? movies : []).map((movie) => (
              <MovieCard movie={movie} key={movie.id} />
            ))}
          </div>
        </>
      )}
    </section>
  );
}

export default Home;
