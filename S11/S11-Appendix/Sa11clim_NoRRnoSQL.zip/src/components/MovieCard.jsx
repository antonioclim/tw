import PropTypes from "prop-types";
import { useMovieContext } from "../contexts/MovieContext.jsx";
import "../css/MovieCard.css";

function MovieCard({ movie }) {
  const { addToFavorites, removeFromFavorites, isFavorite } = useMovieContext();
  const favorite = isFavorite(movie.id);

  const handleFavoriteClick = (event) => {
    event.preventDefault();

    if (favorite) {
      removeFromFavorites(movie.id);
    } else {
      addToFavorites(movie);
    }
  };

  const year = movie?.release_date?.split("-")[0] ?? "Unknown year";

  return (
    <article className="movie-card">
      {movie.poster_path ? (
        <img
          className="movie-poster"
          src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
          alt={movie.title}
        />
      ) : (
        <div className="movie-poster placeholder">
          <span>No image</span>
        </div>
      )}
      <div className="movie-body">
        <h3 className="movie-title">{movie.title}</h3>
        <p className="movie-meta">{year}</p>
        <button
          type="button"
          className={`favorite-button ${favorite ? "active" : ""}`}
          onClick={handleFavoriteClick}
        >
          {favorite ? "Remove from favourites" : "Add to favourites"}
        </button>
      </div>
    </article>
  );
}

MovieCard.propTypes = {
  movie: PropTypes.shape({
    id: PropTypes.number.isRequired,
    title: PropTypes.string.isRequired,
    poster_path: PropTypes.string,
    release_date: PropTypes.string
  }).isRequired
};

export default MovieCard;
