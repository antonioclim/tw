import { createContext, useContext, useEffect, useState } from "react";

const MovieContext = createContext(null);

export function MovieProvider({ children }) {
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    try {
      const stored = localStorage.getItem("favorites");
      if (!stored) return;

      const parsed = JSON.parse(stored);
      if (Array.isArray(parsed)) {
        setFavorites(parsed);
      } else {
        console.warn("Ignoring non-array favourites from localStorage.");
      }
    } catch (error) {
      console.warn("Failed to read favourites from localStorage:", error);
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem("favorites", JSON.stringify(favorites));
    } catch (error) {
      console.warn("Failed to persist favourites to localStorage:", error);
    }
  }, [favorites]);

  const addToFavorites = (movie) => {
    if (!movie || typeof movie.id !== "number") return;

    setFavorites((prev) => {
      if (prev.some((m) => m.id === movie.id)) {
        return prev;
      }
      return [...prev, movie];
    });
  };

  const removeFromFavorites = (movieId) => {
    setFavorites((prev) => prev.filter((movie) => movie.id !== movieId));
  };

  const isFavorite = (movieId) => favorites.some((movie) => movie.id === movieId);

  const contextValue = {
    favorites,
    addToFavorites,
    removeFromFavorites,
    isFavorite
  };

  return <MovieContext.Provider value={contextValue}>{children}</MovieContext.Provider>;
}

export function useMovieContext() {
  const context = useContext(MovieContext);
  if (!context) {
    throw new Error("useMovieContext must be used within a MovieProvider.");
  }
  return context;
}
