
# Seminar 11 – React starterkit (cu Pasul 5 funcțional)

Acesta este proiectul de laborator pentru Seminarul 11 (React + JSX), pregătit
să ruleze pe **Windows 11**, în **Visual Studio Code**, cu Node.js + npm instalate.

## Structură

- `src/` – codul React al starterkit-ului (pagini + pașii 1–5).
- `public/teme/` – enunțurile temelor S11v1–S11v5.
- `public/subtitles/` – subtitrările `.srt` pentru înregistrările video.
- `public/S11_original/` – kitul istoric S11step1-5 (S11v1–S11v5).

Routarea este configurată astfel încât:

- `http://localhost:3000/` – prezentare generală;
- `http://localhost:3000/teme` – Teme & resurse;
- `http://localhost:3000/step1` … `step4` – demonstrații pentru useState, useEffect,
  props, lifting state;
- `http://localhost:3000/step5` – **Pasul 5 (build & deployment)** – deja
  funcțional și demonstrativ.

## Instalare și rulare

1. Creează directorul țintă, de exemplu:

   ```text
   Z:\tw\SxTEST\FAZA11\S11nextlab
   ```

2. Descarcă `starterkit_step5_fixed.zip` și dezarhivează **direct în acest folder**,
   astfel încât să ai:

   ```text
   Z:\tw\SxTEST\FAZA11\S11nextlab\package.json
   Z:\tw\SxTEST\FAZA11\S11nextlab\webpack.config.js
   Z:\tw\SxTEST\FAZA11\S11nextlab\src\...
   Z:\tw\SxTEST\FAZA11\S11nextlab\public\...
   ```

3. În terminal (în directorul `S11nextlab`):

   ```bash
   npm install
   npm start
   ```

4. Deschide în browser:

   - `http://localhost:3000` pentru pagina principală;
   - `http://localhost:3000/step5` pentru a vedea Pasul 5 în acțiune.

## Build de producție (exemplu pentru Pasul 5)

Pentru a genera varianta de producție, rulează:

```bash
npm run build
```

Se va crea directorul `dist/` cu bundle-ul optimizat. Acest conținut poate fi
publicat pe un server static sau pe o platformă de hosting (GitHub Pages,
Netlify etc.), conform discuției teoretice din curs.
