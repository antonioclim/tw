import React, { useState, useEffect } from 'react';

function App() {
  // Initialize state variable 'count' with 0
  const [count, setCount] = useState(0);

  // Use the useEffect hook to handle side effects
  // This updates the document title every time the component renders/updates
  useEffect(() => {
    document.title = `You clicked ${count} times`;
  });

  return (
    <div className="container">
      {/* Display the current count */}
      <p>You clicked {count} times</p>
      
      {/* Button to increment the count state */}
      <button onClick={() => setCount(count + 1)}>Click Me</button>
    </div>
  );
}

export default App;