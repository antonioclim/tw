import React, { useState } from 'react';

const App = () => {
  // Declaration of the state variable 'steps' and the setter 'setSteps'
  // Initialized with a value of 0
  const [steps, setSteps] = useState(0);

  return (
    <div className="container">
      {/* Displaying the current state value */}
      <p>Today you've taken {steps} steps!</p>
      
      {/* Button with an arrow function to update the state on click */}
      <button onClick={() => setSteps(steps + 1)}>Click Me</button>
    </div>
  );
}

export default App;