
import React, { useState } from 'react';

function Step5Deployment() {
  const [built, setBuilt] = useState(false);

  return (
    <div className="page">
      <h2>Pasul 5 – Build și deployment (exemplu local)</h2>
      <section>
        <p>
          Acest pas ilustrează ideea de „de la cod sursă la aplicație livrabilă”.
          Proiectul curent rulează pe portul <code>3000</code> folosind{' '}
          <code>webpack-dev-server</code>, iar comanda <code>npm run build</code>{' '}
          generează un bundle optimizat în directorul <code>dist/</code>.
        </p>
        <p>
          Butonul de mai jos simulează pipeline-ul de build &amp; deploy: când îl
          apeși, marcăm intern faptul că build-ul a fost realizat, iar UI-ul
          reacționează declarativ.
        </p>
        <div style={{ marginTop: '1rem' }}>
          <button onClick={() => setBuilt(true)} disabled={built}>
            {built ? 'Build efectuat' : 'Rulează build-ul (simulat)'}
          </button>
          {built && (
            <ul className="intro-note" style={{ marginTop: '0.75rem' }}>
              <li>1. <code>npm run build</code> – generează <code>dist/</code>.</li>
              <li>
                2. Copiezi conținutul din <code>dist/</code> pe un server static
                (sau pe o platformă precum GitHub Pages / Netlify).
              </li>
              <li>
                3. Utilizatorii accesează direct versiunea build-uită, fără
                toolchain-ul de dezvoltare.
              </li>
            </ul>
          )}
        </div>
      </section>
    </div>
  );
}

export default Step5Deployment;
