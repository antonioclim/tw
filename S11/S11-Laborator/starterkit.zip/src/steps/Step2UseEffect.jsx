
import React, { useEffect, useState } from 'react';

function Step2UseEffect() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    document.title = `Count: ${count}`;
  }, [count]);

  return (
    <div className="page">
      <h2>Pasul 2 – useEffect</h2>
      <section>
        <p>
          <code>useEffect</code> permite atașarea de efecte secundare ciclului de
          viață al componentei. Aici actualizăm titlul documentului la fiecare
          modificare a lui <code>count</code>.
        </p>
        <div style={{ marginTop: '1rem' }}>
          <p>Titlu așteptat în tab: Count: {count}</p>
          <button onClick={() => setCount((c) => c + 1)}>Increment</button>
        </div>
      </section>
    </div>
  );
}

export default Step2UseEffect;
