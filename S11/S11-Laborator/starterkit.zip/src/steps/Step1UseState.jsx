
import React, { useState } from 'react';

function Step1UseState() {
  const [count, setCount] = useState(0);

  return (
    <div className="page">
      <h2>Pasul 1 – useState și randare condițională</h2>
      <section>
        <p>
          Exemplu minimal: un contor care crește la fiecare apăsare. Starea{' '}
          <code>count</code> este locală componentei, iar UI-ul reflectă
          declarativ această stare.
        </p>
        <div style={{ marginTop: '1rem' }}>
          <p>
            Valoare curentă: <strong>{count}</strong>
          </p>
          <button onClick={() => setCount(count + 1)}>Increment</button>
          {count >= 5 && (
            <p className="intro-note">
              Randare condițională: mesajul apare doar când count ≥ 5.
            </p>
          )}
        </div>
      </section>
    </div>
  );
}

export default Step1UseState;
