
import React from 'react';

function UserCard({ user, onSelect }) {
  return (
    <li>
      <button onClick={() => onSelect(user)}>
        {user.name} <span className="tag-pill">{user.role}</span>
      </button>
    </li>
  );
}

function UserDetails({ user }) {
  if (!user) {
    return <p className="intro-note">Selectați un utilizator pentru detalii.</p>;
  }
  return (
    <div>
      <h4>{user.name}</h4>
      <p>Rol: {user.role}</p>
    </div>
  );
}

const USERS = [
  { id: 1, name: 'Ada Lovelace', role: 'admin' },
  { id: 2, name: 'Alan Turing', role: 'standard' },
];

function Step3Props() {
  const [selected, setSelected] = React.useState(null);

  return (
    <div className="page">
      <h2>Pasul 3 – Proprietăți (props)</h2>
      <section>
        <p>
          Componenta părinte deține datele și le transmite componentelor copil
          prin <code>props</code>. Copiii rămân pur funcționali și ușor de
          testat.
        </p>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '1.5rem',
            marginTop: '1rem',
          }}
        >
          <div>
            <h3>Listă utilizatori</h3>
            <ul>
              {USERS.map((u) => (
                <UserCard key={u.id} user={u} onSelect={setSelected} />
              ))}
            </ul>
          </div>
          <div>
            <h3>Detalii</h3>
            <UserDetails user={selected} />
          </div>
        </div>
      </section>
    </div>
  );
}

export default Step3Props;
