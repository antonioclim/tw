
import React from 'react';

const USERS = [
  { id: 1, name: 'Ada Lovelace', role: 'admin' },
  { id: 2, name: 'Alan Turing', role: 'standard' },
  { id: 3, name: 'Grace Hopper', role: 'editor' },
];

function UserList({ users, onSelect, selectedId }) {
  return (
    <ul>
      {users.map((u) => (
        <li key={u.id}>
          <button
            onClick={() => onSelect(u.id)}
            className={selectedId === u.id ? 'nav-link nav-link-active' : 'nav-link'}
          >
            {u.name}
          </button>
        </li>
      ))}
    </ul>
  );
}

function UserDetails({ user }) {
  if (!user) return <p className="intro-note">Niciun utilizator selectat.</p>;
  return (
    <div>
      <h4>{user.name}</h4>
      <p>Rol: {user.role}</p>
    </div>
  );
}

function Step4LiftingState() {
  const [selectedId, setSelectedId] = React.useState(null);
  const selectedUser = USERS.find((u) => u.id === selectedId) || null;

  return (
    <div className="page">
      <h2>Pasul 4 – Lifting state</h2>
      <section>
        <p>
          Starea de selecție este deținută în componenta părinte și distribuită
          ambelor componente copil. Astfel, lista și detaliile sunt menținute în
          sincron.
        </p>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '1.5rem',
            marginTop: '1rem',
          }}
        >
          <div>
            <h3>Listă</h3>
            <UserList
              users={USERS}
              onSelect={setSelectedId}
              selectedId={selectedId}
            />
          </div>
          <div>
            <h3>Detalii</h3>
            <UserDetails user={selectedUser} />
          </div>
        </div>
      </section>
    </div>
  );
}

export default Step4LiftingState;
