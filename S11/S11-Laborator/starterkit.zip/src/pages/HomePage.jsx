
import React from 'react';
import { Link } from 'react-router-dom';

function HomePage() {
  return (
    <div className="page">
      <h2>React &amp; JSX – Arhitectură și fluxul seminarului</h2>
      <section>
        <p>
          Acest starterkit combină explicația teoretică cu exemple minimale de cod
          pentru a ilustra fluxul React: stare locală, efecte, props, lifting state
          și deployment.
        </p>
        <p>
          Folosește meniul de sus pentru a naviga între pași. Pagina{' '}
          <Link to="/teme">Teme &amp; resurse</Link> leagă explicit temele,
          aplicațiile originale (S11v1–S11v5) și subtitrările înregistrărilor.
        </p>
      </section>

      <section>
        <h3>Pașii seminarului</h3>
        <ol>
          <li>
            <strong>Pasul 1 – useState</strong>: stare locală și randare condițională.
          </li>
          <li>
            <strong>Pasul 2 – useEffect</strong>: efecte care reacționează la schimbări de stare.
          </li>
          <li>
            <strong>Pasul 3 – props</strong>: separarea datelor de prezentare.
          </li>
          <li>
            <strong>Pasul 4 – lifting state</strong>: partajarea stării între componente surori.
          </li>
          <li>
            <strong>Pasul 5 – deployment</strong>: de la build local la publicare.
          </li>
        </ol>
      </section>
    </div>
  );
}

export default HomePage;
