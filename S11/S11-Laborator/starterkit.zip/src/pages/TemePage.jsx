
import React from 'react';

function TemePage() {
  return (
    <div className="page">
      <h2>Teme &amp; resurse – Seminar 11 (React)</h2>

      <section>
        <h3>1. Teme de laborator – enunțuri</h3>
        <p>
          Fiecare temă corespunde unui pas din fluxul seminarului. Enunțurile sunt
          disponibile ca fișiere text în <code>public/teme</code>.
        </p>

        <ul>
          <li>
            <strong>Tema 1 – Stare locală și randare condițională</strong>
            <br />
            <a href="/teme/S11v1.txt" target="_blank" rel="noreferrer">
              Descarcă / deschide enunțul (S11v1.txt)
            </a>
          </li>
          <li>
            <strong>Tema 2 – Efecte și ciclul de viață</strong>
            <br />
            <a href="/teme/S11v2.txt" target="_blank" rel="noreferrer">
              Descarcă / deschide enunțul (S11v2.txt)
            </a>
          </li>
          <li>
            <strong>Tema 3 – Props, fetch și structură pe componente</strong>
            <br />
            <a href="/teme/S11v3.txt" target="_blank" rel="noreferrer">
              Descarcă / deschide enunțul (S11v3.txt)
            </a>
          </li>
          <li>
            <strong>Tema 4 – Lifting state și coordonarea componentelor</strong>
            <br />
            <a href="/teme/S11v4.txt" target="_blank" rel="noreferrer">
              Descarcă / deschide enunțul (S11v4.txt)
            </a>
          </li>
          <li>
            <strong>Tema 5 – Build, deployment și integrare cu backend</strong>
            <br />
            <a href="/teme/S11v5.txt" target="_blank" rel="noreferrer">
              Descarcă / deschide enunțul (S11v5.txt)
            </a>
          </li>
        </ul>
      </section>

      <section>
        <h3>2. Aplicațiile originale (S11step1-5)</h3>
        <p>
          Resursele istorice S11v1–S11v5 sunt plasate în{' '}
          <code>public/S11_original</code>. Pot fi folosite pentru comparații sau
          ca punct de plecare pentru teme.
        </p>

        <h4>2.1. Variațiile simple (S11v1, S11v2)</h4>
        <ul>
          <li>
            <strong>S11v1 – useState, contor simplu</strong>
            <br />
            <a href="/S11_original/S11v1/App.js" download>
              Descarcă App.js (S11v1)
            </a>
          </li>
          <li>
            <strong>S11v2 – useState + useEffect</strong>
            <br />
            <a href="/S11_original/S11v2/src/App.js" download>
              Descarcă App.js (S11v2)
            </a>
          </li>
        </ul>

        <h4>2.2. S11v3 – GUI + server</h4>
        <ul>
          <li>
            <a href="/S11_original/S11v3/ex-3-start.zip" download>
              Descarcă ex-3-start.zip
            </a>
          </li>
          <li>
            <a href="/S11_original/S11v3/srcCLASS.zip" download>
              Descarcă srcCLASS.zip
            </a>
          </li>
        </ul>

        <p>
          Pentru rulare, copiază folderele <code>S11v3/gui</code> și{' '}
          <code>S11v3/server</code> într-un spațiu separat și rulează
          <code>npm install</code> urmat de <code>npm start</code>, respectiv{' '}
          <code>node server.js</code>.
        </p>

        <h4>2.3. S11v4 &amp; S11v5 – seturi de start</h4>
        <ul>
          <li>
            <strong>S11v4 – lifting state</strong>
            <br />
            <a href="/S11_original/S11v4/ex-4-start.zip" download>
              Descarcă ex-4-start.zip
            </a>
            {' '}|{' '}
            <a href="/S11_original/S11v4/srcCLASS.zip" download>
              Descarcă srcCLASS.zip
            </a>
          </li>
          <li>
            <strong>S11v5 – deployment &amp; backend</strong>
            <br />
            <a href="/S11_original/S11v5/srcCLASS.zip" download>
              Descarcă srcCLASS.zip
            </a>
          </li>
        </ul>
      </section>

      <section>
        <h3>3. Subtitrări pentru înregistrări</h3>
        <ul>
          <li>
            <a href="/subtitles/S11v1.srt" download>
              S11v1.srt
            </a>
          </li>
          <li>
            <a href="/subtitles/S11v2.srt" download>
              S11v2.srt
            </a>
          </li>
          <li>
            <a href="/subtitles/S11v3.srt" download>
              S11v3.srt
            </a>
          </li>
          <li>
            <a href="/subtitles/S11v4.srt" download>
              S11v4.srt
            </a>
          </li>
          <li>
            <a href="/subtitles/S11v5.srt" download>
              S11v5.srt
            </a>
          </li>
        </ul>
      </section>
    </div>
  );
}

export default TemePage;
