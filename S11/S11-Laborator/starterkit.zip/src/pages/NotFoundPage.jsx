
import React from 'react';
import { Link } from 'react-router-dom';

function NotFoundPage() {
  return (
    <div className="page">
      <h2>404 – Pagina nu a fost găsită</h2>
      <p>
        Adresa accesată nu corespunde niciunui pas din seminar. Revenire la{' '}
        <Link to="/">pagina principală</Link>.
      </p>
    </div>
  );
}

export default NotFoundPage;
