
import React from 'react';
import { NavLink } from 'react-router-dom';

const navLinkClassName = ({ isActive }) =>
  isActive ? 'nav-link nav-link-active' : 'nav-link';

function MainLayout({ children }) {
  return (
    <div className="app-shell">
      <header className="app-header">
        <h1>Seminar 11 – React</h1>
        <p className="app-subtitle">
          Stare, efecte, proprietăți, lifting state și deployment
        </p>
        <nav className="primary-nav">
          <NavLink to="/" className={navLinkClassName} end>
            Prezentare generală
          </NavLink>

          <NavLink to="/teme" className={navLinkClassName}>
            Teme &amp; resurse
          </NavLink>

          <NavLink to="/step1" className={navLinkClassName}>
            Pasul 1
          </NavLink>
          <NavLink to="/step2" className={navLinkClassName}>
            Pasul 2
          </NavLink>
          <NavLink to="/step3" className={navLinkClassName}>
            Pasul 3
          </NavLink>
          <NavLink to="/step4" className={navLinkClassName}>
            Pasul 4
          </NavLink>
          <NavLink to="/step5" className={navLinkClassName}>
            Pasul 5
          </NavLink>
        </nav>
      </header>

      <main className="app-main">{children}</main>

      <footer className="app-footer">
        <small>
          Seminar 11 – React &amp; JSX. Starterkit didactic (webpack + Babel, port 3000).
        </small>
      </footer>
    </div>
  );
}

export default MainLayout;
