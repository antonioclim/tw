
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import MainLayout from './layout/MainLayout.jsx';
import HomePage from './pages/HomePage.jsx';
import TemePage from './pages/TemePage.jsx';
import Step1UseState from './steps/Step1UseState.jsx';
import Step2UseEffect from './steps/Step2UseEffect.jsx';
import Step3Props from './steps/Step3Props.jsx';
import Step4LiftingState from './steps/Step4LiftingState.jsx';
import Step5Deployment from './steps/Step5Deployment.jsx';
import NotFoundPage from './pages/NotFoundPage.jsx';

function App() {
  return (
    <MainLayout>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/teme" element={<TemePage />} />

        <Route path="/step1" element={<Step1UseState />} />
        <Route path="/step2" element={<Step2UseEffect />} />
        <Route path="/step3" element={<Step3Props />} />
        <Route path="/step4" element={<Step4LiftingState />} />
        <Route path="/step5" element={<Step5Deployment />} />

        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </MainLayout>
  );
}

export default App;
