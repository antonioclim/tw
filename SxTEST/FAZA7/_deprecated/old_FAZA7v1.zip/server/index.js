import express from "express";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = process.env.PORT || 3007;

const courses = [
  { id:1, title:"React Basics", lang:"en", lessons:2 },
  { id:2, title:"JS Refresher", lang:"ro", lessons:1 }
];
const lessons = {
  1: [
    { id: 11, title:"Components", lang:"en", duration:8, html:"<p>Components...</p>" },
    { id: 12, title:"State & Props", lang:"en", duration:9, html:"<p>State & Props...</p>" }
  ],
  2: [
    { id: 21, title:"Functions", lang:"ro", duration:7, html:"<p>Functions...</p>" }
  ]
};

app.get('/api/courses', (_req,res)=> res.json(courses));
app.get('/api/courses/:id/lessons', (req,res)=> res.json(lessons[req.params.id]||[]));

app.use(express.static(path.join(__dirname, "..", "public")));
app.get('/', (_req,res)=> res.sendFile(path.join(__dirname, "..", "public", "index.html")));

app.listen(PORT, ()=> console.log(`[FAZA7] pe http://localhost:${PORT}`));

export default app;
