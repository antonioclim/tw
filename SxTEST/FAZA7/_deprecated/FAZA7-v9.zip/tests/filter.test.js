import { describe, it, expect } from 'vitest';
function filterByQuery(arr, q){ return arr.filter(x => (x.title+' '+x.lang).toLowerCase().includes(q.toLowerCase())); }
describe('filterByQuery', ()=>{
  const data = [{title:'React Basics',lang:'en'},{title:'JS',lang:'ro'}];
  it('filters by text', ()=>{
    expect(filterByQuery(data,'react').length).toBe(1);
    expect(filterByQuery(data,'ro').length).toBe(1);
  });
});
