# FAZA7 — Patch fără inline scripts și fără CDN (React local + Vite)

## Rulare
```powershell
cd Z:\tw\SxTEST\FAZA7   # pune aici conținutul patch-ului
npm install
npm run dev
```
- UI: http://localhost:5173/#/courses
- API: http://localhost:3007/api/courses

## Build
```powershell
npm run build
npm run preview
```
