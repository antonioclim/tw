import React, { Suspense, lazy } from 'react'
import { HashRouter, NavLink, Routes, Route } from 'react-router-dom'

const Courses = lazy(()=> import('./pages/Courses.jsx'))
const Lessons = lazy(()=> import('./pages/Lessons.jsx'))

export default function App(){
  return (
    <HashRouter>
      <header style={{padding:'1rem', background:'#0f1530', color:'#e6e9ef', fontFamily:'system-ui'}}>
        <h1 style={{margin:0}}>SxTEST — FAZA7 (local React + Vite)</h1>
        <nav style={{marginTop:'.5rem'}}>
          <NavLink to="/" style={{marginRight:12}}>Acasă</NavLink>
          <NavLink to="/courses">Cursuri</NavLink>
        </nav>
      </header>
      <main style={{padding:'1rem', fontFamily:'system-ui', color:'#e6e9ef', background:'#0b1020', minHeight:'100vh'}}>
        <Suspense fallback={<p>Se încarcă…</p>}>
          <Routes>
            <Route path="/" element={<p>Bine ai venit! React local, fără CDN/inline. API via proxy: /api/*</p>} />
            <Route path="/courses" element={<Courses />} />
            <Route path="/course/:id" element={<Lessons />} />
          </Routes>
        </Suspense>
      </main>
    </HashRouter>
  )
}
