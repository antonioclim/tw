import express from 'express'
const app = express()
const PORT = process.env.PORT || 3007

const courses = [
  { id:1, title:'React Basics', lang:'en', lessons:2 },
  { id:2, title:'JS Refresher', lang:'ro', lessons:1 }
]
const lessons = {
  1: [
    { id:11, title:'Components', lang:'en', duration:8, html:'<p>Components…</p>' },
    { id:12, title:'State & Props', lang:'en', duration:9, html:'<p>State & Props…</p>' }
  ],
  2: [
    { id:21, title:'Functions', lang:'ro', duration:7, html:'<p>Functions…</p>' }
  ]
}
app.get('/api/courses', (_req,res)=> res.json(courses))
app.get('/api/courses/:id/lessons', (req,res)=> res.json(lessons[req.params.id] || []))
app.listen(PORT, ()=> console.log(`[FAZA7 API] http://localhost:${PORT} (UI: http://localhost:5173)`))
