import express from 'express'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()
const PORT = process.env.PORT || 3009

app.use('/public', express.static(path.join(__dirname,'..','public')))
app.get('/', (_req,res)=> res.sendFile(path.join(__dirname,'..','public','index.html')))
app.get('/favicon.ico', (_req,res)=> res.status(204).end())

app.listen(PORT, ()=> console.log(`[FAZA9] http://localhost:${PORT}`))
