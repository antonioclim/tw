FAZA9 — server hotfix
1) Copiază `server/index.js` peste Z:\tw\SxTEST\FAZA9\server\index.js
2) (opțional) Dacă nu ai /public/index.html, copiază-l pe acesta (minim) și apoi pune varianta patch (index.html + styles.css + main.js).
3) Rulează: npm run dev  →  http://localhost:3009
