import express from 'express'
import http from 'node:http'
import { URL } from 'node:url'

const app = express()
const PORT = process.env.PORT || 3009
const F6 = 'http://localhost:3006'

// static
app.use('/public', express.static(new URL('../public', import.meta.url).pathname))
app.get('/', (_req,res)=> res.sendFile(new URL('../public/index.html', import.meta.url).pathname))
app.get('/favicon.ico', (_req,res)=> res.status(204).end())

// proxy (very simple) to FAZA6 to avoid CORS
app.get('/proxy/courses', (req,res)=> proxy(`${F6}/api/courses`, res))
app.get('/proxy/courses/:id/lessons', (req,res)=> proxy(`${F6}/api/courses/${req.params.id}/lessons`, res))

function proxy(target, res){
  const u = new URL(target)
  const opts = { hostname: u.hostname, port: u.port, path: u.pathname + u.search, method: 'GET' }
  const rq = http.request(opts, rr=>{
    res.statusCode = rr.statusCode || 502
    for(const [k,v] of Object.entries(rr.headers)) res.setHeader(k, v)
    rr.pipe(res)
  })
  rq.on('error', err=> res.status(502).json({ error:{ code:'BAD_GATEWAY', message:String(err) } }))
  rq.end()
}

app.listen(PORT, ()=> console.log(`[FAZA9 advanced] http://localhost:${PORT}  (proxy → ${F6})`))
