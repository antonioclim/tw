// Patch snippet for FAZA9/public/main.js (add near other button bindings)
const clearBtn = document.getElementById('clear');
clearBtn.addEventListener('click', ()=>{
  rows = [];
  totalDuration = 0;
  state.page = 1;
  if (typeof saveState === 'function') saveState();
  render();
  if (typeof status === 'function') status('Table cleared. Import a JSON or switch source.', false);
});
