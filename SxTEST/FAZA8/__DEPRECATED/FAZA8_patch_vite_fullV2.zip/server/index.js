import express from 'express'
const app=express(); const PORT=process.env.PORT||3008;
app.get('/',(_req,res)=>res.type('text/plain').send('[FAZA8] UI: http://localhost:5174 (Vite).'));
app.get('/favicon.ico',(_req,res)=>res.status(204).end());
app.listen(PORT,()=>console.log(`[FAZA8 helper] http://localhost:${PORT} (UI: http://localhost:5174)`));
