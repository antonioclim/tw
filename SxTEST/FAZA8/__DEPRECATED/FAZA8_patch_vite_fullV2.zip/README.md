# FAZA8 — Patch (Vite + local React/Redux Toolkit)
Data: 2025-09-24

Rulare:
```
cd /d Z:\tw\SxTEST\FAZA8
npm install
npm run dev
# UI: http://localhost:5174
```
