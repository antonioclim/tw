# FAZA0 — Server minimal
## Rulare
```powershell
cd /d Z:\tw\SxTEST\FAZA0
npm install
npm run dev
```
Apoi deschide http://localhost:3000 și testează butonul /ping.
