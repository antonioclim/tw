const btn=document.getElementById('ping'); const out=document.getElementById('out');
btn?.addEventListener('click', async ()=>{
  out.textContent='Cerere către /ping...';
  const r = await fetch('/ping'); out.textContent = `Răspuns: ${await r.text()} (HTTP ${r.status})`;
});