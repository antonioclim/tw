import { describe, it, expect } from "vitest";
describe("sanity", () => {
  it("adds correctly", () => { expect(2+2).toBe(4); });
});