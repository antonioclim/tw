# FAZA1 — API /api/health + test unit
## Rulare
```powershell
cd /d Z:\tw\SxTEST\FAZA1
npm install
npm run dev
```
Deschide http://localhost:3001 — în consolă vei vedea JSON-ul de la /api/health.
## Teste
```powershell
npm test
```
