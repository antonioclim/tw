import { describe, it, expect } from 'vitest';
// Contract simplu: cursurile trebuie să aibă id,title,lang,lessons
const sample = [
  { id: 1, title: 'T', lang:'ro', lessons: 2, tags:['x'] },
  { id: 2, title: 'U', lang:'en', lessons: 1 }
];
describe('contract curs', ()=>{
  it('are câmpuri cerute', ()=>{
    for(const c of sample){
      expect(c).toHaveProperty('id');
      expect(c).toHaveProperty('title');
      expect(['ro','en']).toContain(c.lang);
      expect(typeof c.lessons).toBe('number');
    }
  });
});