import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { actions, selectAvgScore, selectTopK } from './store.js'

export default function App(){
  const dispatch = useDispatch()
  const avg = useSelector(selectAvgScore)
  const top = useSelector(selectTopK(3))
  return (
    <>
      <header><h1>SxTEST — FAZA11</h1></header>
      <main>
        <div className="card">
          <h2>Redux Toolkit (persist parțial & selectors)</h2>
          <p>Scor mediu: <b>{avg}</b></p>
          <div style={{display:'flex', gap:'.5rem', flexWrap:'wrap'}}>
            <button onClick={()=> dispatch(actions.mark({id:101,score:80}))}>Mark 101:80</button>
            <button onClick={()=> dispatch(actions.mark({id:102,score:95}))}>Mark 102:95</button>
            <button onClick={()=> dispatch(actions.reset())}>Reset</button>
          </div>
          <pre>{JSON.stringify(top, null, 2)}</pre>
        </div>
      </main>
    </>
  )
}
