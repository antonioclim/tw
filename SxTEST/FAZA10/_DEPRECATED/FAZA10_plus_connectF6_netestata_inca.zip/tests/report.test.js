import { describe, it, expect } from 'vitest'
import { aggregate, toCSV, sortRows, filterRows, paginate } from '../src/lib/report.js'

describe('aggregate', ()=>{
  it('computes avg and total', ()=>{
    const lessons=[{id:1,title:'A',lang:'ro',duration:5},{id:2,title:'B',lang:'en',duration:7}]
    const prog=[{lessonId:1,score:80},{lessonId:1,score:100},{lessonId:2,score:70}]
    const r=aggregate(lessons,prog)
    expect(r.rows.length).toBe(2); expect(r.rows.find(x=>x.lessonId===1).avgScore).toBe(90)
  })
})
describe('toCSV', ()=>{
  it('includes BOM and quotes', ()=>{
    const csv = toCSV([{lessonId:1,title:'A,B',lang:'ro',duration:5,avgScore:90}])
    expect(csv.charCodeAt(0)).toBe(0xFEFF); expect(csv).toContain('"A,B"')
  })
})
describe('sort/filter/paginate', ()=>{
  const base=[{title:'B',lang:'ro',avgScore:70},{title:'A',lang:'en',avgScore:90},{title:'C',lang:'ro',avgScore:60}]
  it('sorts asc', ()=>{ expect(sortRows(base,{key:'title',dir:'asc'})[0].title).toBe('A') })
  it('filters', ()=>{ expect(filterRows(base,{q:'',lang:'ro',minScore:65}).length).toBe(1) })
  it('paginates', ()=>{ expect(paginate([1,2,3,4],{page:2,perPage:2})).toEqual([3,4]) })
})
