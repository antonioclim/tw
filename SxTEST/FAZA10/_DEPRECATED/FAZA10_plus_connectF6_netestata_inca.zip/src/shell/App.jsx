import React from 'react'
import { NavLink, Outlet } from 'react-router-dom'

export default function App(){
  const style = ({isActive}) => ({ textDecoration: isActive? 'underline double':'underline' })
  return (<>
    <header>
      <h1>SxTEST — FAZA10 Plus</h1>
      <nav>
        <NavLink to="/courses" style={style}>Cursuri</NavLink>
        <NavLink to="/report" style={style}>Report</NavLink>
      </nav>
    </header>
    <main><Outlet/></main>
  </>)
}
