import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

export default function Courses(){
  const [data,setData] = useState([])
  const [q,setQ] = useState(''); const [lang,setLang] = useState('')

  async function load(){
    try{
      const r = await fetch('/proxy/courses'); if(!r.ok) throw new Error('bad gateway')
      const courses = await r.json()
      setData(courses)
    }catch(e){
      // fallback demo list
      setData([{id:1,title:'JS Basics',lang:'ro',lessons:2},{id:2,title:'HTTP & REST',lang:'en',lessons:1},{id:3,title:'Modules',lang:'ro',lessons:3}])
    }
  }
  useEffect(()=>{ load() },[])

  const list = data.filter(c => (!q || c.title.toLowerCase().includes(q.toLowerCase())) && (!lang || c.lang===lang))
  return <div className="card">
    <h2>Cursuri</h2>
    <div className="controls">
      <input placeholder="Caută..." value={q} onChange={e=>setQ(e.target.value)}/>
      <select value={lang} onChange={e=>setLang(e.target.value)}><option value="">(toate)</option><option>ro</option><option>en</option></select>
    </div>
    <table><thead><tr><th>Title</th><th>Lang</th><th>Lessons</th></tr></thead>
      <tbody>{list.map(c=> <tr key={c.id}>
        <td><Link to={`/lesson/${c.id}`}>{c.title}</Link></td><td>{c.lang}</td><td>{c.lessons ?? '—'}</td>
      </tr>)}</tbody>
    </table>
  </div>
}
