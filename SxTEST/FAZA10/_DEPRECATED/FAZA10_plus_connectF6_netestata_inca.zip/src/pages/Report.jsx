import React, { useEffect, useState } from 'react'
import { aggregate, toCSV, toExcelXML, sortRows, filterRows, paginate, dl } from '../lib/report.js'

export default function Report(){
  const [lessons,setLessons]=useState([])
  const [progress,setProgress]=useState([ // demo progress; înlocuiește cu /proxy/progress când există
    {user:'u1',lessonId:11,score:80},{user:'u1',lessonId:12,score:60},{user:'u2',lessonId:11,score:90}
  ])
  const [q,setQ]=useState(''); const [lang,setLang]=useState(''); const [minScore,setMinScore]=useState(0)
  const [sort,setSort]=useState({key:'title',dir:'asc'}); const [page,setPage]=useState(1); const [perPage,setPerPage]=useState(20)

  useEffect(()=>{
    async function load(){
      try{
        const r = await fetch('/proxy/courses'); if(!r.ok) throw new Error('bad gateway')
        const courses = await r.json()
        const res=[]; for(const c of courses){ const rr=await fetch(`/proxy/courses/${c.id}/lessons`); if(rr.ok){ const ls=await rr.json(); for(const l of ls) res.push({id:l.id,title:l.title,lang:l.lang,duration:l.duration}) } }
        setLessons(res)
      }catch(e){ setLessons([]) }
    }
    load()
  },[])

  const agg = aggregate(lessons, progress)
  const state = { q, lang, minScore, sort, page, perPage }
  const filtered = filterRows(sortRows(agg.rows, sort), state)
  const pages = Math.max(1, Math.ceil(filtered.length / perPage))
  const pageRows = paginate(filtered, state)

  function exportPDF(){
    const tableHTML = document.getElementById('rptTable')?.outerHTML || ''
    const style = `<style>body{font-family:system-ui;color:#111;margin:1rem}table{border-collapse:collapse;width:100%}th,td{border:1px solid #999;padding:6px 8px}</style>`
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>FAZA10 Report</title>${style}</head><body>${tableHTML}</body></html>`
    let w=null; try{ w=window.open('','_blank','noopener,noreferrer,width=1024,height=768') }catch{}
    if(w && w.document){ w.document.open(); w.document.write(html); w.document.close(); w.focus(); setTimeout(()=> w.print(), 250); return; }
    const iframe=document.createElement('iframe'); iframe.style.width='0'; iframe.style.height='0'; document.body.appendChild(iframe);
    const doc=iframe.contentDocument||iframe.contentWindow.document; doc.open(); doc.write(html); doc.close(); setTimeout(()=>{ doc.defaultView.print(); document.body.removeChild(iframe) },300);
  }

  return <div className="card">
    <h2>Report</h2>
    <div className="controls">
      <input placeholder="Caută..." value={q} onChange={e=>{setQ(e.target.value); setPage(1)}}/>
      <select value={lang} onChange={e=>{setLang(e.target.value); setPage(1)}}><option value="">(toate)</option><option>ro</option><option>en</option></select>
      <label>Scor minim: <input type="number" min="0" max="100" value={minScore} onChange={e=>{setMinScore(Number(e.target.value)||0); setPage(1)}} style={{width:'5rem'}}/></label>
      <label>Per pagină: <select value={perPage} onChange={e=>{setPerPage(Number(e.target.value)); setPage(1)}}><option>10</option><option>20</option><option>50</option></select></label>
    </div>
    <table id="rptTable"><thead><tr><th onClick={()=>setSort({key:'title',dir:sort.key==='title'&&sort.dir==='asc'?'desc':'asc'})}>Title</th><th onClick={()=>setSort({key:'lang',dir:sort.key==='lang'&&sort.dir==='asc'?'desc':'asc'})}>Lang</th><th onClick={()=>setSort({key:'duration',dir:sort.key==='duration'&&sort.dir==='asc'?'desc':'asc'})}>Duration</th><th onClick={()=>setSort({key:'avgScore',dir:sort.key==='avgScore'&&sort.dir==='asc'?'desc':'asc'})}>Avg</th></tr></thead>
      <tbody>{pageRows.map(r=> <tr key={r.lessonId}><td>{r.title}</td><td>{r.lang}</td><td>{r.duration}</td><td>{r.avgScore}</td></tr>)}</tbody></table>
    <div className="controls">
      <button onClick={()=> setPage(p=> Math.max(1,p-1))}>Prev</button>
      <span> Pagina {page}/{pages} </span>
      <button onClick={()=> setPage(p=> Math.min(pages,p+1))}>Next</button>
    </div>
    <div className="export">
      <button onClick={()=> dl('report.csv', toCSV(filtered))}>Export CSV</button>
      <button onClick={()=> dl('report.xls', toExcelXML(filtered), 'application/vnd.ms-excel')}>Export Excel</button>
      <button onClick={exportPDF}>Export PDF</button>
    </div>
  </div>
}
