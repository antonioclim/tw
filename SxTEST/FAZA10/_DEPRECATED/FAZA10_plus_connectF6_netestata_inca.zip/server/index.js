import express from 'express'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import http from 'node:http'
const __filename=fileURLToPath(import.meta.url); const __dirname=path.dirname(__filename);
const app=express(); const PORT=process.env.PORT||3010; const F6='http://localhost:3006'
app.get('/',(_req,res)=> res.type('text/plain').send('[FAZA10+ helper] UI: http://localhost:5176/#/  |  Proxy: /proxy/* -> '+F6))
app.get('/favicon.ico',(_req,res)=> res.status(204).end())
// minimal proxy to FAZA6 (avoid CORS)
app.get('/proxy/courses',(_req,res)=> proxy(`${F6}/api/courses`,res))
app.get('/proxy/courses/:id/lessons',(req,res)=> proxy(`${F6}/api/courses/${req.params.id}/lessons`,res))
function proxy(target,res){
  const u=new URL(target); const opt={hostname:u.hostname,port:u.port,path:u.pathname+u.search,method:'GET'}
  const rq=http.request(opt, rr=>{ res.writeHead(rr.statusCode||502, rr.headers); rr.pipe(res) })
  rq.on('error', err=> res.status(502).json({error:{code:'BAD_GATEWAY',message:String(err)}})); rq.end()
}
app.listen(PORT,()=> console.log(`[FAZA10+ helper] http://localhost:${PORT}  (UI http://localhost:5176/#/)`))
