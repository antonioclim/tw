import React from 'react'
export default function About(){
  return <div className="card"><h2>Acasă</h2><p>Interfață React locală (fără CDN), rulată cu Vite. Meniul de sus comută între pagini.</p></div>
}
