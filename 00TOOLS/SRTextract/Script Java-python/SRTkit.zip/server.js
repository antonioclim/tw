// server.js
// Backend Node.js/Express pe portul 8080 pentru transcrierea tuturor fisierelor MP4
// dintr-un director, folosind scriptul Python transcribe_fw.py (faster-whisper).

const express = require('express');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

const app = express();
const PORT = 8080;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Candidati posibili pentru comanda Python in PATH
const PYTHON_CANDIDATES = ['py', 'python', 'python3'];

// Detecteaza prima comanda Python functionala
function detectPython() {
  return new Promise((resolve, reject) => {
    let index = 0;

    function tryNext() {
      if (index >= PYTHON_CANDIDATES.length) {
        return reject(new Error(
          'Nu am gasit nicio comanda Python (py/python/python3) in PATH. ' +
          'Instalati Python 3 si asigurati-va ca este in PATH (vezi pasii din README).'
        ));
      }

      const cmd = PYTHON_CANDIDATES[index++];
      const p = spawn(cmd, ['--version']);

      p.on('close', (code) => {
        if (code === 0) {
          console.log(`Folosesc Python: ${cmd}`);
          return resolve(cmd);
        }
        tryNext();
      });

      p.on('error', () => {
        tryNext();
      });
    }

    tryNext();
  });
}

let cachedPythonCmd = null;

async function getPythonCmd() {
  if (!cachedPythonCmd) {
    cachedPythonCmd = await detectPython();
  }
  return cachedPythonCmd;
}

// Ruleaza transcrierea pentru UN fisier, apelind scriptul Python transcribe_fw.py
function runTranscriptionForFile(pythonCmd, videoPath, outPath, options) {
  return new Promise((resolve, reject) => {
    const {
      fmt,
      model,
      device,
      compute,
      language,
    } = options;

    const scriptPath = path.join(__dirname, 'transcribe_fw.py');

    const args = [
      scriptPath,
      '--input', videoPath,
      '--output', outPath,
      '--fmt', fmt,
      '--model', model,
      '--device', device,
      '--compute', compute,
      '--language', language,
    ];

    console.log('Pornesc transcrierea:', pythonCmd, args.join(' '));

    const child = spawn(pythonCmd, args, {
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    let stdout = '';
    let stderr = '';

    child.stdout.on('data', (d) => {
      const text = d.toString();
      stdout += text;
      process.stdout.write(text);
    });

    child.stderr.on('data', (d) => {
      const text = d.toString();
      stderr += text;
      process.stderr.write(text);
    });

    child.on('close', (code) => {
      if (code === 0) {
        return resolve({ ok: true, stdout, stderr });
      }
      return reject(new Error(
        `Transcriere esuata (cod ${code}) pentru ${videoPath}\n${stderr}`
      ));
    });

    child.on('error', (err) => {
      return reject(err);
    });
  });
}

// Endpoint principal: transcrierea tuturor .mp4 dintr-un director
app.post('/api/transcribe', async (req, res) => {
  try {
    const {
      directory,
      fmt = 'srt',
      model = 'large-v3',
      device = 'cpu',
      compute = 'int8',
      language = 'ro',
    } = req.body || {};

    if (!directory) {
      return res.status(400).json({ error: 'Campul "directory" este obligatoriu.' });
    }

    const absDir = path.resolve(directory);
    if (!fs.existsSync(absDir) || !fs.statSync(absDir).isDirectory()) {
      return res.status(400).json({
        error: `Directorul nu exista sau nu este director: ${absDir}`,
      });
    }

    const files = fs.readdirSync(absDir)
      .filter((name) => name.toLowerCase().endsWith('.mp4'));

    if (files.length === 0) {
      return res.status(400).json({ error: 'Nu am gasit fisiere .mp4 in directorul indicat.' });
    }

    const pythonCmd = await getPythonCmd();

    const results = [];
    // Rulam serial pentru a nu suprasolicita CPU/GPU
    for (const file of files) {
      const videoPath = path.join(absDir, file);
      const base = file.replace(/\.[^.]+$/, '');
      const outExt = fmt === 'txt' ? '.txt' : '.srt';
      const outPath = path.join(absDir, base + outExt);

      try {
        await runTranscriptionForFile(pythonCmd, videoPath, outPath, {
          fmt,
          model,
          device,
          compute,
          language,
        });
        results.push({
          file,
          output: path.basename(outPath),
          status: 'ok',
        });
      } catch (err) {
        console.error(err);
        results.push({
          file,
          status: 'error',
          message: err.message,
        });
      }
    }

    return res.json({
      directory: absDir,
      model,
      device,
      compute,
      language,
      fmt,
      count: results.length,
      results,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      error: err.message || 'Eroare interna.',
      hint: 'Verificati pasii de instalare pentru Python / ffmpeg / faster-whisper din README.',
    });
  }
});

app.listen(PORT, () => {
  console.log(`Serverul ruleaza la http://localhost:${PORT}`);
});
