# transcribe_fw.py
# Script Python care foloseste faster-whisper pentru a transcrie un fisier audio/video
# intr-un fisier .srt sau .txt.

from faster_whisper import WhisperModel
from pathlib import Path
from typing import Iterable
import argparse


def srt_ts(seconds: float) -> str:
    if seconds < 0:
        seconds = 0
    millis = int(round(seconds * 1000))
    hours, millis = divmod(millis, 3600 * 1000)
    minutes, millis = divmod(millis, 60 * 1000)
    secs, millis = divmod(millis, 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


def write_srt(segments: Iterable, path: str) -> None:
    out = Path(path)
    lines = []
    for i, seg in enumerate(segments, start=1):
        lines.append(f"{i}")
        lines.append(f"{srt_ts(seg.start)} --> {srt_ts(seg.end)}")
        lines.append(seg.text.strip())
        lines.append("")  # linie goala intre intrari
    out.write_text("\n".join(lines), encoding="utf-8")


def write_txt(segments: Iterable, path: str) -> None:
    out = Path(path)
    text = " ".join(seg.text.strip() for seg in segments).strip() + "\n"
    out.write_text(text, encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="Fisier video/audio de intrare")
    ap.add_argument("--output", required=True, help="Fisier iesire (SRT sau TXT)")
    ap.add_argument("--fmt", choices=["srt", "txt"], default="srt")
    ap.add_argument("--model", default="large-v3", help="Numele modelului faster-whisper (ex: large-v3, medium)")
    ap.add_argument("--device", default="cpu", help="cpu / cuda / auto")
    ap.add_argument("--compute", default="int8", help="Tip compute_type (int8, int8_float16, float16, etc.)")
    ap.add_argument(
        "--language",
        default="ro",
        help="Cod limba (ISO 639-1: ro, en, fr etc.) sau 'auto' pentru autodetectie",
    )
    args = ap.parse_args()

    input_path = Path(args.input)
    if not input_path.is_file():
        raise SystemExit(f"Fisierul de intrare nu exista: {input_path}")

    # limba None => autodetectie
    language = None if args.language.lower() == "auto" else args.language

    try:
        model = WhisperModel(
            args.model,
            device=args.device,
            compute_type=args.compute,
        )
    except Exception as e:
        raise SystemExit(f"Eroare la initializarea modelului Whisper: {e}") from e

    segments, info = model.transcribe(
        str(input_path),
        language=language,
        vad_filter=True,
        beam_size=5,
    )

    segs = list(segments)

    if args.fmt == "srt":
        write_srt(segs, args.output)
    else:
        write_txt(segs, args.output)


if __name__ == "__main__":
    main()
