# e01_ro

This project reproduces the routing example from the provided script.

## Run

```bash
npm install
npm start
```

## Routes

- `/` → Home
- `/tasks` → Tasks
- `/tasks/:id` → Tasks (parameter displayed)
- `*` → NotFound
