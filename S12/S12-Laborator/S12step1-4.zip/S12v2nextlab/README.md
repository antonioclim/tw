# e01_ro (S12v2)

This Create React App project demonstrates:

- **React Router** (from the earlier lesson) to switch between pages/components.
- **`useReducer`** (S12v2) inside `src/components/Tasks.js` to manage a compound state:
  - `count`
  - `history` (an array of all successive counter values)

## Routes

- `/` → Home
- `/tasks` → Tasks (useReducer demo)
- `/tasks/:id` → Tasks (route still resolves, but S12v2 no longer uses route parameters)
- `*` → NotFound

## Run

```bash
npm install
npm start
```
