# S12 • Step 4 • Redux (async actions)

This step is part of the **Seminar 12 – Redux** teaching kit.

## Run (Windows PowerShell / CMD)

```bash
npm install
npm start
```

By default the dev server runs on port **3004**.
When started from the dashboard, the port is provided via the `PORT` environment variable.
