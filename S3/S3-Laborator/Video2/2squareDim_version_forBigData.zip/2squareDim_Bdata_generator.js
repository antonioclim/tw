
/**
 * 2squareDim_data_gen.js
 * Generator simplu de fişiere cu lungimi de laturi (un număr pe linie).
 * Utilizare: node 2squareDim_data_gen.js 5000000 sides.txt
 */
const fs = require("fs");

const n = Number(process.argv[2] || 1e6);
const out = process.argv[3] || "sides.txt";
const stream = fs.createWriteStream(out, { encoding: "utf8" });

for (let i = 0; i < n; i++) {
  const s = 1 + Math.floor(Math.random() * 100);
  stream.write(String(s) + "\n");
}
stream.end(() => console.log("Wrote", n, "lines to", out));
