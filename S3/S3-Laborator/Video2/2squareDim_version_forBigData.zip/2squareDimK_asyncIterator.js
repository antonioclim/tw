
/**
 * 2squareDimK_asyncIterator.js
 * Demonstraţie a unui generator asincron care expune o sursă arbitrară
 * de numere (ex. un cursor de BD, o paginare de API sau un fişier citit incremental).
 */

async function *numbersFromIterable(iterable) {
  for await (const x of iterable) {
    const v = Number(x);
    if (Number.isFinite(v)) yield v;
  }
}

async function totalAreaFromIterator(asyncNumbers) {
  let total = 0;
  let n = 0;
  for await (const s of asyncNumbers) {
    total += s * s;
    n++;
  }
  return { total, n };
}

// Demo: dintr-un array mare "paged" (simulăm un iterator asincron)
async function *pagedArray(arr, pageSize = 1000) {
  for (let i = 0; i < arr.length; i += pageSize) {
    const page = arr.slice(i, i + pageSize);
    // simulăm I/O asincron
    await new Promise(r => setTimeout(r, 0));
    for (const x of page) yield x;
  }
}

async function demo() {
  const data = Array.from({length: 100_000}, (_, i) => (i % 10) + 1);
  const res = await totalAreaFromIterator(numbersFromIterable(pagedArray(data, 4096)));
  console.log(res); // { total: ..., n: 100000 }
}

if (require.main === module) demo();

module.exports = { numbersFromIterable, totalAreaFromIterator, pagedArray };
