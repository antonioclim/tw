
/**
 * 2squareDimJ_stream.js
 * Streaming & iterator approach for very large datasets.
 *
 * Caracteristici:
 * - Citeşte un flux de date (fişier sau STDIN) linie cu linie, fără a încărca totul în memorie.
 * - Acceptă atât un număr pe linie, cât şi linii cu mai multe numere (CSV/whitespace).
 * - Foloseşte iteratorul asincron oferit de `readline.Interface` (for-await-of).
 * - Igienă minimă: conversie la Number şi filtrare non-finite.
 *
 * Utilizare:
 *   node 2squareDimJ_stream.js --file sides.txt
 *   cat sides.txt | node 2squareDimJ_stream.js
 *
 * Format intrare:
 *   - fie un număr pe linie (ex. 3)
 *   - fie linii cu mai multe numere separate prin virgulă/spaţii (ex. 3,5,12  3   5 3)
 *
 * Observaţii:
 * - Complexitate timp O(n), spaţiu O(1) extra; se menţin doar câteva variabile scalare.
 * - Pentru performanţă maximă evitaţi expresii regex costisitoare pe linii foarte lungi.
 */

const fs = require("fs");
const readline = require("readline");
const { stdin, stdout } = process;

// regex tolerant pentru a extrage numere dintr-o linie
const NUM = /[-+]?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?/gi;

function *tokensFromLine(line) {
  // returnează iterator de stringuri numerice găsite în linie
  const matches = line.match(NUM);
  if (!matches) return;
  for (const m of matches) yield m;
}

async function getTotalAreaFromStream(readable) {
  const rl = readline.createInterface({ input: readable, crlfDelay: Infinity });
  let total = 0;
  let count = 0;
  let invalid = 0;

  for await (const line of rl) {
    for (const tok of tokensFromLine(line) || []) {
      const s = Number(tok);
      if (!Number.isFinite(s)) { invalid++; continue; }
      total += s * s;
      count++;
    }
  }
  return { total, count, invalid };
}

async function main() {
  const args = new Map();
  for (let i = 2; i < process.argv.length; i += 1) {
    const a = process.argv[i];
    if (a.startsWith("--")) {
      const [k, v] = a.includes("=") ? a.slice(2).split("=") : [a.slice(2), process.argv[i+1]];
      if (!a.includes("=")) i += 1;
      args.set(k, v);
    }
  }

  const file = args.get("file");
  const input = file ? fs.createReadStream(file) : stdin;

  const t0 = process.hrtime.bigint();
  const { total, count, invalid } = await getTotalAreaFromStream(input);
  const t1 = process.hrtime.bigint();

  console.log(JSON.stringify({
    total,
    count,
    invalid,
    millis: Number(t1 - t0) / 1e6,
    source: file ? file : "stdin"
  }, null, 2));
}

if (require.main === module) {
  main().catch(err => { console.error(err); process.exit(1); });
}

module.exports = { getTotalAreaFromStream };
