# Pasul 24 — Structură poziționare (HTML)

**Care (ce):** Structură poziționare (HTML)
**Unde:** `index.html` (și `style.css` dacă este cazul)
**De ce / scop:** Înlocuiești secțiunea inline-block cu .position-container.

**Ce arăți în Firefox DevTools**
- Inspector → *Rules/Computed*: verifică proprietățile adăugate.
- Layout (Box Model): pentru pașii cu box/padding/border/margin.
- Responsive Design Mode: pentru a observa efectul la diferite lățimi (după pasul 14).

**Sugestie VS Code**
- Live Server pentru refresh, Prettier pentru formatare, Stylelint pentru validare CSS.
