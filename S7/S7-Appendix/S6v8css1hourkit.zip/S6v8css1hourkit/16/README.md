# Pasul 16 — Line-height

**Care (ce):** Line-height
**Unde:** `style.css` (și `style.css` dacă este cazul)
**De ce / scop:** Îmbunătățești lizibilitatea cu line-height.

**Ce arăți în Firefox DevTools**
- Inspector → *Rules/Computed*: verifică proprietățile adăugate.
- Layout (Box Model): pentru pașii cu box/padding/border/margin.
- Responsive Design Mode: pentru a observa efectul la diferite lățimi (după pasul 14).

**Sugestie VS Code**
- Live Server pentru refresh, Prettier pentru formatare, Stylelint pentru validare CSS.
