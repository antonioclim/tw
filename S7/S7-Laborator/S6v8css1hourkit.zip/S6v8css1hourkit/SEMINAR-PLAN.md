# Plan de seminar (60') — Bloom, pași 01–30

**Scop:** Parcurgere incrementală a CSS (doar nativ), de la atașarea stilurilor la Box Model, poziționare și Flexbox, folosind Firefox DevTools + VS Code.

## Structură temporală
- 0–5': Pașii 01–04 — setup HTML & legare CSS
- 5–15': Pașii 05–11 — stil inline → intern → extern; ID/clasă; primele stiluri
- 15–25': Pașii 12–16 — reset; tipografie; lizibilitate
- 25–35': Pașii 17–21 — Box Model; linkuri block
- 35–45': Pașii 22–27 — inline-block; poziționare (relative/absolute + părinte relativ)
- 45–52': Pas 28 — fixed vs sticky (scroll demo)
- 52–60': Pașii 29–30 — Flexbox (setup + centrare în itemi)

## Bloom (exemple)
- **Înțelegere**: diferența între inline/intern/extern; ce înseamnă box model; specificitate ID vs clasă.
- **Aplicare**: setare `font-size`, `line-height`; configurarea `.box` cu `padding/border/margin`; aliniere cu `display:block` și `inline-block`.
- **Analiză**: efectele poziționării `relative/absolute/sticky`; impactul `box-sizing`; comparația inline-block vs flex.

## Întrebări de ghidaj
- De ce externalizăm CSS? cum ne ajută la mentenanță?
- Cum diferă `absolute` vs `sticky` la scroll? Când alegem fiecare?
- De ce `border-box` e mai intuitiv când planificăm lățimile?
