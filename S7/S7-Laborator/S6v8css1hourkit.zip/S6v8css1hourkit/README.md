# S6v8 — CSS Starterkit (60 min) — Pași numerotați (01–30)

Acest kit conține **30 de pași** numerotați în **ordinea prezentării** pentru seminarul CSS de 60 de minute (bazat strict pe materialele încărcate). Fiecare folder conține starea completă `index.html` + `style.css` **după** aplicarea pasului respectiv, plus un `README.md` scurt cu *ce / unde / de ce / scop*.

## Cum folosești
1. Deschide fiecare folder `01` → `30` în ordinea numerotării.
2. Lansează un server static (ex. *Live Server* din VS Code) și inspectează pagina în Firefox.
3. În **DevTools**: *Inspector → Rules/Computed*, *Layout (Box Model)*, *Color Picker/Contrast*, *Responsive Design Mode* pentru pașii relevanți.
4. Poți comuta între pași pentru a observa incrementalitatea modificărilor.

## Instrumente recomandate
- **Firefox Developer Tools**: Inspector, Rules/Computed, Layout (Box Model), Color/Contrast, Responsive Design Mode.
- **Extensii Firefox**: Web Developer, ColorZilla, axe DevTools.
- **VS Code**: Live Server, Prettier, Stylelint, CSS Peek.

## Index pași
| Pas | Titlu | Scop (succint) |
|-----|-------|-----------------|
| 01 | Structură HTML minimă | Creezi scheletul de bază al paginii. |
| 02 | Metatags + <title> | Adaugi charset, viewport și titlul documentului. |
| 03 | Leagă CSS extern | Conectezi style.css prin <link> în <head>. |
| 04 | Adaugă <h1> | Introduci un titlu vizibil în pagină. |
| 05 | Stil inline pe <h1> | Demonstrezi stilul inline (ex. color: blue). |
| 06 | Stil intern (<style>) | Mută regula în <head> folosind <style>. |
| 07 | Stil extern (style.css) | Mută regula în fișierul CSS extern. |
| 08 | Fundal pentru <body> | Setezi background-color pe body (#333). |
| 09 | ID pe <h1> | Atribui id='title' pentru stilizare țintită. |
| 10 | CSS pe #title | Adaugi background pentru titlu (ex. #777). |
| 11 | Clase & paragrafe | Adaugi .para-text și stilul aferent. |
| 12 | Reset universal | Aplici * { margin:0; padding:0; box-sizing:border-box }. |
| 13 | Culoare RGBA | Schimbi culoarea textului la rgba(...,0.7). |
| 14 | Dimensiune & aliniere titlu | font-size + text-align pentru #title. |
| 15 | Font family & bold | Setezi font pe body și bold pe .para-text. |
| 16 | Line-height | Îmbunătățești lizibilitatea cu line-height. |
| 17 | Box model – container | Adaugi <div class='box'> pentru demo. |
| 18 | Dimensiuni & fundal box | width/height/background pe .box. |
| 19 | Border la box | Adaugi border: 5px solid red. |
| 20 | Padding & margin box | Adaugi padding și margin pe .box. |
| 21 | Linkuri pe linii separate | a { display:block } pentru fiecare link. |
| 22 | Structură inline-block (HTML) | Adaugi 3 div-uri pentru exemplu inline-block. |
| 23 | Stil inline-block (CSS) | display:inline-block + dimensiuni + spacing. |
| 24 | Structură poziționare (HTML) | Înlocuiești secțiunea inline-block cu .position-container. |
| 25 | Position: relative | Mutare controlată față de poziția inițială. |
| 26 | Position: absolute | Iese din flux; poziționare față de body. |
| 27 | Părinte relativ | position:relative pe container – nou context. |
| 28 | Fixed vs Sticky | Demonstrezi fixed și sticky; păstrezi sticky activ. |
| 29 | Structură Flex (HTML) | Înlocuiești containerul de poziționare cu .flex-container. |
| 30 | Flexbox (CSS) | display:flex pe container + centrare în itemi. |
