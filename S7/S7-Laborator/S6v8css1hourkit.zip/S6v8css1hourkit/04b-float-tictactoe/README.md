# 04b – Float Tic‑Tac‑Toe (3×3)

**Obiectiv (Bloom – Aplicare):** obții o grilă 3×3 exclusiv cu **float** și **clearfix**; folosești selectori structurali pentru a marca rândul/coloana centrală.

## Să facem
- Deschide `index.html` cu Live Server.
- Inspectează `.board` și `.cell` în DevTools (Inspector → Rules/Computed; Layout).

## Rulăm
- Vezi grila 3×3; la hover, celula se evidențiază.
- Borduri mai groase pe linia și coloana centrală (selectors `:nth-child`).

## Observăm (DevTools)
- **Layout (Box Model):** cum acționează `box-sizing` asupra lățimilor.
- **Float:** debifează temporar `float:left` pe `.cell` → vezi cele 9 div‑uri afișate pe verticală.
- **Clearfix:** elimină `::after` și observă cum containerul nu‑și mai cuprinde copiii flotanți.

## Exercițiu rapid
- Setează dimensiunea celulelor la `100px` și ajustează lățimea `.board` la `300px`.
- Încearcă o **variantă fără double‑borders**: scoate `border-right` pe celulele din col. 1 și `border-left` pe col. 3; pune un `border` pe `.board` ca ramă exterioară.
