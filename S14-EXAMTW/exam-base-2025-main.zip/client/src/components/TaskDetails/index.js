import TaskDetails from './TaskDetails'

export default TaskDetails
