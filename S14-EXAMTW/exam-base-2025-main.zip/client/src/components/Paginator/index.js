import Paginator from './Paginator'

export default Paginator
