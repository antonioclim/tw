import AuthGuard from './AuthGuard'

export default AuthGuard
