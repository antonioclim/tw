import ErrorDisplay from './ErrorDisplay'

export default ErrorDisplay
