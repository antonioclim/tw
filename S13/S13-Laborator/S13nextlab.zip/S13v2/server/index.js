const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = 8080;

// In-memory "database"
let nextId = 4;
let books = [
  { id: 1, title: 'React', content: 'Components, props, state' },
  { id: 2, title: 'Redux', content: 'Store, actions, reducers' },
  { id: 3, title: 'PrimeReact', content: 'DataTable, Dialog, Buttons' },
];

function normaliseString(x) {
  return (x ?? '').toString().toLowerCase();
}

function filterBooks(query) {
  let result = books;

  if (query.title) {
    const t = normaliseString(query.title);
    result = result.filter(b => normaliseString(b.title).includes(t));
  }

  if (query.content) {
    const c = normaliseString(query.content);
    result = result.filter(b => normaliseString(b.content).includes(c));
  }

  return result;
}

function responsePayload(query) {
  const records = filterBooks(query);
  return {
    count: records.length,
    records
  };
}

app.get('/', (req, res) => {
  res.json({
    name: 'S13v2 Books API',
    endpoints: [
      'GET    /books?title=...&content=...',
      'POST   /books',
      'PUT    /books/:id',
      'DELETE /books/:id'
    ]
  });
});

app.get('/books', (req, res) => {
  res.json(responsePayload(req.query));
});

app.post('/books', (req, res) => {
  const { title, content } = req.body || {};
  if (typeof title !== 'string' || typeof content !== 'string') {
    return res.status(400).json({ message: 'Both title and content must be strings.' });
  }

  const book = { id: nextId++, title, content };
  books.push(book);

  res.json(responsePayload(req.query));
});

app.put('/books/:id', (req, res) => {
  const id = Number(req.params.id);
  const { title, content } = req.body || {};

  const idx = books.findIndex(b => b.id === id);
  if (idx === -1) {
    return res.status(404).json({ message: 'Book not found.' });
  }
  if (typeof title !== 'string' || typeof content !== 'string') {
    return res.status(400).json({ message: 'Both title and content must be strings.' });
  }

  books[idx] = { ...books[idx], title, content };
  res.json(responsePayload(req.query));
});

app.delete('/books/:id', (req, res) => {
  const id = Number(req.params.id);
  const idx = books.findIndex(b => b.id === id);
  if (idx === -1) {
    return res.status(404).json({ message: 'Book not found.' });
  }
  books.splice(idx, 1);
  res.json(responsePayload(req.query));
});

app.listen(PORT, () => {
  console.log(`S13v2 Books API listening on http://localhost:${PORT}`);
});
