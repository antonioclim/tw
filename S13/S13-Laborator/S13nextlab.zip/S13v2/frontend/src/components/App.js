import BookList from './BookList';

function App() {
  return (
    <div style={{ padding: '1rem' }}>
      <h2>S13v2 — PrimeReact DataTable + Redux (Filtering)</h2>
      <BookList />
    </div>
  );
}

export default App;
