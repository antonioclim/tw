const SERVER = 'http://localhost:8080';

// NOTE: BookList keeps filter state locally. To keep add/save/delete consistent with the current
// filter, we remember the most recently used filterString from getBooks().
let lastFilterString = '';

const buildQuery = (filterString) => {
  if (!filterString) return '';
  return filterString.startsWith('?') ? filterString : `?${filterString}`;
};

const asJsonOrThrow = async (response) => {
  const contentType = response.headers.get('content-type') || '';
  const isJson = contentType.includes('application/json');

  if (!response.ok) {
    const body = isJson ? await response.json().catch(() => ({})) : await response.text().catch(() => '');
    const message = (body && body.message) ? body.message : `HTTP ${response.status}`;
    const error = new Error(message);
    error.status = response.status;
    error.body = body;
    throw error;
  }

  return isJson ? response.json() : response.text();
};

export function getBooks(filterString = '') {
  lastFilterString = filterString || '';
  return {
    type: 'GET_BOOKS',
    payload: fetch(`${SERVER}/books${buildQuery(filterString)}`)
      .then(asJsonOrThrow)
  };
}

export function addBook(book) {
  return {
    type: 'ADD_BOOK',
    payload: fetch(`${SERVER}/books${buildQuery(lastFilterString)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(book)
    }).then(asJsonOrThrow)
  };
}

export function saveBook(id, book) {
  return {
    type: 'SAVE_BOOK',
    payload: fetch(`${SERVER}/books/${id}${buildQuery(lastFilterString)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(book)
    }).then(asJsonOrThrow)
  };
}

export function deleteBook(id) {
  return {
    type: 'DELETE_BOOK',
    payload: fetch(`${SERVER}/books/${id}${buildQuery(lastFilterString)}`, {
      method: 'DELETE'
    }).then(asJsonOrThrow)
  };
}
