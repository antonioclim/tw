# Frontend (React + Redux + PrimeReact)

## Run

1. Install dependencies

```bash
npm install
```

2. Start the dev server

```bash
npm start
```

> The frontend expects the API server at `http://localhost:8080`.
