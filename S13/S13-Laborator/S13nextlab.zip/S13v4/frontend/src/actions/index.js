const SERVER = 'http://localhost:8080';

function buildBooksUrl(filterString = '', page = 0, pageSize = 2, sortField = '', sortOrder = 1) {
  const params = new URLSearchParams(filterString || '');
  params.set('page', String(page ?? 0));
  params.set('pageSize', String(pageSize ?? 2));

  if (sortField) {
    params.set('sortField', sortField);
    params.set('sortOrder', String(sortOrder ?? 1));
  }

  return `${SERVER}/books?${params.toString()}`;
}

export const getBooks = (filterString = '', page = 0, pageSize = 2, sortField = '', sortOrder = 1) => async (dispatch) => {
  dispatch({ type: 'GET_BOOKS_PENDING' });
  try {
    const response = await fetch(buildBooksUrl(filterString, page, pageSize, sortField, sortOrder));
    if (!response.ok) {
      throw new Error(`GET /books failed with status ${response.status}`);
    }
    const data = await response.json();
    dispatch({ type: 'GET_BOOKS_FULFILLED', payload: data });
  } catch (err) {
    dispatch({ type: 'GET_BOOKS_REJECTED', payload: err?.message ?? String(err) });
  }
};

export const addBook = (book) => async (dispatch) => {
  dispatch({ type: 'ADD_BOOK_PENDING' });
  try {
    const response = await fetch(`${SERVER}/books`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(book)
    });
    if (!response.ok) {
      throw new Error(`POST /books failed with status ${response.status}`);
    }
    // Refresh the list (default first page) after successful mutation
    const listResponse = await fetch(buildBooksUrl('', 0, 2, '', 1));
    const data = await listResponse.json();
    dispatch({ type: 'ADD_BOOK_FULFILLED', payload: data });
  } catch (err) {
    dispatch({ type: 'ADD_BOOK_REJECTED', payload: err?.message ?? String(err) });
  }
};

export const saveBook = (id, book) => async (dispatch) => {
  dispatch({ type: 'SAVE_BOOK_PENDING' });
  try {
    const response = await fetch(`${SERVER}/books/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(book)
    });
    if (!response.ok) {
      throw new Error(`PUT /books/${id} failed with status ${response.status}`);
    }
    // Refresh the list (default first page) after successful mutation
    const listResponse = await fetch(buildBooksUrl('', 0, 2, '', 1));
    const data = await listResponse.json();
    dispatch({ type: 'SAVE_BOOK_FULFILLED', payload: data });
  } catch (err) {
    dispatch({ type: 'SAVE_BOOK_REJECTED', payload: err?.message ?? String(err) });
  }
};

export const deleteBook = (id) => async (dispatch) => {
  dispatch({ type: 'DELETE_BOOK_PENDING' });
  try {
    const response = await fetch(`${SERVER}/books/${id}`, {
      method: 'DELETE'
    });
    if (!response.ok) {
      throw new Error(`DELETE /books/${id} failed with status ${response.status}`);
    }
    // Refresh the list (default first page) after successful mutation
    const listResponse = await fetch(buildBooksUrl('', 0, 2, '', 1));
    const data = await listResponse.json();
    dispatch({ type: 'DELETE_BOOK_FULFILLED', payload: data });
  } catch (err) {
    dispatch({ type: 'DELETE_BOOK_REJECTED', payload: err?.message ?? String(err) });
  }
};
