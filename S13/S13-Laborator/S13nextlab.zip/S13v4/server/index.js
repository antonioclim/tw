import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json());

let nextId = 1;

// Seed data (includes pageCount for the chart)
let books = [
  { id: nextId++, title: 'Clean Code', content: 'A Handbook of Agile Software Craftsmanship', pageCount: 464 },
  { id: nextId++, title: 'Design Patterns', content: 'Elements of Reusable Object-Oriented Software', pageCount: 416 },
  { id: nextId++, title: 'Refactoring', content: 'Improving the Design of Existing Code', pageCount: 448 },
  { id: nextId++, title: 'The Pragmatic Programmer', content: 'Your Journey to Mastery', pageCount: 352 },
  { id: nextId++, title: 'Introduction to Algorithms', content: 'CLRS', pageCount: 1312 },
  { id: nextId++, title: 'You Don\'t Know JS', content: 'Scope & Closures', pageCount: 98 },
  { id: nextId++, title: 'JavaScript: The Good Parts', content: 'Unearthing the Excellence in JS', pageCount: 176 },
  { id: nextId++, title: 'Eloquent JavaScript', content: 'A Modern Introduction to Programming', pageCount: 472 },
  { id: nextId++, title: 'Effective Java', content: 'Best practices for the Java platform', pageCount: 416 },
  { id: nextId++, title: 'Working Effectively with Legacy Code', content: 'Techniques for large codebases', pageCount: 456 }
];

function containsCI(haystack, needle) {
  return String(haystack).toLowerCase().includes(String(needle).toLowerCase());
}

function normaliseSortOrder(sortOrder) {
  const n = Number(sortOrder);
  if (Number.isNaN(n)) return 1;
  return n >= 0 ? 1 : -1;
}

app.get('/books', (req, res) => {
  const { title, content, sortField, sortOrder, page, pageSize } = req.query;

  // Filtering
  let filtered = [...books];
  if (title) {
    filtered = filtered.filter(b => containsCI(b.title, title));
  }
  if (content) {
    filtered = filtered.filter(b => containsCI(b.content, content));
  }

  // Sorting
  if (sortField) {
    const order = normaliseSortOrder(sortOrder ?? 1);
    filtered.sort((a, b) => {
      const av = a[sortField];
      const bv = b[sortField];

      // Numeric sort if both numbers
      if (typeof av === 'number' && typeof bv === 'number') {
        return order * (av - bv);
      }
      // String sort fallback
      return order * String(av ?? '').localeCompare(String(bv ?? ''));
    });
  }

  const total = filtered.length;

  // Pagination (0-based page index)
  const p = Number(page ?? 0);
  const ps = Number(pageSize ?? 2);
  const start = p * ps;
  const end = start + ps;

  const records = filtered.slice(start, end);

  res.json({
    count: total,
    records
  });
});

app.post('/books', (req, res) => {
  const { title, content, pageCount } = req.body ?? {};
  if (!title || !content) {
    return res.status(400).json({ error: 'Both title and content are required.' });
  }

  const newBook = {
    id: nextId++,
    title,
    content,
    pageCount: Number.isFinite(Number(pageCount)) ? Number(pageCount) : Math.floor(50 + Math.random() * 600)
  };

  books.push(newBook);
  res.status(201).json(newBook);
});

app.put('/books/:id', (req, res) => {
  const id = Number(req.params.id);
  const idx = books.findIndex(b => b.id === id);
  if (idx < 0) {
    return res.status(404).json({ error: 'Book not found.' });
  }

  const { title, content, pageCount } = req.body ?? {};

  books[idx] = {
    ...books[idx],
    title: title ?? books[idx].title,
    content: content ?? books[idx].content,
    pageCount: Number.isFinite(Number(pageCount)) ? Number(pageCount) : books[idx].pageCount
  };

  res.json(books[idx]);
});

app.delete('/books/:id', (req, res) => {
  const id = Number(req.params.id);
  const before = books.length;
  books = books.filter(b => b.id !== id);

  if (books.length === before) {
    return res.status(404).json({ error: 'Book not found.' });
  }

  res.json({ success: true });
});

app.get('/health', (_req, res) => {
  res.json({ ok: true });
});

const PORT = 8080;
app.listen(PORT, () => {
  console.log(`S13v4 server listening on http://localhost:${PORT}`);
});
