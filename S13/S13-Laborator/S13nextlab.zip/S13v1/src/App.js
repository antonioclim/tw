import BookList from './components/BookList';

function App() {
  return (
    <div style={{ padding: '1rem' }}>
      <BookList />
    </div>
  );
}

export default App;
