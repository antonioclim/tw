import { combineReducers } from 'redux';
import book from './book-reducer';

export default combineReducers({
  book,
});
