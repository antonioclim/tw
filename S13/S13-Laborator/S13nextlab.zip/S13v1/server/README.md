# S13v1 Demo Server

A minimal Express server used by the S13v1 starter kit.

## Run

```bash
npm install
npm start
```

## Endpoints

- `GET /books` – returns a JSON array of `{ id, title, content }`
- `POST /books` – create a new book
- `PUT /books/:id` – update an existing book

Data is stored in memory and resets when the server restarts.
