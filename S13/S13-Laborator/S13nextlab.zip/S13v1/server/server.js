const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

let nextId = 3;

// Minimal in-memory dataset (seeded) so the UI has something to render immediately.
let books = [
  { id: 1, title: 'Clean Code', content: 'A Handbook of Agile Software Craftsmanship.' },
  { id: 2, title: 'The Pragmatic Programmer', content: 'Your Journey to Mastery.' },
];

app.get('/books', (req, res) => {
  res.json(books);
});

app.post('/books', (req, res) => {
  const { title = '', content = '' } = req.body || {};
  const book = { id: nextId++, title, content };
  books.push(book);
  res.status(201).json(book);
});

app.put('/books/:id', (req, res) => {
  const id = Number(req.params.id);
  const idx = books.findIndex((b) => b.id === id);

  if (idx === -1) {
    res.status(404).json({ error: 'Book not found' });
    return;
  }

  const { title, content } = req.body || {};
  books[idx] = {
    ...books[idx],
    ...(title !== undefined ? { title } : {}),
    ...(content !== undefined ? { content } : {}),
  };

  res.json(books[idx]);
});

app.get('/', (req, res) => {
  res.type('text').send('S13v1 demo server is running. Try GET /books');
});

const PORT = 8080;
app.listen(PORT, () => {
  console.log(`S13v1 demo server listening on http://localhost:${PORT}`);
});
