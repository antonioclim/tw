const express = require('express');
const cors = require('cors');

const PORT = 8080;

const app = express();
app.use(cors());
app.use(express.json());

let nextId = 1;

// Seed data – enough records to demonstrate paging, filtering and sorting.
let books = [
  { title: 'Algorithms', content: 'Divide and conquer, dynamic programming, greedy.' },
  { title: 'Databases', content: 'Relational model, SQL, indexes.' },
  { title: 'Networks', content: 'TCP/IP, routing, congestion control.' },
  { title: 'Operating Systems', content: 'Processes, threads, scheduling.' },
  { title: 'Compilers', content: 'Parsing, ASTs, optimisation.' },
  { title: 'Machine Learning', content: 'Supervised, unsupervised, evaluation.' },
  { title: 'Human-Computer Interaction', content: 'Usability, affordances, prototyping.' }
].map(b => ({ id: nextId++, ...b }));

function normalise(v) {
  return String(v ?? '').toLowerCase();
}

function applyContainsFilter(list, field, needle) {
  if (needle === undefined || needle === null || String(needle).trim() === '') {
    return list;
  }
  const n = normalise(needle);
  return list.filter(item => normalise(item[field]).includes(n));
}

function applySorting(list, sortField, sortOrder) {
  if (!sortField) return list;

  const allowed = new Set(['id', 'title', 'content']);
  if (!allowed.has(sortField)) return list;

  const order = Number(sortOrder) === -1 ? -1 : 1;

  const sorted = [...list].sort((a, b) => {
    const av = a[sortField];
    const bv = b[sortField];

    // Numeric sort for id, lexicographic for strings
    if (sortField === 'id') {
      return (Number(av) - Number(bv)) * order;
    }

    const as = String(av ?? '');
    const bs = String(bv ?? '');
    if (as < bs) return -1 * order;
    if (as > bs) return 1 * order;
    return 0;
  });

  return sorted;
}

function paginate(list, page, pageSize) {
  const p = Number.isFinite(page) ? page : 0;
  const ps = Number.isFinite(pageSize) ? pageSize : 2;

  const start = Math.max(0, p) * Math.max(1, ps);
  return list.slice(start, start + ps);
}

app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.get('/books', (req, res) => {
  const {
    title,
    content,
    page = '0',
    pageSize = '2',
    sortField = '',
    sortOrder = '1'
  } = req.query;

  let result = [...books];

  // Filtering (contains), as assumed in the subtitles.
  result = applyContainsFilter(result, 'title', title);
  result = applyContainsFilter(result, 'content', content);

  const count = result.length;

  // Sorting
  result = applySorting(result, sortField, sortOrder);

  // Pagination
  const pageNum = parseInt(page, 10);
  const pageSizeNum = parseInt(pageSize, 10);
  const records = paginate(result, pageNum, pageSizeNum);

  res.json({ count, records });
});

app.post('/books', (req, res) => {
  const { title = '', content = '' } = req.body || {};
  const created = { id: nextId++, title, content };
  books.push(created);
  res.status(201).json(created);
});

app.put('/books/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const { title, content } = req.body || {};

  const index = books.findIndex(b => b.id === id);
  if (index < 0) {
    return res.status(404).json({ error: 'Book not found' });
  }

  books[index] = {
    ...books[index],
    title: title !== undefined ? title : books[index].title,
    content: content !== undefined ? content : books[index].content
  };

  res.json(books[index]);
});

app.delete('/books/:id', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const before = books.length;
  books = books.filter(b => b.id !== id);

  if (books.length === before) {
    return res.status(404).json({ error: 'Book not found' });
  }

  res.status(204).send();
});

app.listen(PORT, () => {
  console.log(`S13v3 demo server listening on http://localhost:${PORT}`);
});
