import BookList from './BookList';

function App() {
  return (
    <div className="p-m-3">
      <BookList />
    </div>
  );
}

export default App;
