import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { getBooks, addBook, saveBook } from '../actions';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { FilterMatchMode } from 'primereact/api';

const bookSelector = state => state.book.bookList;
const countSelector = state => state.book.count;

function BookList() {
    const [isDialogShown, setIsDialogShown] = useState(false);
    const [content, setContent] = useState('');
    const [title, setTitle] = useState('');
    const [isNewRecord, setIsNewRecord] = useState(true);
    const [selectedBook, setSelectedBook] = useState(null);
    const [filterString, setFilterString] = useState('');
    const [sortField, setSortField] = useState('');
    const [sortOrder, setSortOrder] = useState(1);
    const [page, setPage] = useState(0);
    const [first, setFirst] = useState(0);

    const [filters, setFilters] = useState({
        title: { value: null, matchMode: FilterMatchMode.CONTAINS },
        content: { value: null, matchMode: FilterMatchMode.CONTAINS }
    });

    const books = useSelector(bookSelector);
    const count = useSelector(countSelector);
    const dispatch = useDispatch();

    // Effect to construct the filter query string when filters change
    useEffect(() => {
        const keys = Object.keys(filters);
        const computedFilterString = keys.map(key => {
            return {
                key: key,
                value: filters[key].value
            };
        })
        .filter(e => e.value !== null)
        .map(e => `${e.key}=${e.value}`)
        .join('&');
        setFilterString(computedFilterString);
    }, [filters]);

    // Main effect to fetch books when parameters change
    useEffect(() => {
        dispatch(getBooks(filterString, page, 2, sortField, sortOrder));
    }, [filterString, page, sortField, sortOrder, dispatch]);

    const handleAddClick = () => {
        setIsDialogShown(true);
        setIsNewRecord(true);
        setTitle('');
        setContent('');
    };

    const hideDialog = () => {
        setIsDialogShown(false);
    };

    const handleSaveClick = () => {
        if (isNewRecord) {
            dispatch(addBook({ title, content }));
        } else {
            dispatch(saveBook(selectedBook, { title, content }));
        }
        setIsDialogShown(false);
        setSelectedBook(null);
        setTitle('');
        setContent('');
    };

    const editBook = (rowData) => {
        setSelectedBook(rowData.id);
        setTitle(rowData.title);
        setContent(rowData.content);
        setIsDialogShown(true);
        setIsNewRecord(false);
    };

    const handleFilter = (evt) => {
        const oldFilters = { ...filters };
        oldFilters[evt.field] = evt.constraints.constraints[0];
        setFilters({ ...oldFilters });
    };

    const handleFilterClear = (evt) => {
        setFilters({
            title: { value: null, matchMode: FilterMatchMode.CONTAINS },
            content: { value: null, matchMode: FilterMatchMode.CONTAINS }
        });
    };

    const handleSort = (evt) => {
        setSortField(evt.sortField);
        setSortOrder(evt.sortOrder);
    };

    const handlePageChange = (evt) => {
        setPage(evt.page);
        setFirst(evt.first);
    };

    const tableFooter = (
        <div className="p-clearfix" style={{ width: '100%' }}>
            <Button label="Add" icon="pi pi-plus" onClick={handleAddClick} />
        </div>
    );

    const dialogFooter = (
        <div>
            <Button label="Save" icon="pi pi-save" onClick={handleSaveClick} />
        </div>
    );

    const opsColumn = (rowData) => {
        return (
            <Button label="Edit" icon="pi pi-pencil" onClick={() => editBook(rowData)} />
        );
    };

    return (
        <div>
            <DataTable 
                value={books} 
                footer={tableFooter} 
                lazy 
                paginator 
                rows={2}
                totalRecords={count}
                first={first}
                onPage={handlePageChange}
                onSort={handleSort} 
                sortField={sortField} 
                sortOrder={sortOrder}
            >
                <Column 
                    header="Title" 
                    field="title" 
                    filter 
                    filterField="title" 
                    filterPlaceholder="title" 
                    onFilterApplyClick={handleFilter} 
                    onFilterClear={handleFilterClear} 
                    sortable 
                />
                <Column 
                    header="Content" 
                    field="content" 
                    filter 
                    filterField="content" 
                    filterPlaceholder="content" 
                    onFilterApplyClick={handleFilter} 
                    onFilterClear={handleFilterClear} 
                    sortable 
                />
                <Column body={opsColumn} />
            </DataTable>

            <Dialog header="A book" visible={isDialogShown} onHide={hideDialog} footer={dialogFooter}>
                <div>
                    <InputText placeholder="title" onChange={(evt) => setTitle(evt.target.value)} value={title} />
                </div>
                <div>
                    <InputText placeholder="content" onChange={(evt) => setContent(evt.target.value)} value={content} />
                </div>
            </Dialog>
        </div>
    );
}

export default BookList;
