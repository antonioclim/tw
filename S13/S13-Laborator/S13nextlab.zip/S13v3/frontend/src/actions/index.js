const SERVER = 'http://localhost:8080';

let lastQuery = {
  filterString: '',
  page: 0,
  pageSize: 2,
  sortField: '',
  sortOrder: 1
};

function buildBooksUrl(filterString = '', page = 0, pageSize = 2, sortField = '', sortOrder = 1) {
  const params = new URLSearchParams();

  // filters arrive as a precomputed string like: "title=abc&content=def"
  if (filterString) {
    const filterParams = new URLSearchParams(filterString);
    for (const [key, value] of filterParams.entries()) {
      if (value !== null && value !== '') {
        params.set(key, value);
      }
    }
  }

  params.set('page', String(page));
  params.set('pageSize', String(pageSize));
  if (sortField) {
    params.set('sortField', sortField);
  }
  params.set('sortOrder', String(sortOrder));

  return `${SERVER}/books?${params.toString()}`;
}

async function fetchJson(url, options) {
  const response = await fetch(url, options);
  if (!response.ok) {
    const text = await response.text().catch(() => '');
    throw new Error(`HTTP ${response.status}: ${text || response.statusText}`);
  }

  // Some endpoints may return 204; handle that gracefully.
  const contentType = response.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    return null;
  }
  return response.json();
}

function refreshBooksWithLastQuery() {
  const { filterString, page, pageSize, sortField, sortOrder } = lastQuery;
  const url = buildBooksUrl(filterString, page, pageSize, sortField, sortOrder);
  return fetchJson(url);
}

export function getBooks(filterString = '', page = 0, pageSize = 2, sortField = '', sortOrder = 1) {
  lastQuery = { filterString, page, pageSize, sortField, sortOrder };

  const url = buildBooksUrl(filterString, page, pageSize, sortField, sortOrder);
  return {
    type: 'GET_BOOKS',
    payload: fetchJson(url)
  };
}

export function addBook(book) {
  return {
    type: 'ADD_BOOK',
    payload: fetchJson(`${SERVER}/books`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(book || {})
    }).then(() => refreshBooksWithLastQuery())
  };
}

export function saveBook(id, book) {
  return {
    type: 'SAVE_BOOK',
    payload: fetchJson(`${SERVER}/books/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(book || {})
    }).then(() => refreshBooksWithLastQuery())
  };
}

export function deleteBook(id) {
  return {
    type: 'DELETE_BOOK',
    payload: fetchJson(`${SERVER}/books/${id}`, {
      method: 'DELETE'
    }).then(() => refreshBooksWithLastQuery())
  };
}
