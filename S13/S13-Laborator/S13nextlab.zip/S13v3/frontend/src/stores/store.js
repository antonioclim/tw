import { createStore, applyMiddleware } from 'redux';
import reducer from '../reducers';
import promiseMiddleware from 'redux-promise-middleware';

/**
 * redux-promise-middleware has historically shipped in slightly different shapes
 * (either as a middleware factory or as a middleware function). To keep the
 * starter kit robust, we attempt to initialise it as a factory first and fall
 * back to using it directly if that fails.
 */
let middleware;
try {
  middleware = promiseMiddleware();
} catch (e) {
  middleware = promiseMiddleware;
}

const store = createStore(reducer, applyMiddleware(middleware));

export default store;
