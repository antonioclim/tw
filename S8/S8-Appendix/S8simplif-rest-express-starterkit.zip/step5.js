﻿// step5.js - add logger middleware
const express = require("express");
const app = express();
const PORT = process.env.PORT || 3001;

app.use(express.json());

// logging middleware
app.use((req, res, next) => {
  const now = new Date().toISOString();
  console.log(`[${now}] ${req.method} ${req.originalUrl}`);
  if (req.body && Object.keys(req.body).length > 0) {
    console.log("  Body:", req.body);
  }
  next();
});

let nextId = 4;
let books = [
  { id: 1, title: "Clean Code", author: "Robert C. Martin" },
  { id: 2, title: "The Pragmatic Programmer", author: "Andrew Hunt, David Thomas" },
  { id: 3, title: "Harry Potter and the Philosopher's Stone", author: "J.K. Rowling" }
];

app.get("/books", (req, res) => {
  const sorted = [...books].sort((a, b) => a.title.localeCompare(b.title));
  res.json(sorted);
});

app.post("/books", (req, res) => {
  const { title, author } = req.body || {};

  if (!title || typeof title !== "string" || !author || typeof author !== "string") {
    return res.status(400).json({
      error: "Invalid body. Expected JSON with non-empty 'title' and 'author'."
    });
  }

  const newBook = {
    id: nextId++,
    title: title.trim(),
    author: author.trim()
  };

  books.push(newBook);
  res.status(201).json(newBook);
});

app.delete("/books/:id", (req, res) => {
  const id = parseInt(req.params.id, 10);

  if (Number.isNaN(id)) {
    return res.status(400).json({ error: "Invalid ID parameter (must be a number)." });
  }

  const index = books.findIndex(b => b.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Book not found." });
  }

  books.splice(index, 1);
  res.sendStatus(204);
});

const statusRouter2 = require("./routes/statusRouter");
app.use("/status", statusRouter2);

app.listen(PORT, () => {
  console.log(`STEP 5 server running at http://localhost:${PORT}`);
});
