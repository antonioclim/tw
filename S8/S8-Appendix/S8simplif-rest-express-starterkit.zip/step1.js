﻿// step1.js - simple server with GET /books
const express = require("express");
const app = express();
const PORT = process.env.PORT || 3001;

let books = [
  { id: 1, title: "Clean Code", author: "Robert C. Martin" },
  { id: 2, title: "The Pragmatic Programmer", author: "Andrew Hunt, David Thomas" },
  { id: 3, title: "Harry Potter and the Philosopher's Stone", author: "J.K. Rowling" }
];

app.get("/books", (req, res) => {
  const sorted = [...books].sort((a, b) => a.title.localeCompare(b.title));
  res.json(sorted);
});

app.listen(PORT, () => {
  console.log(`STEP 1 server running at http://localhost:${PORT}/books`);
});
