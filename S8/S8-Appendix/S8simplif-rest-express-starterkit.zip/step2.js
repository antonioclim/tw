﻿// step2.js - GET /books + POST /books with basic validation
const express = require("express");
const app = express();
const PORT = process.env.PORT || 3001;

app.use(express.json());

let nextId = 4;
let books = [
  { id: 1, title: "Clean Code", author: "Robert C. Martin" },
  { id: 2, title: "The Pragmatic Programmer", author: "Andrew Hunt, David Thomas" },
  { id: 3, title: "Harry Potter and the Philosopher's Stone", author: "J.K. Rowling" }
];

app.get("/books", (req, res) => {
  const sorted = [...books].sort((a, b) => a.title.localeCompare(b.title));
  res.json(sorted);
});

app.post("/books", (req, res) => {
  const { title, author } = req.body || {};

  if (!title || typeof title !== "string" || !author || typeof author !== "string") {
    return res.status(400).json({
      error: "Invalid body. Expected JSON with non-empty 'title' and 'author'."
    });
  }

  const newBook = {
    id: nextId++,
    title: title.trim(),
    author: author.trim()
  };

  books.push(newBook);
  res.status(201).json(newBook);
});

app.listen(PORT, () => {
  console.log(`STEP 2 server running at http://localhost:${PORT}`);
});
