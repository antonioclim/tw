﻿// server.js
// Meniu didactic pentru S8 – Servicii RESTful & Express.js

const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// descrierea pașilor (un singur „adevăr” central)
const steps = [
  {
    id: 1,
    title: "Server simplu – GET /books (listează cărțile, sortat alfabetic)",
    apiUrl: "http://localhost:3001/books",
    docPath: "/docs/step1.html"
  },
  {
    id: 2,
    title: "POST /books – adăugare carte + validare simplă",
    apiUrl: "http://localhost:3001/books",
    docPath: "/docs/step2.html"
  },
  {
    id: 3,
    title: "DELETE /books/:id – identificare și ștergere resurse",
    apiUrl: "http://localhost:3001/books",
    docPath: "/docs/step3.html"
  },
  {
    id: 4,
    title: "Router modular /status – structurare pe module",
    apiUrl: "http://localhost:3001/status",
    docPath: "/docs/step4.html"
  },
  {
    id: 5,
    title: "Middleware de logging – lans cerere–răspuns",
    apiUrl: "http://localhost:3001/books",
    docPath: "/docs/step5.html"
  },
  {
    id: 6,
    title: "Gestionarea erorilor – handler global + 404",
    apiUrl: "http://localhost:3001/books",
    docPath: "/docs/step6.html"
  }
];

// servim documentația ca fișiere statice din ./docs
app.use(
  "/docs",
  express.static(path.join(__dirname, "docs"), {
    extensions: ["html"]
  })
);

// pagina de meniu la /
app.get("/", (req, res) => {
  const rows = steps
    .map(
      (s) => `
      <li class="step">
        <div class="step-title">
          <span class="step-badge">Pasul ${s.id}</span>
          <span>${s.title}</span>
        </div>
        <div class="step-actions">
          <a class="btn btn-primary" href="${s.apiUrl}" target="_blank" rel="noopener">
            Deschide step${s.id} (API)
          </a>
          <a class="btn btn-secondary" href="${s.docPath}" target="_blank" rel="noopener">
            Documentație
          </a>
        </div>
        <div class="step-meta">
          <code>${s.apiUrl}</code>
        </div>
      </li>`
    )
    .join("\n");

  res.send(`<!DOCTYPE html>
<html lang="ro">
  <head>
    <meta charset="utf-8">
    <title>S8 – Servicii RESTful & Express.js (kit 6 pași)</title>
    <style>
      :root {
        --accent: #0d6efd;
        --accent-soft: #e7f1ff;
        --border: #e0e0e0;
        --bg: #fafafa;
        --text-main: #222;
        --text-muted: #666;
      }

      * { box-sizing: border-box; }

      body {
        margin: 0;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        background: var(--bg);
        color: var(--text-main);
      }

      main {
        max-width: 960px;
        margin: 2.5rem auto;
        padding: 0 1.5rem 3rem;
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.04);
      }

      header {
        padding: 1.5rem 0 1rem;
        border-bottom: 1px solid var(--border);
      }

      h1 {
        margin: 0 0 0.25rem;
        font-size: 1.9rem;
      }

      .subtitle {
        margin: 0;
        color: var(--text-muted);
      }

      .subtitle code {
        background: #f3f3f3;
        padding: 0.1rem 0.3rem;
        border-radius: 4px;
        font-size: 0.9em;
      }

      ul.steps {
        list-style: none;
        padding: 0;
        margin: 2rem 0 1.5rem;
      }

      .step {
        border: 1px solid var(--border);
        border-radius: 10px;
        padding: 0.9rem 1rem;
        margin-bottom: 0.8rem;
        display: flex;
        flex-direction: column;
        gap: 0.4rem;
        background: #fff;
      }

      .step-title {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
        align-items: center;
        font-weight: 500;
      }

      .step-badge {
        background: var(--accent-soft);
        color: var(--accent);
        border-radius: 999px;
        padding: 0.2rem 0.7rem;
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.04em;
      }

      .step-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 0.4rem;
      }

      .step-meta {
        font-size: 0.85rem;
        color: var(--text-muted);
      }

      .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 0.35rem 0.8rem;
        border-radius: 6px;
        border: 1px solid transparent;
        font-size: 0.9rem;
        text-decoration: none;
        cursor: pointer;
        transition: background 0.15s ease, border-color 0.15s ease, color 0.15s ease;
      }

      .btn-primary {
        background: var(--accent);
        color: #fff;
        border-color: var(--accent);
      }

      .btn-primary:hover {
        background: #0b5ed7;
      }

      .btn-secondary {
        background: #fff;
        color: var(--accent);
        border-color: var(--accent-soft);
      }

      .btn-secondary:hover {
        background: var(--accent-soft);
      }

      section.instructions {
        border-top: 1px solid var(--border);
        padding-top: 1.5rem;
        margin-top: 1rem;
        font-size: 0.92rem;
        color: var(--text-muted);
      }

      section.instructions ol {
        margin-top: 0.5rem;
        padding-left: 1.2rem;
      }

      code {
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
      }

      @media (max-width: 640px) {
        main { margin: 1rem 0.5rem 2rem; }
      }
    </style>
  </head>
  <body>
    <main>
      <header>
        <h1>S8 – Servicii RESTful &amp; Express.js</h1>
        <p class="subtitle">
          Kit de seminar în 6 pași. Meniul de mai jos pornește fie API‑ul de exemplu (dacă rulează deja pe portul corespunzător),
          fie documentația fiecărui pas.
        </p>
      </header>

      <ul class="steps">
        ${rows}
      </ul>

      <section class="instructions">
        <strong>Instrucțiuni de utilizare (recomandate la laborator)</strong>
        <ol>
          <li>
            Pentru fiecare pas, porniți în terminal serverul corespunzător.
            De exemplu: <br>
            <code>node step1.js</code> (ascultă pe <code>http://localhost:3001</code>),<br>
            <code>node step2.js</code> (pe <code>3002</code>), etc.
          </li>
          <li>
            Deschideți această pagină la
            <code>http://localhost:${PORT}/</code>
            și folosiți butoanele <em>„Deschide stepX (API)”</em>
            pentru a vedea rapid răspunsul endpoint‑urilor în browser sau în Postman.
          </li>
          <li>
            Pentru fiecare pas, linkul <em>„Documentație”</em> deschide fișierul HTML generat din notele de curs
            (DOCX/README) – acolo pot fi evidențiate diferențele față de pasul precedent,
            exemple de cereri Postman, diagrame etc.
          </li>
        </ol>
      </section>
    </main>
  </body>
</html>`);
});

// opțional: health‑check simplu
app.get("/health", (req, res) => {
  res.json({ status: "ok", menu: "S8 REST/Express", timestamp: new Date().toISOString() });
});

app.listen(PORT, () => {
  console.log(`Meniul S8 rulează pe http://localhost:${PORT}`);
});
