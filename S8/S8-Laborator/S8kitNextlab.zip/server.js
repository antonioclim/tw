const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

// Servim pagina de meniu (public/index.html)
app.use(express.static(path.join(__dirname, 'public')));

// Servim documentația fiecărui pas (docs/step1.html ... step8.html)
app.use('/docs', express.static(path.join(__dirname, 'docs')));

// Un mic endpoint JSON, doar ca exemplu
app.get('/api-info', (req, res) => {
  res.json({
    message: 'Seminar 8 – Servicii RESTful si Express.js (varianta in 8 pasi)',
    steps: [1, 2, 3, 4, 5, 6, 7, 8],
    docsBaseUrl: '/docs'
  });
});

// Fallback 404 pentru meniul principal
app.use((req, res) => {
  res
    .status(404)
    .send('Pagina nu a fost gasita in serverul de meniu (port 3000).');
});

app.listen(PORT, () => {
  console.log(`Meniul S8 (8 pasi) este disponibil la http://localhost:${PORT}`);
});
