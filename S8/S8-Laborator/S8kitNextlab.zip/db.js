// Baza de date "in-memory" pentru exemplele didactice.
// La fiecare rulare de pas, datele pornesc din nou de la aceasta stare initiala.

const books = [
  { id: 1, title: 'Harry Potter and the Philosopher\'s Stone', author: 'J.K. Rowling' },
  { id: 2, title: 'Harry Potter and the Chamber of Secrets', author: 'J.K. Rowling' },
  { id: 3, title: 'Harry Potter and the Prisoner of Azkaban', author: 'J.K. Rowling' },
  { id: 4, title: 'Fantastic Beasts and Where to Find Them', author: 'J.K. Rowling' }
];

let nextBookId = books.length + 1;

function generateBookId() {
  return nextBookId++;
}

const departments = [
  { id: 1, name: 'Gryffindor Library', floor: 1 },
  { id: 2, name: 'Ravenclaw Archive', floor: 2 },
  { id: 3, name: 'Slytherin Restricted Section', floor: -1 }
];

let nextDepartmentId = departments.length + 1;

function generateDepartmentId() {
  return nextDepartmentId++;
}

module.exports = {
  books,
  departments,
  generateBookId,
  generateDepartmentId
};
