// Book.js
class Book {
  constructor(id, title, author, year) {
    this.id = id;
    this.title = title;
    this.author = author;
    if (year !== undefined) {
      this.year = year;
    }
  }
}

module.exports = Book;
