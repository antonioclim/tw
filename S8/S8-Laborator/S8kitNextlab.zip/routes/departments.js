const express = require('express');
const { departments, generateDepartmentId } = require('../db');

const router = express.Router();

/**
 * Middleware de validare pentru un "department".
 * Verifica daca body contine cel putin "name" si "floor" (numar).
 */
function validateDepartment(req, res, next) {
  const { name, floor } = req.body;

  if (!name || typeof name !== 'string') {
    return res.status(400).json({
      error: 'Campul "name" este obligatoriu si trebuie sa fie string.'
    });
  }

  if (floor === undefined || typeof floor !== 'number') {
    return res.status(400).json({
      error: 'Campul "floor" este obligatoriu si trebuie sa fie number.'
    });
  }

  next();
}

// GET /departments  – lista tuturor departamentelor
router.get('/', (req, res) => {
  res.json(departments);
});

// GET /departments/:id – un singur departament dupa ID
router.get('/:id', (req, res) => {
  const id = Number(req.params.id);
  const dept = departments.find(d => d.id === id);

  if (!dept) {
    return res.status(404).json({ error: 'Departament inexistent.' });
  }

  res.json(dept);
});

// POST /departments – creeaza un nou departament (cu validare)
router.post('/', validateDepartment, (req, res) => {
  const { name, floor } = req.body;

  const newDept = {
    id: generateDepartmentId(),
    name,
    floor
  };

  departments.push(newDept);
  res.status(201).json(newDept);
});

// DELETE /departments/:id – sterge departamentul
router.delete('/:id', (req, res) => {
  const id = Number(req.params.id);
  const index = departments.findIndex(d => d.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Departament inexistent.' });
  }

  departments.splice(index, 1);
  res.status(204).send();
});

module.exports = router;
