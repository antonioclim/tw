const express = require('express');
const { books, generateBookId } = require('./db');
const departmentsRouter = require('./routes/departments');

const app = express();
const PORT = 3001;

app.use(express.json());

// Logging de baza
app.use((req, res, next) => {
  const now = new Date().toISOString();
  console.log(`[STEP 8] ${now} - ${req.method} ${req.url}`);
  next();
});

// Router pentru departamente
app.use('/departments', departmentsRouter);

// Middleware de validare pentru carti (ca in step7)
function validateBook(req, res, next) {
  const { title, author } = req.body;

  if (!title || typeof title !== 'string') {
    return res.status(400).json({
      error: 'Campul "title" este obligatoriu si trebuie sa fie string.'
    });
  }

  if (!author || typeof author !== 'string') {
    return res.status(400).json({
      error: 'Campul "author" este obligatoriu si trebuie sa fie string.'
    });
  }

  next();
}

app.get('/', (req, res) => {
  res.send(
    '<h1>STEP 8 – Handler global de erori + 404</h1>' +
    '<p>Aveti un handler 404 pentru rute inexistente si un handler global de erori (500).</p>' +
    '<p>Puteti testa o eroare la <code>/error-test</code>.</p>'
  );
});

// Rute pentru carti
app.get('/books', (req, res) => {
  const sorted = [...books].sort((a, b) =>
    a.title.localeCompare(b.title, 'en', { sensitivity: 'base' })
  );
  res.json(sorted);
});

app.post('/books', validateBook, (req, res) => {
  const { title, author } = req.body;

  const newBook = {
    id: generateBookId(),
    title,
    author
  };

  books.push(newBook);
  res.status(201).json(newBook);
});

app.delete('/books/:id', (req, res) => {
  const id = Number(req.params.id);
  const index = books.findIndex(b => b.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Cartea nu a fost gasita.' });
  }

  books.splice(index, 1);
  res.status(204).send();
});

// Ruta speciala pentru a genera o eroare intentionata
app.get('/error-test', (req, res, next) => {
  const err = new Error('Eroare intentionata pentru testarea handlerului global.');
  next(err);
});

// Handler 404 – trebuie sa fie inainte de handlerul de erori
app.use((req, res, next) => {
  res.status(404).json({
    error: 'Ruta nu a fost gasita (handler 404 din STEP 8).'
  });
});

// Handler global de erori (semnatura cu 4 argumente)
app.use((err, req, res, next) => {
  console.error('=== EROARE in STEP 8 ===');
  console.error(err.stack);

  res.status(500).json({
    error: 'Eroare interna a serverului.',
    message: err.message
  });
});

app.listen(PORT, () => {
  console.log(`STEP 8 – Server pornit pe http://localhost:${PORT}`);
  console.log('Testati /error-test pentru a vedea handlerul global de erori in actiune.');
});
