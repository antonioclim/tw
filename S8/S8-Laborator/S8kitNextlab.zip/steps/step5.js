const express = require('express');
const { books, generateBookId } = require('./db');
const departmentsRouter = require('./routes/departments');

const app = express();
const PORT = 3001;

app.use(express.json());

// Router pentru departamente (cu GET/POST/DELETE si validare)
app.use('/departments', departmentsRouter);

app.get('/', (req, res) => {
  res.send(
    '<h1>STEP 5 – Router /departments</h1>' +
    '<p>In plus fata de pasii anteriori: <code>/departments</code> (GET, POST, DELETE).</p>'
  );
});

// Rute pentru carti (ca in pasii precedenti)
app.get('/books', (req, res) => {
  const sorted = [...books].sort((a, b) =>
    a.title.localeCompare(b.title, 'en', { sensitivity: 'base' })
  );
  res.json(sorted);
});

app.post('/books', (req, res) => {
  const { title, author } = req.body;

  if (!title || !author) {
    return res.status(400).json({
      error: 'Campurile "title" si "author" sunt obligatorii.'
    });
  }

  const newBook = {
    id: generateBookId(),
    title,
    author
  };

  books.push(newBook);
  res.status(201).json(newBook);
});

app.delete('/books/:id', (req, res) => {
  const id = Number(req.params.id);
  const index = books.findIndex(b => b.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Cartea nu a fost gasita.' });
  }

  books.splice(index, 1);
  res.status(204).send();
});

app.listen(PORT, () => {
  console.log(`STEP 5 – Server pornit pe http://localhost:${PORT}`);
  console.log('Folositi: GET /departments, POST /departments, DELETE /departments/:id');
});
