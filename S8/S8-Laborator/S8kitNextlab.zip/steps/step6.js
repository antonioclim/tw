const express = require('express');
const { books, generateBookId } = require('./db');
const departmentsRouter = require('./routes/departments');

const app = express();
const PORT = 3001;

app.use(express.json());

// Middleware de logging – se executa pentru fiecare cerere
app.use((req, res, next) => {
  const now = new Date().toISOString();
  console.log(`[STEP 6] ${now} - ${req.method} ${req.url}`);
  next();
});

// Router pentru departamente
app.use('/departments', departmentsRouter);

app.get('/', (req, res) => {
  res.send(
    '<h1>STEP 6 – Middleware de logging</h1>' +
    '<p>Fiecare cerere este logata in consola (metoda + URL).</p>'
  );
});

// Rute pentru carti
app.get('/books', (req, res) => {
  const sorted = [...books].sort((a, b) =>
    a.title.localeCompare(b.title, 'en', { sensitivity: 'base' })
  );
  res.json(sorted);
});

app.post('/books', (req, res) => {
  const { title, author } = req.body;

  if (!title || !author) {
    return res.status(400).json({
      error: 'Campurile "title" si "author" sunt obligatorii.'
    });
  }

  const newBook = {
    id: generateBookId(),
    title,
    author
  };

  books.push(newBook);
  res.status(201).json(newBook);
});

app.delete('/books/:id', (req, res) => {
  const id = Number(req.params.id);
  const index = books.findIndex(b => b.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Cartea nu a fost gasita.' });
  }

  books.splice(index, 1);
  res.status(204).send();
});

app.listen(PORT, () => {
  console.log(`STEP 6 – Server pornit pe http://localhost:${PORT}`);
  console.log('Urmareste consola pentru a vedea logurile middleware-ului.');
});
