const express = require('express');
const { books, generateBookId } = require('./db');

const app = express();
const PORT = 3001;

// Middleware pentru parsarea corpului JSON
app.use(express.json());

app.get('/', (req, res) => {
  res.send(
    '<h1>STEP 2 – GET + POST /books</h1>' +
    '<p>Incercati <code>GET /books</code> si apoi <code>POST /books</code> cu Postman (JSON in body).</p>'
  );
});

// GET /books – lista de carti
app.get('/books', (req, res) => {
  const sorted = [...books].sort((a, b) =>
    a.title.localeCompare(b.title, 'en', { sensitivity: 'base' })
  );
  res.json(sorted);
});

// POST /books – creeaza o carte noua, validare minimala
app.post('/books', (req, res) => {
  const { title, author } = req.body;

  if (!title || !author) {
    return res.status(400).json({
      error: 'Campurile "title" si "author" sunt obligatorii.'
    });
  }

  const newBook = {
    id: generateBookId(),
    title,
    author
  };

  books.push(newBook);
  res.status(201).json(newBook);
});

app.listen(PORT, () => {
  console.log(`STEP 2 – Server pornit pe http://localhost:${PORT}`);
  console.log('GET  /books  – lista de carti');
  console.log('POST /books  – creeaza o carte (folositi Postman, body JSON).');
});
