const express = require('express');
const { books } = require('./db');

const app = express();
const PORT = 3001;

// Ruta radacina – mesaj explicativ
app.get('/', (req, res) => {
  res.send(
    '<h1>STEP 1 – Server Express simplu</h1>' +
    '<p>Incercati <code>GET /books</code> pentru a primi lista de carti in format JSON.</p>'
  );
});

// GET /books – intoarce lista de carti, sortata alfabetic dupa titlu
app.get('/books', (req, res) => {
  const sorted = [...books].sort((a, b) =>
    a.title.localeCompare(b.title, 'en', { sensitivity: 'base' })
  );
  res.json(sorted);
});

app.listen(PORT, () => {
  console.log(`STEP 1 – Server pornit pe http://localhost:${PORT}`);
  console.log('Incercati in browser:  http://localhost:3001/books');
});
