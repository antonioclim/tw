const express = require('express');
const { books, generateBookId } = require('./db');
const departmentsRouter = require('./routes/departments');

const app = express();
const PORT = 3001;

app.use(express.json());

// Middleware de logging (il pastram si aici)
app.use((req, res, next) => {
  const now = new Date().toISOString();
  console.log(`[STEP 7] ${now} - ${req.method} ${req.url}`);
  next();
});

// Middleware dedicat de validare pentru carti (books)
function validateBook(req, res, next) {
  const { title, author } = req.body;

  if (!title || typeof title !== 'string') {
    return res.status(400).json({
      error: 'Campul "title" este obligatoriu si trebuie sa fie string.'
    });
  }

  if (!author || typeof author !== 'string') {
    return res.status(400).json({
      error: 'Campul "author" este obligatoriu si trebuie sa fie string.'
    });
  }

  next();
}

// Router pentru departamente (cu validare proprie in fisierul departments.js)
app.use('/departments', departmentsRouter);

app.get('/', (req, res) => {
  res.send(
    '<h1>STEP 7 – Validare cu middleware dedicat</h1>' +
    '<p>Vedeti <code>POST /books</code> (cu middleware <code>validateBook</code>) si routerul <code>/departments</code>.</p>'
  );
});

// GET /books
app.get('/books', (req, res) => {
  const sorted = [...books].sort((a, b) =>
    a.title.localeCompare(b.title, 'en', { sensitivity: 'base' })
  );
  res.json(sorted);
});

// POST /books – foloseste middleware-ul validateBook
app.post('/books', validateBook, (req, res) => {
  const { title, author } = req.body;

  const newBook = {
    id: generateBookId(),
    title,
    author
  };

  books.push(newBook);
  res.status(201).json(newBook);
});

// DELETE /books/:id
app.delete('/books/:id', (req, res) => {
  const id = Number(req.params.id);
  const index = books.findIndex(b => b.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Cartea nu a fost gasita.' });
  }

  books.splice(index, 1);
  res.status(204).send();
});

app.listen(PORT, () => {
  console.log(`STEP 7 – Server pornit pe http://localhost:${PORT}`);
  console.log('Validarea pentru POST /books este extrasa intr-un middleware dedicat.');
});
