'use strict';

/**
 * Minimal Express static server for the Employee Management System lab.
 * Serves files from ./public and listens on PORT (default 3000).
 */
const path = require('path');
const express = require('express');
const app = express();

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');

// Basic security-related headers (very light-touch without extra deps)
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'no-referrer');
  next();
});

app.use(express.static(PUBLIC_DIR));

// Fallback to index.html for the root
app.get('/', (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`[hwclim-starter] Server running at http://localhost:${PORT}`);
});
