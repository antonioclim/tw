# HWclim Starter Kit — Lab 2 (JavaScript Array Methods)

**Language:** English (UK) | **Locale & currency:** `ro-RO`, `RON`  
**Purpose:** Base project for the “Employee Management System” lab, aligned with the lab document you approved.

## Features
- Clean HTML/CSS/JS with **unobtrusive** event listeners.
- **Array methods** demo: `forEach`, `map`, `filter`, `reduce`, `find`.
- **Localisation (ro-RO)** and `Intl.NumberFormat` for **RON**.
- **Monetary safety:** salaries kept as integers (bani), formatted only at display time.
- **XSS‑aware rendering:** builds DOM with `textContent` (no unsafe HTML injection).
- **Accessibility:** polite live region for results.

## Project structure
```
hwclim_starter/
├─ public/
│  ├─ index.html
│  ├─ styles.css
│  └─ app.js
├─ server.js
├─ package.json
└─ README.md
```

## Running locally (port 3000)
1. Install Node.js LTS (18+ recommended).
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the server (serves `public/` at **http://localhost:3000**):
   ```bash
   npm start
   ```

## What to try
- **Display All Employees** → renders a table via `map`.
- **Calculate Total Salaries** → computes aggregate with `reduce`.
- **Display HR Employees** → filters with `filter`.
- **Find by ID** → retrieves a single record with `find`.

## Homework hooks (HWclim)
- Extend `EMPLOYEES` with `email` and `hiringDate` (ISO 8601).
- Update the table headers + rows to show the new fields.
- Implement compound filters (e.g., Department + Min Salary + Hired After).
- Update `handleAdvancedFilter` accordingly.

## GitHub structure
When submitting your homework, place this project under your repository path:
```
.../sem2/HWclim/
```
Provide a `README.md` with run instructions and a `LICENSE` file (e.g., MIT).
