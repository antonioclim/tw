'use strict';

/**
 * Employee Management System — Lab Starter (UE/RO)
 * Array methods: forEach, map, filter, reduce, find.
 * Practices: ro-RO localisation for RON, DOM API for safe rendering (no unsafe innerHTML),
 *            monetary values stored as integers (bani), accessibility via aria-live.
 */

/** Monetary formatter for Romania (RON). */
const fmtRON = new Intl.NumberFormat('ro-RO', {
  style: 'currency',
  currency: 'RON',
  maximumFractionDigits: 2,
});

/** Convert bani (integer) to formatted RON string. */
function ronFromBani(bani) {
  const ron = bani / 100;
  return fmtRON.format(ron);
}

/** Basic date formatter for RO (YYYY-MM-DD -> DD.MM.YYYY). */
function formatDateRO(isoDate) {
  if (!isoDate) return '';
  const d = new Date(isoDate);
  if (Number.isNaN(d.getTime())) return isoDate;
  return new Intl.DateTimeFormat('ro-RO', { year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
}

/** Immutable seed data. Salaries kept in bani (integers). */
const EMPLOYEES = Object.freeze([
  { id: 1, name: 'Andrei Popescu', age: 31, department: 'IT',      salaryBani: 12500_00 /*, email: '', hiringDate: '2022-05-11'*/ },
  { id: 2, name: 'Ioana Ionescu',  age: 28, department: 'HR',      salaryBani:  9200_00 /*, email: '', hiringDate: '2023-01-23'*/ },
  { id: 3, name: 'Mihai Dumitru',  age: 39, department: 'Finance', salaryBani: 15000_00 /*, email: '', hiringDate: '2021-09-14'*/ },
  { id: 4, name: 'Elena Marin',    age: 26, department: 'IT',      salaryBani:  8300_00 /*, email: '', hiringDate: '2024-03-02'*/ },
  { id: 5, name: 'Paul Stoica',    age: 34, department: 'HR',      salaryBani: 10100_00 /*, email: '', hiringDate: '2020-11-30'*/ },
]);

/** Cache DOM nodes. */
const $out = document.getElementById('employeesDetails');
const $btnShowAll = document.getElementById('btnShowAll');
const $btnTotal = document.getElementById('btnTotalSalary');
const $btnHR = document.getElementById('btnShowHR');
const $btnFind = document.getElementById('btnFindById');
const $idInput = document.getElementById('empIdInput');

// Advanced controls (for homework)
const $deptSelect = document.getElementById('deptSelect');
const $minSalary = document.getElementById('minSalary');
const $hiringAfter = document.getElementById('hiringAfter');
const $btnAdvanced = document.getElementById('btnAdvancedFilter');

/** Render helper — clears container. */
function clearOutput() {
  $out.replaceChildren(); // safer and faster than innerHTML = ''
}

/** Render a message safely. */
function renderMessage(text) {
  clearOutput();
  const p = document.createElement('p');
  p.className = 'empty';
  p.textContent = text;
  $out.appendChild(p);
}

/** Render a table from an array of employee-like objects. */
function renderEmployeesTable(list) {
  clearOutput();
  if (!Array.isArray(list) || list.length === 0) {
    renderMessage('No employees to display.');
    return;
  }

  const table = document.createElement('table');
  const thead = document.createElement('thead');
  const tbody = document.createElement('tbody');

  // Header
  const hr = document.createElement('tr');
  ['ID', 'Name', 'Department', 'Age', 'Salary (RON)'].forEach(h => {
    const th = document.createElement('th');
    th.textContent = h;
    hr.appendChild(th);
  });
  thead.appendChild(hr);

  // Rows
  list.forEach(emp => {
    const tr = document.createElement('tr');

    const tdId = document.createElement('td'); tdId.textContent = String(emp.id);
    const tdName = document.createElement('td'); tdName.textContent = emp.name;
    const tdDept = document.createElement('td'); tdDept.textContent = emp.department;
    const tdAge = document.createElement('td'); tdAge.textContent = String(emp.age);
    const tdSalary = document.createElement('td'); tdSalary.textContent = ronFromBani(emp.salaryBani);

    tr.append(tdId, tdName, tdDept, tdAge, tdSalary);
    tbody.appendChild(tr);
  });

  table.append(thead, tbody);
  $out.appendChild(table);
}

/** Actions **/

function handleShowAll() {
  // map to clone minimal fields (pure approach, no mutation)
  const rows = EMPLOYEES.map(e => ({
    id: e.id, name: e.name, department: e.department, age: e.age, salaryBani: e.salaryBani
  }));
  renderEmployeesTable(rows);
}

function handleTotalSalaries() {
  const total = EMPLOYEES.reduce((acc, e) => acc + e.salaryBani, 0);
  alert(`Total salaries: ${ronFromBani(total)}`);
}

function handleShowHR() {
  const hrList = EMPLOYEES.filter(e => e.department === 'HR');
  renderEmployeesTable(hrList);
}

function handleFindById() {
  const raw = $idInput.value.trim();
  if (!raw) {
    renderMessage('Please enter an ID to search.');
    return;
  }
  const id = Number(raw);
  if (!Number.isInteger(id) || id <= 0) {
    renderMessage('Invalid ID. Please provide a positive integer.');
    return;
  }
  const found = EMPLOYEES.find(e => e.id === id);
  if (!found) {
    renderMessage(`No employee found with ID ${id}.`);
    return;
  }
  renderEmployeesTable([found]);
}

/** Optional advanced filter (for homework demonstration) */
function handleAdvancedFilter() {
  const dept = ($deptSelect.value || '').trim();
  const minSalaryRON = Number($minSalary.value || '0'); // user enters RON
  const hiredAfter = ($hiringAfter.value || '').trim();

  let list = EMPLOYEES.slice();

  if (dept) {
    list = list.filter(e => e.department === dept);
  }
  if (Number.isFinite(minSalaryRON) && minSalaryRON > 0) {
    const thresholdBani = Math.round(minSalaryRON * 100);
    list = list.filter(e => e.salaryBani >= thresholdBani);
  }
  if (hiredAfter) {
    // If hiringDate existed, we would filter by it. Starter kit keeps it as TODO.
    // Example (if e.hiringDate exists): new Date(e.hiringDate) > new Date(hiredAfter)
    // For now we just inform the user.
    alert('Hiring date filter is a homework extension — please add hiringDate to data first.');
  }

  renderEmployeesTable(list);
}

/** Wire up events */
$btnShowAll.addEventListener('click', handleShowAll);
$btnTotal.addEventListener('click', handleTotalSalaries);
$btnHR.addEventListener('click', handleShowHR);
$btnFind.addEventListener('click', handleFindById);
$btnAdvanced.addEventListener('click', handleAdvancedFilter);

// Initial render message
renderMessage('Use the actions above to display or filter employees.');
